import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly STORAGE_KEY = 'teaa-theme';
  isDark = signal(this.loadTheme());

  toggle(): void {
    this.isDark.update(v => !v);
    this.applyTheme();
    localStorage.setItem(this.STORAGE_KEY, this.isDark() ? 'dark' : 'light');
  }

  applyTheme(): void {
    document.body.classList.toggle('dark-theme', this.isDark());
  }

  private loadTheme(): boolean {
    const saved = localStorage.getItem(this.STORAGE_KEY);
    return saved === 'dark';
  }

  init(): void {
    this.applyTheme();
  }
}
