import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const API = '/api/v1';

// --- Models ---

export interface SourceType {
  id?: number;
  code: string;
  name: string;
  description?: string;
  defaultConfig?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Source {
  id?: number;
  name: string;
  description?: string;
  typeId: number;
  location: string;
  config?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Job {
  id?: number;
  sourceId: number;
  action: string;
  status?: string;
  progress?: number;
  totalItems?: number;
  processedItems?: number;
  errorMessage?: string;
  configOverride?: string;
  startedAt?: string;
  completedAt?: string;
  createdAt?: string;
}

export interface Collection {
  id?: number;
  name: string;
  description?: string;
  version?: string;
  embeddingModel: string;
  dimensions: number;
  chunkSize: number;
  chunkOverlap: number;
  teiBaseUrl?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Setting {
  key: string;
  value: string;
  description?: string;
  updatedAt?: string;
}

export interface SystemStatus {
  runningDownloads: number;
  runningEmbeds: number;
  pendingJobs: number;
  totalChunks: number;
  teiHealthy: boolean;
  recentJobs?: Job[];
}

export interface SearchQuery {
  embedding: number[];
  topK?: number;
}

export interface SearchRequest {
  queries: SearchQuery[];
  threshold?: number;
  sourceId?: number;
  collectionId?: number;
}

export interface ChunkResult {
  chunkId: number;
  content: string;
  similarity: number;
  sourceId: number;
  metadata: Record<string, unknown>;
}

export interface QueryResult {
  queryIndex: number;
  chunks: ChunkResult[];
}

export interface SearchResponse {
  results: QueryResult[];
}

// --- Services ---

@Injectable({ providedIn: 'root' })
export class SourceTypeApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<SourceType[]> { return this.http.get<SourceType[]>(`${API}/source-types`); }
  findById(id: number): Observable<SourceType> { return this.http.get<SourceType>(`${API}/source-types/${id}`); }
  create(data: SourceType): Observable<SourceType> { return this.http.post<SourceType>(`${API}/source-types`, data); }
  update(id: number, data: SourceType): Observable<SourceType> { return this.http.put<SourceType>(`${API}/source-types/${id}`, data); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/source-types/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class SourceApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<Source[]> { return this.http.get<Source[]>(`${API}/sources`); }
  findById(id: number): Observable<Source> { return this.http.get<Source>(`${API}/sources/${id}`); }
  chunkCount(id: number): Observable<{sourceId: number; chunkCount: number}> { return this.http.get<any>(`${API}/sources/${id}/chunks/count`); }
  create(data: Source): Observable<Source> { return this.http.post<Source>(`${API}/sources`, data); }
  update(id: number, data: Source): Observable<Source> { return this.http.put<Source>(`${API}/sources/${id}`, data); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/sources/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class JobApiService {
  constructor(private http: HttpClient) {}
  findAll(params?: {status?: string; action?: string}): Observable<Job[]> {
    let url = `${API}/jobs`;
    const queryParams: string[] = [];
    if (params?.status) queryParams.push(`status=${params.status}`);
    if (params?.action) queryParams.push(`action=${params.action}`);
    if (queryParams.length) url += '?' + queryParams.join('&');
    return this.http.get<Job[]>(url);
  }
  findById(id: number): Observable<Job> { return this.http.get<Job>(`${API}/jobs/${id}`); }
  create(data: Partial<Job>): Observable<Job> { return this.http.post<Job>(`${API}/jobs`, data); }
  updateAndRestart(id: number, data: Partial<Job>): Observable<Job> { return this.http.put<Job>(`${API}/jobs/${id}`, data); }
  stop(id: number): Observable<Job> { return this.http.put<Job>(`${API}/jobs/${id}/stop`, {}); }
  resume(id: number): Observable<Job> { return this.http.put<Job>(`${API}/jobs/${id}/resume`, {}); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/jobs/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class CollectionApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<Collection[]> { return this.http.get<Collection[]>(`${API}/collections`); }
  findById(id: number): Observable<Collection> { return this.http.get<Collection>(`${API}/collections/${id}`); }
  create(data: Collection): Observable<Collection> { return this.http.post<Collection>(`${API}/collections`, data); }
  update(id: number, data: Collection): Observable<Collection> { return this.http.put<Collection>(`${API}/collections/${id}`, data); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/collections/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class SettingsApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<Setting[]> { return this.http.get<Setting[]>(`${API}/settings`); }
  findByKey(key: string): Observable<Setting> { return this.http.get<Setting>(`${API}/settings/${key}`); }
  update(key: string, value: string): Observable<Setting> { return this.http.put<Setting>(`${API}/settings/${key}`, { value }); }
  create(data: Setting): Observable<Setting> { return this.http.post<Setting>(`${API}/settings`, data); }
  delete(key: string): Observable<void> { return this.http.delete<void>(`${API}/settings/${key}`); }
  reload(): Observable<void> { return this.http.post<void>(`${API}/settings/reload`, {}); }
}

@Injectable({ providedIn: 'root' })
export class StatusApiService {
  constructor(private http: HttpClient) {}
  getStatus(): Observable<SystemStatus> { return this.http.get<SystemStatus>(`${API}/status`); }
}

@Injectable({ providedIn: 'root' })
export class SearchApiService {
  constructor(private http: HttpClient) {}
  search(request: SearchRequest): Observable<SearchResponse> { return this.http.post<SearchResponse>(`${API}/search`, request); }
}
