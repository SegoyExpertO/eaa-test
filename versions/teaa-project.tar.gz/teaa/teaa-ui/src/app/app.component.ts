import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ThemeService } from '@shared/services/theme.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, RouterModule, RouterOutlet,
    MatSidenavModule, MatToolbarModule, MatListModule,
    MatIconModule, MatButtonModule, MatTooltipModule
  ],
  template: `
    <mat-sidenav-container class="app-container">
      <mat-sidenav mode="side" [opened]="true" class="sidenav">
        <div class="sidenav-header">
          <span class="logo" i18n="@@navLogo">TEAA RAG</span>
        </div>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span i18n="@@navDashboard">Огляд</span>
          </a>
          <a mat-list-item routerLink="/source-types" routerLinkActive="active">
            <mat-icon matListItemIcon>category</mat-icon>
            <span i18n="@@navSourceTypes">Типи джерел</span>
          </a>
          <a mat-list-item routerLink="/sources" routerLinkActive="active">
            <mat-icon matListItemIcon>source</mat-icon>
            <span i18n="@@navSources">Джерела</span>
          </a>
          <a mat-list-item routerLink="/jobs" routerLinkActive="active">
            <mat-icon matListItemIcon>work</mat-icon>
            <span i18n="@@navJobs">Завдання</span>
          </a>
          <a mat-list-item routerLink="/collections" routerLinkActive="active">
            <mat-icon matListItemIcon>collections_bookmark</mat-icon>
            <span i18n="@@navCollections">Колекції</span>
          </a>
          <a mat-list-item routerLink="/settings" routerLinkActive="active">
            <mat-icon matListItemIcon>settings</mat-icon>
            <span i18n="@@navSettings">Налаштування</span>
          </a>
          <a mat-list-item routerLink="/search" routerLinkActive="active">
            <mat-icon matListItemIcon>search</mat-icon>
            <span i18n="@@navSearch">Пошук</span>
          </a>
          <a mat-list-item routerLink="/export-import" routerLinkActive="active">
            <mat-icon matListItemIcon>import_export</mat-icon>
            <span i18n="@@navExportImport">Експорт / Імпорт</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>

      <mat-sidenav-content class="main-content">
        <mat-toolbar class="toolbar">
          <span class="toolbar-spacer"></span>
          <button mat-icon-button (click)="theme.toggle()" [matTooltip]="theme.isDark() ? 'Light' : 'Dark'">
            <mat-icon>{{ theme.isDark() ? 'light_mode' : 'dark_mode' }}</mat-icon>
          </button>
        </mat-toolbar>
        <div class="content">
          <router-outlet />
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .app-container { height: 100vh; }
    .sidenav {
      width: 240px;
      background: var(--bg-surface);
      border-right: 1px solid var(--border-color);
    }
    .sidenav-header {
      padding: 20px 16px;
      border-bottom: 1px solid var(--border-color);
    }
    .logo {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--primary);
      letter-spacing: 1px;
    }
    .toolbar {
      background: var(--bg-surface);
      border-bottom: 1px solid var(--border-color);
      height: 56px;
      color: var(--text-primary);
    }
    .toolbar-spacer { flex: 1; }
    .content { padding: 24px; }
    .active {
      background: rgba(37, 99, 235, 0.08) !important;
      color: var(--primary) !important;
    }
    mat-nav-list a {
      color: var(--text-primary);
      font-size: 0.875rem;
    }
  `]
})
export class AppComponent implements OnInit {
  constructor(public theme: ThemeService) {}

  ngOnInit(): void {
    this.theme.init();
  }
}
