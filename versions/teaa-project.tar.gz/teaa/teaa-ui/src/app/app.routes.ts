import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: 'dashboard',
    loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent)
  },
  {
    path: 'source-types',
    loadComponent: () => import('./pages/source-types/source-type-list.component').then(m => m.SourceTypeListComponent)
  },
  {
    path: 'source-types/new',
    loadComponent: () => import('./pages/source-types/source-type-form.component').then(m => m.SourceTypeFormComponent)
  },
  {
    path: 'source-types/:id',
    loadComponent: () => import('./pages/source-types/source-type-form.component').then(m => m.SourceTypeFormComponent)
  },
  {
    path: 'sources',
    loadComponent: () => import('./pages/sources/source-list.component').then(m => m.SourceListComponent)
  },
  {
    path: 'sources/new',
    loadComponent: () => import('./pages/sources/source-form.component').then(m => m.SourceFormComponent)
  },
  {
    path: 'sources/:id',
    loadComponent: () => import('./pages/sources/source-form.component').then(m => m.SourceFormComponent)
  },
  {
    path: 'jobs',
    loadComponent: () => import('./pages/jobs/job-list.component').then(m => m.JobListComponent)
  },
  {
    path: 'jobs/new',
    loadComponent: () => import('./pages/jobs/job-form.component').then(m => m.JobFormComponent)
  },
  {
    path: 'collections',
    loadComponent: () => import('./pages/collections/collection-list.component').then(m => m.CollectionListComponent)
  },
  {
    path: 'collections/new',
    loadComponent: () => import('./pages/collections/collection-form.component').then(m => m.CollectionFormComponent)
  },
  {
    path: 'collections/:id',
    loadComponent: () => import('./pages/collections/collection-form.component').then(m => m.CollectionFormComponent)
  },
  {
    path: 'settings',
    loadComponent: () => import('./pages/settings/settings.component').then(m => m.SettingsComponent)
  },
  {
    path: 'search',
    loadComponent: () => import('./pages/search/search.component').then(m => m.SearchComponent)
  },
  {
    path: 'export-import',
    loadComponent: () => import('./pages/export-import/export-import.component').then(m => m.ExportImportComponent)
  }
];
