import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { SourceTypeApiService, SourceType } from '@shared/services/api.service';

@Component({
  selector: 'app-source-type-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MatTableModule, MatButtonModule, MatIconModule, MatSnackBarModule],
  template: `
    <div class="page-header">
      <h1 i18n="@@sourceTypesTitle">Типи джерел</h1>
      <a mat-flat-button color="primary" routerLink="/source-types/new" i18n="@@sourceTypesCreate">Створити</a>
    </div>

    <table mat-table [dataSource]="items()" class="mat-elevation-z0">
      <ng-container matColumnDef="code">
        <th mat-header-cell *matHeaderCellDef i18n="@@stColCode">Код</th>
        <td mat-cell *matCellDef="let item"><code>{{ item.code }}</code></td>
      </ng-container>

      <ng-container matColumnDef="name">
        <th mat-header-cell *matHeaderCellDef i18n="@@stColName">Назва</th>
        <td mat-cell *matCellDef="let item">{{ item.name }}</td>
      </ng-container>

      <ng-container matColumnDef="description">
        <th mat-header-cell *matHeaderCellDef i18n="@@stColDesc">Опис</th>
        <td mat-cell *matCellDef="let item">{{ item.description }}</td>
      </ng-container>

      <ng-container matColumnDef="createdAt">
        <th mat-header-cell *matHeaderCellDef i18n="@@stColCreated">Створено</th>
        <td mat-cell *matCellDef="let item">{{ item.createdAt | date:'short' }}</td>
      </ng-container>

      <ng-container matColumnDef="actions">
        <th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let item">
          <a mat-icon-button [routerLink]="['/source-types', item.id]"><mat-icon>edit</mat-icon></a>
          <button mat-icon-button (click)="remove(item)" color="warn"><mat-icon>delete</mat-icon></button>
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.8rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
  `]
})
export class SourceTypeListComponent implements OnInit {
  items = signal<SourceType[]>([]);
  columns = ['code', 'name', 'description', 'createdAt', 'actions'];

  constructor(private api: SourceTypeApiService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.load();
  }

  remove(item: SourceType): void {
    this.api.delete(item.id!).subscribe(() => {
      this.snackBar.open('Видалено', '', { duration: 2000 });
      this.load();
    });
  }

  private load(): void {
    this.api.findAll().subscribe(data => this.items.set(data));
  }
}
