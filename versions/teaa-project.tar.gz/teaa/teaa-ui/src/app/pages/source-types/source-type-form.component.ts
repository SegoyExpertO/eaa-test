import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { SourceTypeApiService, SourceType } from '@shared/services/api.service';

@Component({
  selector: 'app-source-type-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatSnackBarModule],
  template: `
    <div class="page-header">
      <h1>{{ isEdit() ? 'Редагування типу' : 'Новий тип джерела' }}</h1>
    </div>

    <div class="card form-card">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@stFormCode">Код</mat-label>
        <input matInput [(ngModel)]="model.code" [disabled]="isEdit()">
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@stFormName">Назва</mat-label>
        <input matInput [(ngModel)]="model.name">
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@stFormDesc">Опис</mat-label>
        <textarea matInput [(ngModel)]="model.description" rows="3"></textarea>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@stFormConfig">Типова конфігурація (JSON)</mat-label>
        <textarea matInput [(ngModel)]="model.defaultConfig" rows="8" class="json-input"></textarea>
      </mat-form-field>

      <div class="form-actions">
        <button mat-stroked-button routerLink="/source-types" i18n="@@formCancel">Скасувати</button>
        <button mat-flat-button color="primary" (click)="save()" i18n="@@formSave">Зберегти</button>
      </div>
    </div>
  `,
  styles: [`
    .form-card { max-width: 640px; }
    .full-width { width: 100%; }
    .json-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }
  `]
})
export class SourceTypeFormComponent implements OnInit {
  model: SourceType = { code: '', name: '', description: '', defaultConfig: '{}' };
  isEdit = signal(false);
  private id?: number;

  constructor(
    private api: SourceTypeApiService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = +idParam;
      this.isEdit.set(true);
      this.api.findById(this.id).subscribe(data => this.model = data);
    }
  }

  save(): void {
    const obs = this.isEdit()
      ? this.api.update(this.id!, this.model)
      : this.api.create(this.model);

    obs.subscribe(() => {
      this.snackBar.open('Збережено', '', { duration: 2000 });
      this.router.navigate(['/source-types']);
    });
  }
}
