import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { HttpClient } from '@angular/common/http';
import {
  SourceApiService, Source,
  CollectionApiService, Collection
} from '@shared/services/api.service';

@Component({
  selector: 'app-export-import',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatCardModule, MatButtonModule,
    MatSelectModule, MatFormFieldModule, MatIconModule,
    MatSnackBarModule, MatDividerModule
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@exportImportTitle">Експорт / Імпорт</h1>
    </div>

    <!-- EXPORT -->
    <mat-card class="section-card">
      <h2 i18n="@@exportTitle">Експорт</h2>

      <div class="export-row">
        <mat-form-field appearance="outline">
          <mat-label i18n="@@exportScope">Обсяг</mat-label>
          <mat-select [(ngModel)]="exportScope">
            <mat-option value="all" i18n="@@exportScopeAll">Весь RAG</mat-option>
            <mat-option value="collection" i18n="@@exportScopeCollection">Колекція</mat-option>
            <mat-option value="source" i18n="@@exportScopeSource">Джерело</mat-option>
          </mat-select>
        </mat-form-field>

        @if (exportScope === 'collection') {
          <mat-form-field appearance="outline">
            <mat-label i18n="@@exportCollection">Колекція</mat-label>
            <mat-select [(ngModel)]="exportId">
              @for (c of collections(); track c.id) {
                <mat-option [value]="c.id">{{ c.name }} (v{{ c.version }})</mat-option>
              }
            </mat-select>
          </mat-form-field>
        }

        @if (exportScope === 'source') {
          <mat-form-field appearance="outline">
            <mat-label i18n="@@exportSource">Джерело</mat-label>
            <mat-select [(ngModel)]="exportId">
              @for (s of sources(); track s.id) {
                <mat-option [value]="s.id">{{ s.name }}</mat-option>
              }
            </mat-select>
          </mat-form-field>
        }

        <mat-form-field appearance="outline">
          <mat-label i18n="@@exportFormat">Формат</mat-label>
          <mat-select [(ngModel)]="exportFormat">
            <mat-option value="json">JSON</mat-option>
            <mat-option value="sql">SQL</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      <button mat-flat-button color="primary" (click)="doExport()"
              [disabled]="exportScope !== 'all' && !exportId"
              i18n="@@exportButton">
        <mat-icon>download</mat-icon> Експортувати
      </button>
    </mat-card>

    <mat-divider class="divider"></mat-divider>

    <!-- IMPORT -->
    <mat-card class="section-card">
      <h2 i18n="@@importTitle">Імпорт</h2>
      <p class="hint" i18n="@@importHint">Завантажте файл .json або .sql, отриманий через експорт.</p>

      <div class="import-row">
        <input type="file" accept=".json,.sql" (change)="onFileSelected($event)" #fileInput>
        <button mat-flat-button color="primary" (click)="doImport()"
                [disabled]="!selectedFile"
                i18n="@@importButton">
          <mat-icon>upload</mat-icon> Імпортувати
        </button>
      </div>

      @if (importResult()) {
        <div class="import-result" [class.success]="importResult()?.status === 'SUCCESS'"
             [class.error]="importResult()?.status === 'ERROR'">
          <p>{{ importResult()?.status }}</p>
          @if (importResult()?.imported !== undefined) {
            <p i18n="@@importResultChunks">Імпортовано чанків: {{ importResult()?.imported }}</p>
          }
          @if (importResult()?.executedStatements !== undefined) {
            <p i18n="@@importResultStatements">Виконано SQL: {{ importResult()?.executedStatements }}</p>
          }
          @if (importResult()?.error) {
            <p class="error-text">{{ importResult()?.error }}</p>
          }
        </div>
      }
    </mat-card>
  `,
  styles: [`
    .section-card {
      max-width: 800px;
      margin-bottom: 24px;
      padding: 24px;
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
    }
    h2 { font-size: 1.1rem; margin-bottom: 16px; }
    .export-row { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; }
    .export-row mat-form-field { flex: 1; min-width: 160px; }
    .divider { margin: 8px 0; max-width: 800px; }
    .import-row { display: flex; gap: 16px; align-items: center; margin-bottom: 16px; }
    .hint { font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 16px; }
    .import-result {
      padding: 12px 16px; border-radius: 6px; margin-top: 12px;
    }
    .import-result.success { background: rgba(22,163,74,0.08); color: var(--success); }
    .import-result.error { background: rgba(220,38,38,0.08); color: var(--error); }
    .error-text { font-size: 0.85rem; }
  `]
})
export class ExportImportComponent implements OnInit {
  exportScope = 'all';
  exportId: number | null = null;
  exportFormat = 'json';
  selectedFile: File | null = null;
  importResult = signal<any>(null);

  sources = signal<Source[]>([]);
  collections = signal<Collection[]>([]);

  constructor(
    private http: HttpClient,
    private sourceApi: SourceApiService,
    private collectionApi: CollectionApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.sourceApi.findAll().subscribe(s => this.sources.set(s));
    this.collectionApi.findAll().subscribe(c => this.collections.set(c));
  }

  doExport(): void {
    let url = `/api/v1/export?scope=${this.exportScope}&format=${this.exportFormat}`;
    if (this.exportScope !== 'all' && this.exportId) {
      url += `&id=${this.exportId}`;
    }

    this.http.get(url, { responseType: 'blob' }).subscribe(blob => {
      const ext = this.exportFormat === 'json' ? '.json' : '.sql';
      const filename = `teaa-rag-export-${this.exportScope}${ext}`;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      a.click();
      URL.revokeObjectURL(a.href);
      this.snackBar.open('Експорт завершено', '', { duration: 2000 });
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] ?? null;
    this.importResult.set(null);
  }

  doImport(): void {
    if (!this.selectedFile) return;

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post<any>('/api/v1/import', formData).subscribe({
      next: result => {
        this.importResult.set(result);
        this.snackBar.open('Імпорт завершено', '', { duration: 2000 });
      },
      error: err => {
        this.importResult.set({ status: 'ERROR', error: err.message });
      }
    });
  }
}
