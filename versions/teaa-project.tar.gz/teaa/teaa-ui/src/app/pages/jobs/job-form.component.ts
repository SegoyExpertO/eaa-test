import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { JobApiService, SourceApiService, Source } from '@shared/services/api.service';

@Component({
  selector: 'app-job-form',
  standalone: true,
  imports: [
    CommonModule, FormsModule, RouterModule, MatFormFieldModule,
    MatInputModule, MatSelectModule, MatButtonModule, MatSnackBarModule
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@jobFormTitle">Нове завдання</h1>
    </div>

    <div class="card form-card">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@jobFormSource">Джерело</mat-label>
        <mat-select [(ngModel)]="sourceId">
          @for (s of sources(); track s.id) {
            <mat-option [value]="s.id">{{ s.name }} ({{ s.location | slice:0:40 }})</mat-option>
          }
        </mat-select>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@jobFormAction">Дія</mat-label>
        <mat-select [(ngModel)]="action">
          <mat-option value="DOWNLOAD" i18n="@@jobActionDownload">DOWNLOAD — завантаження та нарізка</mat-option>
          <mat-option value="EMBED" i18n="@@jobActionEmbed">EMBED — генерація embeddings</mat-option>
        </mat-select>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@jobFormConfigOverride">Config override (JSON, опціонально)</mat-label>
        <textarea matInput [(ngModel)]="configOverride" rows="6" class="json-input"
                  placeholder='{"chunk_size": 500, "max_depth": 1}'></textarea>
        <mat-hint i18n="@@jobFormConfigHint">Перевизначає параметри джерела для цього запуску</mat-hint>
      </mat-form-field>

      <div class="form-actions">
        <button mat-stroked-button routerLink="/jobs" i18n="@@formCancel">Скасувати</button>
        <button mat-flat-button color="primary" (click)="create()" [disabled]="!sourceId || !action"
                i18n="@@jobFormSubmit">Створити завдання</button>
      </div>
    </div>
  `,
  styles: [`
    .form-card { max-width: 640px; }
    .full-width { width: 100%; }
    .json-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }
  `]
})
export class JobFormComponent implements OnInit {
  sources = signal<Source[]>([]);
  sourceId: number | null = null;
  action = '';
  configOverride = '';

  constructor(
    private jobApi: JobApiService,
    private sourceApi: SourceApiService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.sourceApi.findAll().subscribe(s => this.sources.set(s));
  }

  create(): void {
    const job: any = {
      sourceId: this.sourceId,
      action: this.action
    };
    if (this.configOverride.trim()) {
      job.configOverride = this.configOverride;
    }

    this.jobApi.create(job).subscribe(() => {
      this.snackBar.open('Завдання створено', '', { duration: 2000 });
      this.router.navigate(['/jobs']);
    });
  }
}
