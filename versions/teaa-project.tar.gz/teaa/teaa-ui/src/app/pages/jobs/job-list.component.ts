import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { StatusBadgeComponent } from '@shared/components/status-badge.component';
import { JobApiService, Job } from '@shared/services/api.service';
import { interval, Subscription, switchMap, filter } from 'rxjs';

@Component({
  selector: 'app-job-list',
  standalone: true,
  imports: [
    CommonModule, RouterModule, MatTableModule, MatButtonModule,
    MatIconModule, MatProgressBarModule, MatMenuModule,
    MatDialogModule, MatSnackBarModule, StatusBadgeComponent
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@jobsTitle">Завдання</h1>
      <a mat-flat-button color="primary" routerLink="/jobs/new" i18n="@@jobsCreate">Створити</a>
    </div>

    <table mat-table [dataSource]="jobs()" class="mat-elevation-z0">
      <ng-container matColumnDef="id">
        <th mat-header-cell *matHeaderCellDef>ID</th>
        <td mat-cell *matCellDef="let job">#{{ job.id }}</td>
      </ng-container>

      <ng-container matColumnDef="action">
        <th mat-header-cell *matHeaderCellDef i18n="@@jobsColAction">Дія</th>
        <td mat-cell *matCellDef="let job">{{ job.action }}</td>
      </ng-container>

      <ng-container matColumnDef="status">
        <th mat-header-cell *matHeaderCellDef i18n="@@jobsColStatus">Статус</th>
        <td mat-cell *matCellDef="let job"><app-status-badge [status]="job.status" /></td>
      </ng-container>

      <ng-container matColumnDef="progress">
        <th mat-header-cell *matHeaderCellDef i18n="@@jobsColProgress">Прогрес</th>
        <td mat-cell *matCellDef="let job">
          @if (job.status === 'RUNNING') {
            <mat-progress-bar mode="determinate" [value]="job.progress" />
            <span class="progress-text">{{ job.processedItems }}/{{ job.totalItems }}</span>
          } @else if (job.status === 'COMPLETED') {
            <span class="progress-text">{{ job.totalItems }} / {{ job.totalItems }}</span>
          }
        </td>
      </ng-container>

      <ng-container matColumnDef="error">
        <th mat-header-cell *matHeaderCellDef i18n="@@jobsColError">Помилка</th>
        <td mat-cell *matCellDef="let job">
          <span class="error-text">{{ job.errorMessage | slice:0:60 }}</span>
        </td>
      </ng-container>

      <ng-container matColumnDef="createdAt">
        <th mat-header-cell *matHeaderCellDef i18n="@@jobsColCreated">Створено</th>
        <td mat-cell *matCellDef="let job">{{ job.createdAt | date:'short' }}</td>
      </ng-container>

      <ng-container matColumnDef="actions">
        <th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let job">
          <button mat-icon-button [matMenuTriggerFor]="menu">
            <mat-icon>more_vert</mat-icon>
          </button>
          <mat-menu #menu="matMenu">
            @if (job.status === 'RUNNING' || job.status === 'PENDING') {
              <button mat-menu-item (click)="stop(job)" i18n="@@jobsActionStop">
                <mat-icon>pause</mat-icon> Зупинити
              </button>
            }
            @if (job.status === 'STOPPED' || job.status === 'FAILED') {
              <button mat-menu-item (click)="resume(job)" i18n="@@jobsActionResume">
                <mat-icon>play_arrow</mat-icon> Відновити
              </button>
            }
            <button mat-menu-item (click)="deleteJob(job)" i18n="@@jobsActionDelete">
              <mat-icon>delete</mat-icon> Видалити
            </button>
          </mat-menu>
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    .progress-text { font-size: 0.75rem; color: var(--text-secondary); margin-left: 8px; }
    .error-text { font-size: 0.75rem; color: var(--error); }
    mat-progress-bar { display: inline-block; width: 120px; vertical-align: middle; }
  `]
})
export class JobListComponent implements OnInit, OnDestroy {
  jobs = signal<Job[]>([]);
  columns = ['id', 'action', 'status', 'progress', 'error', 'createdAt', 'actions'];
  private sub?: Subscription;

  constructor(
    private jobApi: JobApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadJobs();
    this.sub = interval(5000).pipe(
      filter(() => this.jobs().some(j => j.status === 'RUNNING' || j.status === 'PENDING')),
      switchMap(() => this.jobApi.findAll())
    ).subscribe(jobs => this.jobs.set(jobs));
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  stop(job: Job): void {
    this.jobApi.stop(job.id!).subscribe(() => {
      this.snackBar.open('Завдання зупинено', '', { duration: 2000 });
      this.loadJobs();
    });
  }

  resume(job: Job): void {
    this.jobApi.resume(job.id!).subscribe(() => {
      this.snackBar.open('Завдання відновлено', '', { duration: 2000 });
      this.loadJobs();
    });
  }

  deleteJob(job: Job): void {
    this.jobApi.delete(job.id!).subscribe(() => {
      this.snackBar.open('Завдання видалено', '', { duration: 2000 });
      this.loadJobs();
    });
  }

  private loadJobs(): void {
    this.jobApi.findAll().subscribe(jobs => this.jobs.set(jobs));
  }
}
