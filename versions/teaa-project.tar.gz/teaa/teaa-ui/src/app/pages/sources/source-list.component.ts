import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { StatusBadgeComponent } from '@shared/components/status-badge.component';
import { SourceApiService, Source, SourceTypeApiService, SourceType, JobApiService } from '@shared/services/api.service';

@Component({
  selector: 'app-source-list',
  standalone: true,
  imports: [
    CommonModule, RouterModule, MatTableModule, MatButtonModule,
    MatIconModule, MatMenuModule, MatSnackBarModule, StatusBadgeComponent
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@sourcesTitle">Джерела</h1>
      <a mat-flat-button color="primary" routerLink="/sources/new" i18n="@@sourcesCreate">Додати</a>
    </div>

    <table mat-table [dataSource]="items()" class="mat-elevation-z0">
      <ng-container matColumnDef="name">
        <th mat-header-cell *matHeaderCellDef i18n="@@srcColName">Назва</th>
        <td mat-cell *matCellDef="let item">{{ item.name }}</td>
      </ng-container>

      <ng-container matColumnDef="type">
        <th mat-header-cell *matHeaderCellDef i18n="@@srcColType">Тип</th>
        <td mat-cell *matCellDef="let item">
          <code>{{ getTypeCode(item.typeId) }}</code>
        </td>
      </ng-container>

      <ng-container matColumnDef="location">
        <th mat-header-cell *matHeaderCellDef i18n="@@srcColLocation">Location</th>
        <td mat-cell *matCellDef="let item" class="location-cell">{{ item.location | slice:0:50 }}</td>
      </ng-container>

      <ng-container matColumnDef="status">
        <th mat-header-cell *matHeaderCellDef i18n="@@srcColStatus">Статус</th>
        <td mat-cell *matCellDef="let item"><app-status-badge [status]="item.status" /></td>
      </ng-container>

      <ng-container matColumnDef="actions">
        <th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let item">
          <button mat-icon-button [matMenuTriggerFor]="menu"><mat-icon>more_vert</mat-icon></button>
          <mat-menu #menu="matMenu">
            <a mat-menu-item [routerLink]="['/sources', item.id]" i18n="@@srcActionEdit">
              <mat-icon>edit</mat-icon> Редагувати
            </a>
            <button mat-menu-item (click)="startDownload(item)" i18n="@@srcActionDownload">
              <mat-icon>download</mat-icon> Завантажити
            </button>
            <button mat-menu-item (click)="startEmbed(item)" i18n="@@srcActionEmbed">
              <mat-icon>memory</mat-icon> Embedding
            </button>
            <button mat-menu-item (click)="remove(item)" i18n="@@srcActionDelete">
              <mat-icon>delete</mat-icon> Видалити
            </button>
          </mat-menu>
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.75rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
    .location-cell { font-size: 0.8rem; color: var(--text-secondary); }
  `]
})
export class SourceListComponent implements OnInit {
  items = signal<Source[]>([]);
  types = signal<SourceType[]>([]);
  columns = ['name', 'type', 'location', 'status', 'actions'];

  constructor(
    private sourceApi: SourceApiService,
    private typeApi: SourceTypeApiService,
    private jobApi: JobApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.load();
    this.typeApi.findAll().subscribe(t => this.types.set(t));
  }

  getTypeCode(typeId: number): string {
    return this.types().find(t => t.id === typeId)?.code ?? '';
  }

  startDownload(source: Source): void {
    this.jobApi.create({ sourceId: source.id!, action: 'DOWNLOAD' }).subscribe(() => {
      this.snackBar.open('Завдання завантаження створено', '', { duration: 2000 });
    });
  }

  startEmbed(source: Source): void {
    this.jobApi.create({ sourceId: source.id!, action: 'EMBED' }).subscribe(() => {
      this.snackBar.open('Завдання embedding створено', '', { duration: 2000 });
    });
  }

  remove(source: Source): void {
    this.sourceApi.delete(source.id!).subscribe(() => {
      this.snackBar.open('Видалено', '', { duration: 2000 });
      this.load();
    });
  }

  private load(): void {
    this.sourceApi.findAll().subscribe(data => this.items.set(data));
  }
}
