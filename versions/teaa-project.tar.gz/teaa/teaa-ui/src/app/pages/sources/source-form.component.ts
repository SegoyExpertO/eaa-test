import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { SourceApiService, Source, SourceTypeApiService, SourceType } from '@shared/services/api.service';

@Component({
  selector: 'app-source-form',
  standalone: true,
  imports: [
    CommonModule, FormsModule, RouterModule, MatFormFieldModule,
    MatInputModule, MatSelectModule, MatButtonModule, MatSnackBarModule
  ],
  template: `
    <div class="page-header">
      <h1>{{ isEdit() ? 'Редагування джерела' : 'Нове джерело' }}</h1>
    </div>

    <div class="card form-card">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@srcFormName">Назва</mat-label>
        <input matInput [(ngModel)]="model.name">
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@srcFormDesc">Опис</mat-label>
        <textarea matInput [(ngModel)]="model.description" rows="2"></textarea>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@srcFormType">Тип джерела</mat-label>
        <mat-select [(ngModel)]="model.typeId" (selectionChange)="onTypeChange()">
          @for (type of types(); track type.id) {
            <mat-option [value]="type.id">{{ type.code }} — {{ type.name }}</mat-option>
          }
        </mat-select>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@srcFormLocation">Location (URL або шлях)</mat-label>
        <input matInput [(ngModel)]="model.location">
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@srcFormConfig">Конфігурація (JSON)</mat-label>
        <textarea matInput [(ngModel)]="model.config" rows="6" class="json-input"></textarea>
        <mat-hint i18n="@@srcFormConfigHint">Мержиться з типовою конфігурацією типу</mat-hint>
      </mat-form-field>

      <div class="form-actions">
        <button mat-stroked-button routerLink="/sources" i18n="@@formCancel">Скасувати</button>
        <button mat-flat-button color="primary" (click)="save()" i18n="@@formSave">Зберегти</button>
      </div>
    </div>
  `,
  styles: [`
    .form-card { max-width: 640px; }
    .full-width { width: 100%; }
    .json-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }
  `]
})
export class SourceFormComponent implements OnInit {
  model: Source = { name: '', typeId: 0, location: '', config: '{}' };
  types = signal<SourceType[]>([]);
  isEdit = signal(false);
  private id?: number;

  constructor(
    private sourceApi: SourceApiService,
    private typeApi: SourceTypeApiService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.typeApi.findAll().subscribe(t => this.types.set(t));

    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = +idParam;
      this.isEdit.set(true);
      this.sourceApi.findById(this.id).subscribe(data => this.model = data);
    }
  }

  onTypeChange(): void {
    if (!this.isEdit()) {
      const type = this.types().find(t => t.id === this.model.typeId);
      if (type?.defaultConfig) {
        this.model.config = type.defaultConfig;
      }
    }
  }

  save(): void {
    const obs = this.isEdit()
      ? this.sourceApi.update(this.id!, this.model)
      : this.sourceApi.create(this.model);

    obs.subscribe(() => {
      this.snackBar.open('Збережено', '', { duration: 2000 });
      this.router.navigate(['/sources']);
    });
  }
}
