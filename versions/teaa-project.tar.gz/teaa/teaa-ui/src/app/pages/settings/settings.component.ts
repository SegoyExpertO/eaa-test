import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { SettingsApiService, Setting } from '@shared/services/api.service';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatTableModule, MatButtonModule,
    MatIconModule, MatInputModule, MatFormFieldModule, MatSnackBarModule
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@settingsTitle">Налаштування</h1>
      <button mat-stroked-button (click)="reload()" i18n="@@settingsReload">
        <mat-icon>refresh</mat-icon> Перечитати з БД
      </button>
    </div>

    <table mat-table [dataSource]="settings()" class="mat-elevation-z0">
      <ng-container matColumnDef="key">
        <th mat-header-cell *matHeaderCellDef i18n="@@settingsColKey">Ключ</th>
        <td mat-cell *matCellDef="let s">
          <code>{{ s.key }}</code>
        </td>
      </ng-container>

      <ng-container matColumnDef="value">
        <th mat-header-cell *matHeaderCellDef i18n="@@settingsColValue">Значення</th>
        <td mat-cell *matCellDef="let s">
          @if (editingKey() === s.key) {
            <mat-form-field appearance="outline" class="inline-edit">
              <input matInput [(ngModel)]="editValue" (keyup.enter)="save(s.key)" (keyup.escape)="cancelEdit()">
            </mat-form-field>
            <button mat-icon-button (click)="save(s.key)" color="primary"><mat-icon>check</mat-icon></button>
            <button mat-icon-button (click)="cancelEdit()"><mat-icon>close</mat-icon></button>
          } @else {
            <span class="value-text" (click)="startEdit(s)">{{ s.value }}</span>
            <button mat-icon-button (click)="startEdit(s)" class="edit-btn"><mat-icon>edit</mat-icon></button>
          }
        </td>
      </ng-container>

      <ng-container matColumnDef="description">
        <th mat-header-cell *matHeaderCellDef i18n="@@settingsColDesc">Опис</th>
        <td mat-cell *matCellDef="let s">{{ s.description }}</td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.8rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
    .value-text { cursor: pointer; }
    .value-text:hover { text-decoration: underline; }
    .edit-btn { opacity: 0.3; }
    .edit-btn:hover { opacity: 1; }
    .inline-edit { width: 200px; }
  `]
})
export class SettingsComponent implements OnInit {
  settings = signal<Setting[]>([]);
  editingKey = signal<string | null>(null);
  editValue = '';
  columns = ['key', 'value', 'description'];

  constructor(private api: SettingsApiService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.loadSettings();
  }

  startEdit(setting: Setting): void {
    this.editingKey.set(setting.key);
    this.editValue = setting.value;
  }

  cancelEdit(): void {
    this.editingKey.set(null);
  }

  save(key: string): void {
    this.api.update(key, this.editValue).subscribe(() => {
      this.editingKey.set(null);
      this.snackBar.open('Збережено', '', { duration: 2000 });
      this.loadSettings();
    });
  }

  reload(): void {
    this.api.reload().subscribe(() => {
      this.snackBar.open('Кеш оновлено', '', { duration: 2000 });
      this.loadSettings();
    });
  }

  private loadSettings(): void {
    this.api.findAll().subscribe(s => this.settings.set(s));
  }
}
