import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { CollectionApiService, Collection } from '@shared/services/api.service';

@Component({
  selector: 'app-collection-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatSnackBarModule],
  template: `
    <div class="page-header">
      <h1>{{ isEdit() ? 'Редагування колекції' : 'Нова колекція' }}</h1>
    </div>

    <div class="card form-card">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@colFormName">Назва</mat-label>
        <input matInput [(ngModel)]="model.name">
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@colFormDesc">Опис</mat-label>
        <textarea matInput [(ngModel)]="model.description" rows="2"></textarea>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@colFormVersion">Версія</mat-label>
        <input matInput [(ngModel)]="model.version">
      </mat-form-field>

      <div class="row">
        <mat-form-field appearance="outline">
          <mat-label i18n="@@colFormModel">Embedding модель</mat-label>
          <input matInput [(ngModel)]="model.embeddingModel">
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label i18n="@@colFormDim">Розмірність</mat-label>
          <input matInput type="number" [(ngModel)]="model.dimensions">
        </mat-form-field>
      </div>

      <div class="row">
        <mat-form-field appearance="outline">
          <mat-label i18n="@@colFormChunkSize">Chunk size</mat-label>
          <input matInput type="number" [(ngModel)]="model.chunkSize">
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label i18n="@@colFormOverlap">Overlap</mat-label>
          <input matInput type="number" [(ngModel)]="model.chunkOverlap">
        </mat-form-field>
      </div>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@colFormTei">TEI Base URL</mat-label>
        <input matInput [(ngModel)]="model.teiBaseUrl">
      </mat-form-field>

      <div class="form-actions">
        <button mat-stroked-button routerLink="/collections" i18n="@@formCancel">Скасувати</button>
        <button mat-flat-button color="primary" (click)="save()" i18n="@@formSave">Зберегти</button>
      </div>
    </div>
  `,
  styles: [`
    .form-card { max-width: 640px; }
    .full-width { width: 100%; }
    .row { display: flex; gap: 16px; }
    .row mat-form-field { flex: 1; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }
  `]
})
export class CollectionFormComponent implements OnInit {
  model: Collection = {
    name: '', embeddingModel: '', dimensions: 768,
    chunkSize: 800, chunkOverlap: 200, version: '1.0.0'
  };
  isEdit = signal(false);
  private id?: number;

  constructor(
    private api: CollectionApiService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = +idParam;
      this.isEdit.set(true);
      this.api.findById(this.id).subscribe(data => this.model = data);
    }
  }

  save(): void {
    const obs = this.isEdit()
      ? this.api.update(this.id!, this.model)
      : this.api.create(this.model);

    obs.subscribe(() => {
      this.snackBar.open('Збережено', '', { duration: 2000 });
      this.router.navigate(['/collections']);
    });
  }
}
