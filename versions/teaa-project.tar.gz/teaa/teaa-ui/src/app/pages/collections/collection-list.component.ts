import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { StatusBadgeComponent } from '@shared/components/status-badge.component';
import { CollectionApiService, Collection } from '@shared/services/api.service';

@Component({
  selector: 'app-collection-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MatTableModule, MatButtonModule, MatIconModule, MatSnackBarModule, StatusBadgeComponent],
  template: `
    <div class="page-header">
      <h1 i18n="@@collectionsTitle">Колекції</h1>
      <a mat-flat-button color="primary" routerLink="/collections/new" i18n="@@collectionsCreate">Створити</a>
    </div>

    <table mat-table [dataSource]="items()" class="mat-elevation-z0">
      <ng-container matColumnDef="name">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColName">Назва</th>
        <td mat-cell *matCellDef="let item">{{ item.name }}</td>
      </ng-container>

      <ng-container matColumnDef="version">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColVersion">Версія</th>
        <td mat-cell *matCellDef="let item">{{ item.version }}</td>
      </ng-container>

      <ng-container matColumnDef="embeddingModel">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColModel">Модель</th>
        <td mat-cell *matCellDef="let item"><code>{{ item.embeddingModel }}</code></td>
      </ng-container>

      <ng-container matColumnDef="dimensions">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColDim">Dim</th>
        <td mat-cell *matCellDef="let item">{{ item.dimensions }}</td>
      </ng-container>

      <ng-container matColumnDef="chunkSize">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColChunk">Chunk</th>
        <td mat-cell *matCellDef="let item">{{ item.chunkSize }} / {{ item.chunkOverlap }}</td>
      </ng-container>

      <ng-container matColumnDef="status">
        <th mat-header-cell *matHeaderCellDef i18n="@@colColStatus">Статус</th>
        <td mat-cell *matCellDef="let item"><app-status-badge [status]="item.status" /></td>
      </ng-container>

      <ng-container matColumnDef="actions">
        <th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let item">
          <a mat-icon-button [routerLink]="['/collections', item.id]"><mat-icon>edit</mat-icon></a>
          <button mat-icon-button (click)="remove(item)" color="warn"><mat-icon>delete</mat-icon></button>
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.75rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
  `]
})
export class CollectionListComponent implements OnInit {
  items = signal<Collection[]>([]);
  columns = ['name', 'version', 'embeddingModel', 'dimensions', 'chunkSize', 'status', 'actions'];

  constructor(private api: CollectionApiService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.load();
  }

  remove(item: Collection): void {
    this.api.delete(item.id!).subscribe(() => {
      this.snackBar.open('Видалено', '', { duration: 2000 });
      this.load();
    });
  }

  private load(): void {
    this.api.findAll().subscribe(data => this.items.set(data));
  }
}
