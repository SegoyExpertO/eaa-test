import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSliderModule } from '@angular/material/slider';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import {
  SearchApiService, SearchResponse, ChunkResult,
  SourceApiService, Source, CollectionApiService, Collection
} from '@shared/services/api.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatFormFieldModule, MatInputModule,
    MatButtonModule, MatSliderModule, MatCardModule, MatProgressBarModule,
    MatSelectModule, MatSnackBarModule
  ],
  template: `
    <div class="page-header">
      <h1 i18n="@@searchTitle">Пошук</h1>
    </div>

    <div class="card search-card">
      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@searchEmbedding">Embedding (JSON array)</mat-label>
        <textarea matInput [(ngModel)]="embeddingText" rows="4" class="json-input"
                  placeholder="[0.1, 0.2, 0.3, ...]"></textarea>
      </mat-form-field>

      <div class="params-row">
        <mat-form-field appearance="outline">
          <mat-label>Top K</mat-label>
          <input matInput type="number" [(ngModel)]="topK" min="1" max="50">
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label i18n="@@searchThreshold">Threshold</mat-label>
          <input matInput type="number" [(ngModel)]="threshold" min="0" max="1" step="0.05">
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label i18n="@@searchSource">Джерело</mat-label>
          <mat-select [(ngModel)]="sourceId">
            <mat-option [value]="null" i18n="@@searchAllSources">Усі</mat-option>
            @for (s of sources(); track s.id) {
              <mat-option [value]="s.id">{{ s.name }}</mat-option>
            }
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label i18n="@@searchCollection">Колекція</mat-label>
          <mat-select [(ngModel)]="collectionId">
            <mat-option [value]="null" i18n="@@searchAllCollections">Усі</mat-option>
            @for (c of collections(); track c.id) {
              <mat-option [value]="c.id">{{ c.name }}</mat-option>
            }
          </mat-select>
        </mat-form-field>
      </div>

      <button mat-flat-button color="primary" (click)="search()" [disabled]="searching()" i18n="@@searchButton">
        Шукати
      </button>
    </div>

    @if (results().length > 0) {
      <div class="results">
        <h2 i18n="@@searchResults">Результати ({{ results().length }})</h2>
        @for (chunk of results(); track chunk.chunkId) {
          <mat-card class="result-card">
            <div class="result-header">
              <span class="chunk-id">#{{ chunk.chunkId }}</span>
              <span class="similarity">{{ (chunk.similarity * 100).toFixed(1) }}%</span>
              <mat-progress-bar mode="determinate" [value]="chunk.similarity * 100" />
            </div>
            <p class="result-content">{{ chunk.content | slice:0:300 }}</p>
            @if (chunk.metadata && objectKeys(chunk.metadata).length > 0) {
              <div class="result-meta">
                @for (key of objectKeys(chunk.metadata); track key) {
                  <span class="meta-tag">{{ key }}: {{ chunk.metadata[key] }}</span>
                }
              </div>
            }
          </mat-card>
        }
      </div>
    }
  `,
  styles: [`
    .search-card { max-width: 800px; margin-bottom: 24px; }
    .full-width { width: 100%; }
    .json-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .params-row { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; }
    .params-row mat-form-field { flex: 1; min-width: 120px; }
    .results { max-width: 800px; }
    .results h2 { font-size: 1.1rem; margin-bottom: 12px; }
    .result-card { margin-bottom: 12px; padding: 16px; background: var(--bg-surface); border: 1px solid var(--border-color); }
    .result-header { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
    .chunk-id { font-weight: 600; color: var(--text-secondary); }
    .similarity { font-weight: 600; color: var(--primary); min-width: 50px; }
    mat-progress-bar { flex: 1; }
    .result-content { font-size: 0.85rem; line-height: 1.5; color: var(--text-primary); margin-bottom: 8px; }
    .result-meta { display: flex; flex-wrap: wrap; gap: 6px; }
    .meta-tag {
      font-size: 0.7rem; padding: 2px 8px; border-radius: 10px;
      background: rgba(37,99,235,0.06); color: var(--text-secondary);
    }
  `]
})
export class SearchComponent {
  embeddingText = '';
  topK = 10;
  threshold = 0.7;
  sourceId: number | null = null;
  collectionId: number | null = null;
  results = signal<ChunkResult[]>([]);
  searching = signal(false);
  sources = signal<Source[]>([]);
  collections = signal<Collection[]>([]);
  objectKeys = Object.keys;

  constructor(
    private searchApi: SearchApiService,
    private sourceApi: SourceApiService,
    private collectionApi: CollectionApiService,
    private snackBar: MatSnackBar
  ) {
    this.sourceApi.findAll().subscribe(s => this.sources.set(s));
    this.collectionApi.findAll().subscribe(c => this.collections.set(c));
  }

  search(): void {
    let embedding: number[];
    try {
      embedding = JSON.parse(this.embeddingText);
      if (!Array.isArray(embedding)) throw new Error();
    } catch {
      this.snackBar.open('Невалідний JSON embedding', '', { duration: 3000 });
      return;
    }

    this.searching.set(true);
    this.searchApi.search({
      queries: [{ embedding, topK: this.topK }],
      threshold: this.threshold,
      sourceId: this.sourceId ?? undefined,
      collectionId: this.collectionId ?? undefined
    }).subscribe({
      next: (res: SearchResponse) => {
        const chunks = res.results.flatMap(r => r.chunks);
        this.results.set(chunks);
        this.searching.set(false);
      },
      error: () => {
        this.snackBar.open('Помилка пошуку', '', { duration: 3000 });
        this.searching.set(false);
      }
    });
  }
}
