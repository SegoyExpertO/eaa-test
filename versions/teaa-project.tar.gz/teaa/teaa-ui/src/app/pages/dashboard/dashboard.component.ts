import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { StatusApiService, SystemStatus, Job } from '@shared/services/api.service';
import { StatusBadgeComponent } from '@shared/components/status-badge.component';
import { interval, Subscription, switchMap } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule, MatProgressBarModule, StatusBadgeComponent],
  template: `
    <div class="page-header">
      <h1 i18n="@@dashboardTitle">Огляд системи</h1>
    </div>

    <div class="stats-grid">
      <mat-card class="stat-card">
        <mat-icon>download</mat-icon>
        <div class="stat-value">{{ status().runningDownloads }}</div>
        <div class="stat-label" i18n="@@dashboardActiveDownloads">Активних завантажень</div>
      </mat-card>
      <mat-card class="stat-card">
        <mat-icon>memory</mat-icon>
        <div class="stat-value">{{ status().runningEmbeds }}</div>
        <div class="stat-label" i18n="@@dashboardActiveEmbeds">Активних embedding</div>
      </mat-card>
      <mat-card class="stat-card">
        <mat-icon>queue</mat-icon>
        <div class="stat-value">{{ status().pendingJobs }}</div>
        <div class="stat-label" i18n="@@dashboardPendingJobs">У черзі</div>
      </mat-card>
      <mat-card class="stat-card">
        <mat-icon>storage</mat-icon>
        <div class="stat-value">{{ status().totalChunks }}</div>
        <div class="stat-label" i18n="@@dashboardTotalChunks">Чанків у базі</div>
      </mat-card>
      <mat-card class="stat-card">
        <mat-icon>{{ status().teiHealthy ? 'check_circle' : 'error' }}</mat-icon>
        <div class="stat-value" [class.healthy]="status().teiHealthy" [class.unhealthy]="!status().teiHealthy">
          {{ status().teiHealthy ? 'OK' : 'Недоступний' }}
        </div>
        <div class="stat-label" i18n="@@dashboardTeiStatus">TEI сервер</div>
      </mat-card>
    </div>

    <div class="recent-section">
      <h2 i18n="@@dashboardRecentJobs">Останні завдання</h2>
      <div class="jobs-list">
        @for (job of recentJobs(); track job.id) {
          <div class="job-row">
            <span class="job-id">#{{ job.id }}</span>
            <app-status-badge [status]="job.status ?? ''" />
            <span class="job-action">{{ job.action }}</span>
            @if (job.status === 'RUNNING') {
              <mat-progress-bar mode="determinate" [value]="job.progress ?? 0" />
            }
            <span class="job-date">{{ job.createdAt | date:'short' }}</span>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }
    .stat-card {
      padding: 20px;
      text-align: center;
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
    }
    .stat-card mat-icon { color: var(--primary); font-size: 2rem; width: 32px; height: 32px; }
    .stat-value { font-size: 1.75rem; font-weight: 700; margin: 8px 0 4px; }
    .stat-label { font-size: 0.8rem; color: var(--text-secondary); }
    .healthy { color: var(--success); }
    .unhealthy { color: var(--error); }
    .recent-section h2 { font-size: 1.1rem; margin-bottom: 12px; color: var(--text-primary); }
    .jobs-list { display: flex; flex-direction: column; gap: 8px; }
    .job-row {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      border-radius: 6px;
    }
    .job-id { font-weight: 600; color: var(--text-secondary); min-width: 40px; }
    .job-action { font-size: 0.85rem; }
    .job-date { margin-left: auto; font-size: 0.8rem; color: var(--text-secondary); }
    mat-progress-bar { flex: 1; max-width: 200px; }
  `]
})
export class DashboardComponent implements OnInit, OnDestroy {
  status = signal<SystemStatus>({ runningDownloads: 0, runningEmbeds: 0, pendingJobs: 0, totalChunks: 0, teiHealthy: false, recentJobs: [] });
  recentJobs = signal<Job[]>([]);
  private sub?: Subscription;

  constructor(private statusApi: StatusApiService) {}

  ngOnInit(): void {
    this.loadData();
    this.sub = interval(5000).pipe(switchMap(() => this.statusApi.getStatus()))
      .subscribe(s => {
        this.status.set(s);
        this.recentJobs.set(s.recentJobs ?? []);
      });
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  private loadData(): void {
    this.statusApi.getStatus().subscribe(s => {
      this.status.set(s);
      this.recentJobs.set(s.recentJobs ?? []);
    });
  }
}
