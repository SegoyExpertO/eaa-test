# TEAA — Tizen European Accessibility Auditor

Система для побудови та управління RAG-базою знань з підтримкою семантичного пошуку.

## Структура проєкту

```
teaa/
├── pom.xml                    # Батьківський Maven POM
├── Dockerfile                 # Docker образ для teaa-rag
├── docker-compose.yml         # Оркестрація: PostgreSQL + teaa-rag + teaa-ui
├── teaa-rag/                  # Backend сервіс (Java 21, Spring Boot 3.4, WebFlux)
│   ├── pom.xml
│   └── src/
│       ├── main/
│       │   ├── java/ua/teaa/rag/
│       │   │   ├── config/         # OpenAPI, конфігурація
│       │   │   ├── controller/     # REST контролери (8 шт.)
│       │   │   ├── dto/            # Search request/response
│       │   │   ├── entity/         # R2DBC сутності (7 шт.)
│       │   │   ├── repository/     # R2DBC репозиторії + VectorRepository
│       │   │   └── service/        # Бізнес-логіка, черга, TEI, download strategies
│       │   └── resources/
│       │       ├── application.yml
│       │       └── db/schema.sql   # DDL + seed data
│       └── test/                   # Unit-тести (8 шт.)
└── teaa-ui/                   # Frontend (Angular 19, Material, i18n)
    ├── package.json
    ├── angular.json            # i18n: uk (source) + en
    ├── Dockerfile              # node build → nginx
    ├── nginx.conf              # SPA + API proxy
    └── src/
        ├── app/
        │   ├── pages/              # 8 сторінок
        │   └── shared/             # API сервіси, компоненти, тема
        └── styles.scss             # Корпоративна тема (dark/light)
```

## Технологічний стек

### Backend
- Java 21, Spring Boot 3.4, WebFlux (reactive)
- Maven
- PostgreSQL 16 + pgvector
- R2DBC
- TEI (Text Embeddings Inference) — окремий сервер
- Jsoup 1.18.3, Apache PDFBox 3.0.3
- springdoc-openapi (Swagger)
- JUnit 5, Mockito, MockWebServer

### Frontend
- Angular 19+, Angular Material
- Standalone components, Signals API
- Angular i18n (UK + EN)
- Chart.js
- Docker (nginx)

## Запуск

### Docker Compose

```bash
# Встановити URL TEI-сервера
export TEI_BASE_URL=http://<tei-server>:8080

# Запуск
docker compose up -d

# UI:       http://localhost:4200
# API:      http://localhost:8082
# Swagger:  http://localhost:8082/swagger-ui.html
```

### Локальна розробка

```bash
# Backend
cd teaa-rag
mvn spring-boot:run

# Frontend
cd teaa-ui
npm install
npm start
# UI: http://localhost:4200 (proxy → localhost:8082)
```

### Тести

```bash
cd teaa-rag
mvn test
```

## REST API

| Група | Endpoints |
|---|---|
| Source Types | CRUD `/api/v1/source-types` |
| Sources | CRUD `/api/v1/sources`, `GET /{id}/chunks/count` |
| Jobs | CRUD `/api/v1/jobs`, `PUT /{id}/stop`, `PUT /{id}/resume` |
| Collections | CRUD `/api/v1/collections` |
| Settings | CRUD `/api/v1/settings`, `POST /reload` |
| Search | `POST /api/v1/search` |
| Export | `GET /api/v1/export?scope=all|collection|source&format=json|sql` |
| Import | `POST /api/v1/import` (multipart file) |
| Status | `GET /api/v1/status` |

Swagger UI: `http://localhost:8082/swagger-ui.html`

## Черга завдань

Два типи завдань з незалежними чергами:

- **DOWNLOAD** — завантаження документів, парсинг, нарізка на чанки
- **EMBED** — генерація embeddings через TEI, збереження в pgvector

Стани: `PENDING → RUNNING → COMPLETED | FAILED | STOPPED`

Параметри черги конфігуруються через `rag_settings` в БД та змінюються без перезапуску через API.

## Типи джерел

| Код | Опис | Стратегія |
|---|---|---|
| HTML_SITE | HTML-сторінки | WebClient + Jsoup |
| GIT_REPO | GitHub-репозиторій | GitHub API + raw download |
| PDF | PDF-документ | WebClient + PDFBox |
| LOCAL_FILES | Локальні файли | Files.walk |

Нові типи додаються через API + реалізація `DownloadStrategy` у коді.

## Конфігурація

Системні параметри зберігаються в таблиці `rag_settings` (key-value) і змінюються через API без перезапуску:

| Ключ | Значення | Опис |
|---|---|---|
| tei.base-url | http://localhost:8080 | URL TEI сервера |
| tei.batch-size | 32 | Розмір батчу |
| queue.max-concurrent-download | 2 | Max DOWNLOAD |
| queue.max-concurrent-embed | 1 | Max EMBED |
| search.default-top-k | 10 | Результатів пошуку |
| search.default-threshold | 0.7 | Мінімальна схожість |
| ui.default-locale | uk | Мова UI за замовчуванням |

## Експорт / Імпорт

Експорт RAG-бази у форматі JSON або SQL для переносу на інший інстанс PostgreSQL + pgvector.

```bash
# Експорт всього
curl -o dump.json "http://localhost:8082/api/v1/export?scope=all&format=json"

# Експорт колекції
curl -o col.sql "http://localhost:8082/api/v1/export?scope=collection&id=1&format=sql"

# Імпорт
curl -X POST -F "file=@dump.json" http://localhost:8082/api/v1/import
```

## Ліцензія

Proprietary
