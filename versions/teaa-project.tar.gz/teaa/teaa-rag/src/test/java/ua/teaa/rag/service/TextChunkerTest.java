package ua.teaa.rag.service;

import org.junit.jupiter.api.Test;
import ua.teaa.rag.service.download.TextChunker;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class TextChunkerTest {

    private final TextChunker chunker = new TextChunker();

    @Test
    void shouldReturnSingleChunkForShortText() {
        List<String> chunks = chunker.chunk("Short text", 100, 20);
        assertThat(chunks).hasSize(1);
        assertThat(chunks.getFirst()).isEqualTo("Short text");
    }

    @Test
    void shouldSplitLongText() {
        String text = "word ".repeat(100); // ~500 chars
        List<String> chunks = chunker.chunk(text.trim(), 200, 50);
        assertThat(chunks).hasSizeGreaterThan(1);
    }

    @Test
    void shouldReturnEmptyForBlankText() {
        assertThat(chunker.chunk("", 100, 20)).isEmpty();
        assertThat(chunker.chunk(null, 100, 20)).isEmpty();
        assertThat(chunker.chunk("   ", 100, 20)).isEmpty();
    }

    @Test
    void shouldNotLoseContent() {
        String text = "Alpha Beta Gamma Delta Epsilon Zeta Eta Theta Iota Kappa";
        List<String> chunks = chunker.chunk(text, 20, 5);

        // Всі слова мають бути присутні хоча б в одному чанку
        String allChunks = String.join(" ", chunks);
        for (String word : text.split(" ")) {
            assertThat(allChunks).contains(word);
        }
    }
}
