package ua.teaa.rag.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.rag.entity.RagCollection;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.entity.RagSourceType;
import ua.teaa.rag.repository.*;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.r2dbc.core.FetchSpec;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportServiceTest {

    @Mock
    private RagCollectionRepository collectionRepository;
    @Mock
    private RagSourceRepository sourceRepository;
    @Mock
    private RagSourceTypeRepository sourceTypeRepository;
    @Mock
    private RagChunkRepository chunkRepository;
    @Mock
    private DatabaseClient databaseClient;

    @InjectMocks
    private ExportService exportService;

    @Test
    void shouldRejectUnknownScope() {
        StepVerifier.create(exportService.exportJson("unknown", 1L))
                .expectError(IllegalArgumentException.class)
                .verify();
    }

    @Test
    void shouldExportAllCollections() {
        when(sourceTypeRepository.findAll()).thenReturn(Flux.empty());
        when(sourceRepository.findAll()).thenReturn(Flux.empty());
        when(collectionRepository.findAll()).thenReturn(Flux.empty());

        var execSpec = mock(DatabaseClient.GenericExecuteSpec.class);
        var fetchSpec = mock(FetchSpec.class);
        when(databaseClient.sql(anyString())).thenReturn(execSpec);
        when(execSpec.map(any())).thenReturn(fetchSpec);
        when(fetchSpec.all()).thenReturn(Flux.empty());

        StepVerifier.create(exportService.exportJson("all", null))
                .assertNext(data -> assertThat(data).isNotEmpty())
                .verifyComplete();
    }

    @Test
    void shouldExportSqlFormat() {
        when(sourceTypeRepository.findAll()).thenReturn(Flux.empty());
        when(sourceRepository.findAll()).thenReturn(Flux.empty());
        when(collectionRepository.findAll()).thenReturn(Flux.empty());

        var execSpec = mock(DatabaseClient.GenericExecuteSpec.class);
        var fetchSpec = mock(FetchSpec.class);
        when(databaseClient.sql(anyString())).thenReturn(execSpec);
        when(execSpec.map(any())).thenReturn(fetchSpec);
        when(fetchSpec.all()).thenReturn(Flux.empty());

        StepVerifier.create(exportService.exportSql("all", null))
                .assertNext(data -> {
                    String sql = new String(data);
                    assertThat(sql).contains("TEAA RAG Export");
                    assertThat(sql).contains("CREATE EXTENSION");
                })
                .verifyComplete();
    }
}
