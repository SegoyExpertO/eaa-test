package ua.teaa.rag.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.entity.RagSourceType;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class ConfigMergeServiceTest {

    private ConfigMergeService service;

    @BeforeEach
    void setUp() {
        service = new ConfigMergeService(new ObjectMapper());
    }

    @Test
    void shouldMergeAllThreeLevels() {
        var sourceType = RagSourceType.builder()
                .defaultConfig("{\"parser\": \"jsoup\", \"max_depth\": 2}")
                .build();
        var source = RagSource.builder()
                .config("{\"max_depth\": 5, \"language\": \"en\"}")
                .build();
        var job = RagJob.builder()
                .configOverride("{\"language\": \"uk\", \"chunk_size\": 1000}")
                .build();

        Map<String, Object> result = service.merge(sourceType, source, job);

        assertThat(result).containsEntry("parser", "jsoup");
        assertThat(result).containsEntry("max_depth", 5);
        assertThat(result).containsEntry("language", "uk");
        assertThat(result).containsEntry("chunk_size", 1000);
    }

    @Test
    void shouldHandleNullOverride() {
        var sourceType = RagSourceType.builder()
                .defaultConfig("{\"parser\": \"jsoup\"}")
                .build();
        var source = RagSource.builder()
                .config("{\"language\": \"en\"}")
                .build();
        var job = RagJob.builder().build();

        Map<String, Object> result = service.merge(sourceType, source, job);

        assertThat(result).containsEntry("parser", "jsoup");
        assertThat(result).containsEntry("language", "en");
        assertThat(result).hasSize(2);
    }

    @Test
    void shouldHandleEmptyConfigs() {
        var sourceType = RagSourceType.builder().defaultConfig("{}").build();
        var source = RagSource.builder().config(null).build();
        var job = RagJob.builder().build();

        Map<String, Object> result = service.merge(sourceType, source, job);

        assertThat(result).isEmpty();
    }

    @Test
    void shouldHandleInvalidJson() {
        var sourceType = RagSourceType.builder().defaultConfig("not-json").build();
        var source = RagSource.builder().config("{\"key\": \"value\"}").build();
        var job = RagJob.builder().build();

        Map<String, Object> result = service.merge(sourceType, source, job);

        assertThat(result).containsEntry("key", "value");
    }
}
