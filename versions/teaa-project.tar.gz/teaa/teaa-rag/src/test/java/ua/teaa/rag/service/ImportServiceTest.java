package ua.teaa.rag.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.r2dbc.core.DatabaseClient;
import reactor.test.StepVerifier;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class ImportServiceTest {

    @Mock
    private DatabaseClient databaseClient;

    @InjectMocks
    private ImportService importService;

    @Test
    void shouldHandleEmptyJsonImport() {
        byte[] data = "{\"exportType\": \"all\", \"chunks\": []}".getBytes();

        StepVerifier.create(importService.importJson(data))
                .assertNext(result -> {
                    assertThat(result.get("status")).isEqualTo("EMPTY");
                    assertThat(result.get("imported")).isEqualTo(0);
                })
                .verifyComplete();
    }

    @Test
    void shouldHandleInvalidJson() {
        byte[] data = "not-json".getBytes();

        StepVerifier.create(importService.importJson(data))
                .assertNext(result -> {
                    assertThat(result.get("status")).isEqualTo("ERROR");
                })
                .verifyComplete();
    }

    @Test
    void shouldHandleNullChunks() {
        byte[] data = "{\"exportType\": \"all\"}".getBytes();

        StepVerifier.create(importService.importJson(data))
                .assertNext(result -> {
                    assertThat(result.get("status")).isEqualTo("EMPTY");
                })
                .verifyComplete();
    }
}
