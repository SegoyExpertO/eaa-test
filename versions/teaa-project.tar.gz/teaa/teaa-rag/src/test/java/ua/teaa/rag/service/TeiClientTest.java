package ua.teaa.rag.service;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TeiClientTest {

    private MockWebServer mockServer;
    private TeiClient teiClient;
    private SettingsService settings;

    @BeforeEach
    void setUp() throws IOException {
        mockServer = new MockWebServer();
        mockServer.start();

        settings = mock(SettingsService.class);
        when(settings.getTeiBaseUrl()).thenReturn(mockServer.url("/").toString());
        when(settings.getTeiBatchSize()).thenReturn(32);
        when(settings.getTeiTimeoutSeconds()).thenReturn(10L);

        teiClient = new TeiClient(settings, WebClient.builder());
    }

    @AfterEach
    void tearDown() throws IOException {
        mockServer.shutdown();
    }

    @Test
    void shouldReturnEmbeddings() {
        mockServer.enqueue(new MockResponse()
                .setBody("[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]")
                .addHeader("Content-Type", "application/json"));

        StepVerifier.create(teiClient.embed(List.of("text1", "text2")))
                .assertNext(result -> assertThat(result).hasSize(2))
                .verifyComplete();
    }

    @Test
    void shouldHandleServerError() {
        mockServer.enqueue(new MockResponse().setResponseCode(500));

        StepVerifier.create(teiClient.embed(List.of("text")))
                .expectError()
                .verify();
    }

    @Test
    void shouldCheckHealth() {
        mockServer.enqueue(new MockResponse().setResponseCode(200));

        StepVerifier.create(teiClient.isHealthy())
                .assertNext(healthy -> assertThat(healthy).isTrue())
                .verifyComplete();
    }

    @Test
    void shouldReturnUnhealthyOnError() {
        mockServer.enqueue(new MockResponse().setResponseCode(503));

        StepVerifier.create(teiClient.isHealthy())
                .assertNext(healthy -> assertThat(healthy).isFalse())
                .verifyComplete();
    }

    @Test
    void shouldReturnBatchSizeFromSettings() {
        when(settings.getTeiBatchSize()).thenReturn(64);
        assertThat(teiClient.getBatchSize()).isEqualTo(64);
    }
}
