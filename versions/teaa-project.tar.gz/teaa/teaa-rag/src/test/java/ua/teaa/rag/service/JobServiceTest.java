package ua.teaa.rag.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagJobRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JobServiceTest {

    @Mock
    private RagJobRepository repository;

    @InjectMocks
    private JobService service;

    @Test
    void shouldCreateJobWithPendingStatus() {
        var job = RagJob.builder()
                .sourceId(1L)
                .action("DOWNLOAD")
                .build();

        when(repository.save(any(RagJob.class))).thenAnswer(inv -> {
            RagJob saved = inv.getArgument(0);
            saved.setId(1L);
            return Mono.just(saved);
        });

        StepVerifier.create(service.create(job))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("PENDING");
                    assertThat(result.getProgress()).isEqualTo(0);
                })
                .verifyComplete();
    }

    @Test
    void shouldStopRunningJob() {
        var job = RagJob.builder().id(1L).status("RUNNING").build();

        when(repository.findById(1L)).thenReturn(Mono.just(job));
        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.stop(1L))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("STOPPED");
                    assertThat(result.getCompletedAt()).isNotNull();
                })
                .verifyComplete();
    }

    @Test
    void shouldNotStopCompletedJob() {
        var job = RagJob.builder().id(1L).status("COMPLETED").build();

        when(repository.findById(1L)).thenReturn(Mono.just(job));

        StepVerifier.create(service.stop(1L))
                .verifyComplete();
    }

    @Test
    void shouldResumeStoppedJob() {
        var job = RagJob.builder().id(1L).status("STOPPED").errorMessage("old error").build();

        when(repository.findById(1L)).thenReturn(Mono.just(job));
        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.resume(1L))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("PENDING");
                    assertThat(result.getErrorMessage()).isNull();
                    assertThat(result.getStartedAt()).isNull();
                })
                .verifyComplete();
    }

    @Test
    void shouldResumeFailedJob() {
        var job = RagJob.builder().id(1L).status("FAILED").build();

        when(repository.findById(1L)).thenReturn(Mono.just(job));
        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.resume(1L))
                .assertNext(result -> assertThat(result.getStatus()).isEqualTo("PENDING"))
                .verifyComplete();
    }

    @Test
    void shouldUpdateAndRestart() {
        var existing = RagJob.builder()
                .id(1L).status("FAILED").progress(50).processedItems(25).errorMessage("timeout")
                .build();
        var updated = RagJob.builder().configOverride("{\"chunk_size\": 500}").build();

        when(repository.findById(1L)).thenReturn(Mono.just(existing));
        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.updateAndRestart(1L, updated))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("PENDING");
                    assertThat(result.getProgress()).isEqualTo(0);
                    assertThat(result.getProcessedItems()).isEqualTo(0);
                    assertThat(result.getErrorMessage()).isNull();
                    assertThat(result.getConfigOverride()).isEqualTo("{\"chunk_size\": 500}");
                })
                .verifyComplete();
    }

    @Test
    void shouldUpdateProgress() {
        var job = RagJob.builder().id(1L).build();

        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.updateProgress(job, 30, 100))
                .assertNext(result -> {
                    assertThat(result.getProcessedItems()).isEqualTo(30);
                    assertThat(result.getTotalItems()).isEqualTo(100);
                    assertThat(result.getProgress()).isEqualTo(30);
                })
                .verifyComplete();
    }

    @Test
    void shouldMarkCompleted() {
        var job = RagJob.builder().id(1L).build();

        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.markCompleted(job))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("COMPLETED");
                    assertThat(result.getProgress()).isEqualTo(100);
                    assertThat(result.getCompletedAt()).isNotNull();
                })
                .verifyComplete();
    }

    @Test
    void shouldMarkFailed() {
        var job = RagJob.builder().id(1L).build();

        when(repository.save(any(RagJob.class))).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.markFailed(job, "Connection refused"))
                .assertNext(result -> {
                    assertThat(result.getStatus()).isEqualTo("FAILED");
                    assertThat(result.getErrorMessage()).isEqualTo("Connection refused");
                })
                .verifyComplete();
    }
}
