package ua.teaa.rag.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.rag.dto.SearchRequest;
import ua.teaa.rag.dto.SearchResponse.ChunkResult;
import ua.teaa.rag.repository.VectorRepository;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SearchServiceTest {

    @Mock
    private VectorRepository vectorRepository;

    @Mock
    private SettingsService settings;

    private SearchService service;

    @BeforeEach
    void setUp() {
        when(settings.getDefaultTopK()).thenReturn(10);
        when(settings.getDefaultThreshold()).thenReturn(0.7);
        service = new SearchService(vectorRepository, settings);
    }

    @Test
    void shouldReturnEmptyForNoQueries() {
        var request = SearchRequest.builder().queries(List.of()).build();

        StepVerifier.create(service.search(request))
                .assertNext(response -> assertThat(response.getResults()).isEmpty())
                .verifyComplete();
    }

    @Test
    void shouldSearchSingleQuery() {
        var embedding = List.of(0.1f, 0.2f, 0.3f);
        var request = SearchRequest.builder()
                .queries(List.of(SearchRequest.SearchQuery.builder().embedding(embedding).build()))
                .build();

        var chunk = ChunkResult.builder()
                .chunkId(1L).content("test").similarity(0.85).sourceId(1L).metadata(Map.of())
                .build();

        when(vectorRepository.search(eq(embedding), eq(10), eq(0.7), isNull(), isNull()))
                .thenReturn(Mono.just(List.of(chunk)));

        StepVerifier.create(service.search(request))
                .assertNext(response -> {
                    assertThat(response.getResults()).hasSize(1);
                    assertThat(response.getResults().getFirst().getChunks()).hasSize(1);
                })
                .verifyComplete();
    }

    @Test
    void shouldOverrideDefaults() {
        var embedding = List.of(0.1f, 0.2f);
        var request = SearchRequest.builder()
                .queries(List.of(SearchRequest.SearchQuery.builder().embedding(embedding).topK(5).build()))
                .threshold(0.8)
                .sourceId(2L)
                .collectionId(3L)
                .build();

        when(vectorRepository.search(eq(embedding), eq(5), eq(0.8), eq(2L), eq(3L)))
                .thenReturn(Mono.just(List.of()));

        StepVerifier.create(service.search(request))
                .assertNext(response -> assertThat(response.getResults().getFirst().getChunks()).isEmpty())
                .verifyComplete();
    }

    @Test
    void shouldSearchMultipleQueries() {
        var emb1 = List.of(0.1f, 0.2f);
        var emb2 = List.of(0.3f, 0.4f);
        var request = SearchRequest.builder()
                .queries(List.of(
                        SearchRequest.SearchQuery.builder().embedding(emb1).build(),
                        SearchRequest.SearchQuery.builder().embedding(emb2).topK(3).build()))
                .build();

        when(vectorRepository.search(eq(emb1), eq(10), eq(0.7), isNull(), isNull()))
                .thenReturn(Mono.just(List.of(ChunkResult.builder().chunkId(1L).content("c1").similarity(0.9).build())));
        when(vectorRepository.search(eq(emb2), eq(3), eq(0.7), isNull(), isNull()))
                .thenReturn(Mono.just(List.of(
                        ChunkResult.builder().chunkId(2L).content("c2").similarity(0.8).build(),
                        ChunkResult.builder().chunkId(3L).content("c3").similarity(0.75).build())));

        StepVerifier.create(service.search(request))
                .assertNext(response -> {
                    assertThat(response.getResults()).hasSize(2);
                    assertThat(response.getResults().get(0).getChunks()).hasSize(1);
                    assertThat(response.getResults().get(1).getChunks()).hasSize(2);
                })
                .verifyComplete();
    }
}
