package ua.teaa.rag.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.entity.RagSourceType;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ConfigMergeService {

    private final ObjectMapper objectMapper;

    /**
     * Мержить конфігурацію з трьох рівнів:
     * source_type.default_config < source.config < job.config_override
     */
    public Map<String, Object> merge(RagSourceType sourceType, RagSource source, RagJob job) {
        Map<String, Object> result = new HashMap<>();
        result.putAll(parseJson(sourceType.getDefaultConfig()));
        result.putAll(parseJson(source.getConfig()));
        if (job.getConfigOverride() != null) {
            result.putAll(parseJson(job.getConfigOverride()));
        }
        return result;
    }

    private Map<String, Object> parseJson(String json) {
        if (json == null || json.isBlank()) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            log.warn("Помилка парсингу JSON конфігурації: {}", e.getMessage());
            return Map.of();
        }
    }
}
