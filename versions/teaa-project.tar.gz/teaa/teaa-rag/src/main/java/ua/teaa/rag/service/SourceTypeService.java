package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSourceType;
import ua.teaa.rag.repository.RagSourceTypeRepository;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class SourceTypeService {

    private final RagSourceTypeRepository repository;

    public Flux<RagSourceType> findAll() {
        return repository.findAll();
    }

    public Mono<RagSourceType> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<RagSourceType> create(RagSourceType sourceType) {
        sourceType.setCreatedAt(LocalDateTime.now());
        sourceType.setUpdatedAt(LocalDateTime.now());
        return repository.save(sourceType);
    }

    public Mono<RagSourceType> update(Long id, RagSourceType updated) {
        return repository.findById(id)
                .flatMap(existing -> {
                    existing.setCode(updated.getCode());
                    existing.setName(updated.getName());
                    existing.setDescription(updated.getDescription());
                    existing.setDefaultConfig(updated.getDefaultConfig());
                    existing.setUpdatedAt(LocalDateTime.now());
                    return repository.save(existing);
                });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id);
    }
}
