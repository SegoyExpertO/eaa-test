package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSetting;
import ua.teaa.rag.service.SettingsService;

import java.util.Map;

@Tag(name = "Settings", description = "Системні налаштування")
@RestController
@RequestMapping("/api/v1/settings")
@RequiredArgsConstructor
public class SettingsController {

    private final SettingsService service;

    @GetMapping
    public Flux<RagSetting> findAll() {
        return service.findAll();
    }

    @GetMapping("/{key}")
    public Mono<RagSetting> findByKey(@PathVariable String key) {
        return service.findByKey(key);
    }

    @PutMapping("/{key}")
    public Mono<RagSetting> update(@PathVariable String key, @RequestBody Map<String, String> body) {
        return service.update(key, body.get("value"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagSetting> create(@RequestBody RagSetting setting) {
        return service.create(setting);
    }

    @DeleteMapping("/{key}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable String key) {
        return service.delete(key);
    }

    @PostMapping("/reload")
    public Mono<Void> reload() {
        return service.reloadCache();
    }
}
