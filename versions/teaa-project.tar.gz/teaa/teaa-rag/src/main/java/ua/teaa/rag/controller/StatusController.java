package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagChunkRepository;
import ua.teaa.rag.repository.RagJobRepository;
import ua.teaa.rag.service.JobService;
import ua.teaa.rag.service.TeiClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Tag(name = "Status", description = "Стан системи")
@RestController
@RequestMapping("/api/v1/status")
@RequiredArgsConstructor
public class StatusController {

    private final RagJobRepository jobRepository;
    private final RagChunkRepository chunkRepository;
    private final JobService jobService;
    private final TeiClient teiClient;

    @GetMapping
    public Mono<Map<String, Object>> status() {
        return Mono.zip(
                jobRepository.countRunningByAction("DOWNLOAD"),
                jobRepository.countRunningByAction("EMBED"),
                jobRepository.findByStatus("PENDING").count(),
                chunkRepository.count(),
                teiClient.isHealthy(),
                jobService.findRecent(10).collectList()
        ).map(tuple -> {
            Map<String, Object> result = new HashMap<>();
            result.put("runningDownloads", tuple.getT1());
            result.put("runningEmbeds", tuple.getT2());
            result.put("pendingJobs", tuple.getT3());
            result.put("totalChunks", tuple.getT4());
            result.put("teiHealthy", tuple.getT5());
            result.put("recentJobs", tuple.getT6());
            return result;
        });
    }
}
