package ua.teaa.rag.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagCollection;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.entity.RagSourceType;
import ua.teaa.rag.repository.*;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExportService {

    private final RagCollectionRepository collectionRepository;
    private final RagSourceRepository sourceRepository;
    private final RagSourceTypeRepository sourceTypeRepository;
    private final RagChunkRepository chunkRepository;
    private final DatabaseClient databaseClient;

    /**
     * Експорт у JSON.
     */
    public Mono<byte[]> exportJson(String scope, Long id) {
        return buildExportData(scope, id).map(data -> {
            try {
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new JavaTimeModule());
                mapper.enable(SerializationFeature.INDENT_OUTPUT);
                mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                return mapper.writeValueAsBytes(data);
            } catch (Exception e) {
                throw new RuntimeException("Помилка серіалізації JSON: " + e.getMessage(), e);
            }
        });
    }

    /**
     * Експорт у SQL.
     */
    public Mono<byte[]> exportSql(String scope, Long id) {
        return buildSqlDump(scope, id).map(String::getBytes);
    }

    private Mono<Map<String, Object>> buildExportData(String scope, Long id) {
        return switch (scope) {
            case "collection" -> exportCollection(id);
            case "source" -> exportSource(id);
            case "all" -> exportAll();
            default -> Mono.error(new IllegalArgumentException("Невідомий scope: " + scope));
        };
    }

    private Mono<Map<String, Object>> exportCollection(Long collectionId) {
        return collectionRepository.findById(collectionId)
                .flatMap(collection -> databaseClient.sql(
                                "SELECT id, source_id, collection_id, content, embedding::text as embedding_text, metadata, created_at " +
                                        "FROM rag_chunks WHERE collection_id = :collectionId")
                        .bind("collectionId", collectionId)
                        .map((row, meta) -> {
                            Map<String, Object> chunk = new LinkedHashMap<>();
                            chunk.put("id", row.get("id", Long.class));
                            chunk.put("sourceId", row.get("source_id", Long.class));
                            chunk.put("collectionId", row.get("collection_id", Long.class));
                            chunk.put("content", row.get("content", String.class));
                            chunk.put("embedding", row.get("embedding_text", String.class));
                            chunk.put("metadata", row.get("metadata", String.class));
                            chunk.put("createdAt", row.get("created_at", LocalDateTime.class));
                            return chunk;
                        })
                        .all()
                        .collectList()
                        .map(chunks -> {
                            Map<String, Object> data = new LinkedHashMap<>();
                            data.put("exportType", "collection");
                            data.put("exportedAt", LocalDateTime.now().toString());
                            data.put("collection", collection);
                            data.put("chunks", chunks);
                            data.put("totalChunks", chunks.size());
                            return data;
                        })
                );
    }

    private Mono<Map<String, Object>> exportSource(Long sourceId) {
        return sourceRepository.findById(sourceId)
                .flatMap(source -> sourceTypeRepository.findById(source.getTypeId())
                        .flatMap(sourceType -> fetchChunksBySource(sourceId)
                                .map(chunks -> {
                                    Map<String, Object> data = new LinkedHashMap<>();
                                    data.put("exportType", "source");
                                    data.put("exportedAt", LocalDateTime.now().toString());
                                    data.put("sourceType", sourceType);
                                    data.put("source", source);
                                    data.put("chunks", chunks);
                                    data.put("totalChunks", chunks.size());
                                    return data;
                                })
                        )
                );
    }

    private Mono<Map<String, Object>> exportAll() {
        return Mono.zip(
                sourceTypeRepository.findAll().collectList(),
                sourceRepository.findAll().collectList(),
                collectionRepository.findAll().collectList(),
                fetchAllChunks()
        ).map(tuple -> {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("exportType", "all");
            data.put("exportedAt", LocalDateTime.now().toString());
            data.put("sourceTypes", tuple.getT1());
            data.put("sources", tuple.getT2());
            data.put("collections", tuple.getT3());
            data.put("chunks", tuple.getT4());
            data.put("totalChunks", tuple.getT4().size());
            return data;
        });
    }

    private Mono<List<Map<String, Object>>> fetchChunksBySource(Long sourceId) {
        return databaseClient.sql(
                        "SELECT id, source_id, collection_id, content, embedding::text as embedding_text, metadata, created_at " +
                                "FROM rag_chunks WHERE source_id = :sourceId")
                .bind("sourceId", sourceId)
                .map((row, meta) -> mapChunkRow(row))
                .all()
                .collectList();
    }

    private Mono<List<Map<String, Object>>> fetchAllChunks() {
        return databaseClient.sql(
                        "SELECT id, source_id, collection_id, content, embedding::text as embedding_text, metadata, created_at FROM rag_chunks")
                .map((row, meta) -> mapChunkRow(row))
                .all()
                .collectList();
    }

    private Map<String, Object> mapChunkRow(io.r2dbc.spi.Readable row) {
        Map<String, Object> chunk = new LinkedHashMap<>();
        chunk.put("id", row.get("id", Long.class));
        chunk.put("sourceId", row.get("source_id", Long.class));
        chunk.put("collectionId", row.get("collection_id", Long.class));
        chunk.put("content", row.get("content", String.class));
        chunk.put("embedding", row.get("embedding_text", String.class));
        chunk.put("metadata", row.get("metadata", String.class));
        chunk.put("createdAt", row.get("created_at", LocalDateTime.class));
        return chunk;
    }

    // --- SQL dump ---

    private Mono<String> buildSqlDump(String scope, Long id) {
        return buildExportData(scope, id).map(this::convertToSql);
    }

    @SuppressWarnings("unchecked")
    private String convertToSql(Map<String, Object> data) {
        StringBuilder sql = new StringBuilder();
        sql.append("-- TEAA RAG Export\n");
        sql.append("-- Type: ").append(data.get("exportType")).append("\n");
        sql.append("-- Date: ").append(data.get("exportedAt")).append("\n");
        sql.append("-- Total chunks: ").append(data.get("totalChunks")).append("\n\n");
        sql.append("CREATE EXTENSION IF NOT EXISTS vector;\n\n");

        // Source types
        if (data.containsKey("sourceTypes")) {
            List<RagSourceType> types = (List<RagSourceType>) data.get("sourceTypes");
            for (RagSourceType t : types) {
                sql.append(String.format(
                        "INSERT INTO rag_source_types (id, code, name, description, default_config) VALUES (%d, '%s', '%s', '%s', '%s') ON CONFLICT (id) DO NOTHING;\n",
                        t.getId(), escape(t.getCode()), escape(t.getName()),
                        escape(t.getDescription()), escape(t.getDefaultConfig())));
            }
            sql.append("\n");
        }

        // Sources
        if (data.containsKey("sources")) {
            List<RagSource> sources = (List<RagSource>) data.get("sources");
            for (RagSource s : sources) {
                sql.append(String.format(
                        "INSERT INTO rag_sources (id, name, description, type_id, location, config, status) VALUES (%d, '%s', '%s', %d, '%s', '%s', '%s') ON CONFLICT (id) DO NOTHING;\n",
                        s.getId(), escape(s.getName()), escape(s.getDescription()),
                        s.getTypeId(), escape(s.getLocation()), escape(s.getConfig()), s.getStatus()));
            }
            sql.append("\n");
        }

        // Single source/sourceType
        if (data.containsKey("sourceType") && data.get("sourceType") instanceof RagSourceType t) {
            sql.append(String.format(
                    "INSERT INTO rag_source_types (id, code, name, description, default_config) VALUES (%d, '%s', '%s', '%s', '%s') ON CONFLICT (id) DO NOTHING;\n\n",
                    t.getId(), escape(t.getCode()), escape(t.getName()),
                    escape(t.getDescription()), escape(t.getDefaultConfig())));
        }
        if (data.containsKey("source") && data.get("source") instanceof RagSource s) {
            sql.append(String.format(
                    "INSERT INTO rag_sources (id, name, description, type_id, location, config, status) VALUES (%d, '%s', '%s', %d, '%s', '%s', '%s') ON CONFLICT (id) DO NOTHING;\n\n",
                    s.getId(), escape(s.getName()), escape(s.getDescription()),
                    s.getTypeId(), escape(s.getLocation()), escape(s.getConfig()), s.getStatus()));
        }

        // Collections
        if (data.containsKey("collections")) {
            List<RagCollection> cols = (List<RagCollection>) data.get("collections");
            for (RagCollection c : cols) {
                appendCollectionSql(sql, c);
            }
            sql.append("\n");
        }
        if (data.containsKey("collection") && data.get("collection") instanceof RagCollection c) {
            appendCollectionSql(sql, c);
            sql.append("\n");
        }

        // Chunks
        List<Map<String, Object>> chunks = (List<Map<String, Object>>) data.get("chunks");
        if (chunks != null) {
            for (Map<String, Object> chunk : chunks) {
                String embedding = chunk.get("embedding") != null
                        ? "'" + chunk.get("embedding") + "'::vector"
                        : "NULL";
                sql.append(String.format(
                        "INSERT INTO rag_chunks (id, source_id, collection_id, content, embedding, metadata) VALUES (%s, %s, %s, '%s', %s, '%s') ON CONFLICT (id) DO NOTHING;\n",
                        chunk.get("id"), chunk.get("sourceId"),
                        chunk.get("collectionId") != null ? chunk.get("collectionId") : "NULL",
                        escape(String.valueOf(chunk.get("content"))),
                        embedding,
                        escape(String.valueOf(chunk.get("metadata")))));
            }
        }

        return sql.toString();
    }

    private void appendCollectionSql(StringBuilder sql, RagCollection c) {
        sql.append(String.format(
                "INSERT INTO rag_collections (id, name, description, version, embedding_model, dimensions, chunk_size, chunk_overlap, tei_base_url, status) " +
                        "VALUES (%d, '%s', '%s', '%s', '%s', %d, %d, %d, '%s', '%s') ON CONFLICT (id) DO NOTHING;\n",
                c.getId(), escape(c.getName()), escape(c.getDescription()),
                escape(c.getVersion()), escape(c.getEmbeddingModel()),
                c.getDimensions(), c.getChunkSize(), c.getChunkOverlap(),
                escape(c.getTeiBaseUrl()), c.getStatus()));
    }

    private String escape(String val) {
        if (val == null) return "";
        return val.replace("'", "''");
    }
}
