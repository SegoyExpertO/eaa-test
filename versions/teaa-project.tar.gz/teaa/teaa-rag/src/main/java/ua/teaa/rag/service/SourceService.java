package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.repository.RagSourceRepository;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class SourceService {

    private final RagSourceRepository repository;

    public Flux<RagSource> findAll() {
        return repository.findAll();
    }

    public Mono<RagSource> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<RagSource> create(RagSource source) {
        source.setStatus(RagSource.Status.REGISTERED.name());
        source.setCreatedAt(LocalDateTime.now());
        source.setUpdatedAt(LocalDateTime.now());
        return repository.save(source);
    }

    public Mono<RagSource> update(Long id, RagSource updated) {
        return repository.findById(id)
                .flatMap(existing -> {
                    existing.setName(updated.getName());
                    existing.setDescription(updated.getDescription());
                    existing.setTypeId(updated.getTypeId());
                    existing.setLocation(updated.getLocation());
                    existing.setConfig(updated.getConfig());
                    existing.setUpdatedAt(LocalDateTime.now());
                    return repository.save(existing);
                });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id);
    }
}
