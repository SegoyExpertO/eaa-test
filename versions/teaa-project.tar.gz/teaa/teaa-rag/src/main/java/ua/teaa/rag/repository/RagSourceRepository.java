package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import ua.teaa.rag.entity.RagSource;

public interface RagSourceRepository extends R2dbcRepository<RagSource, Long> {
    Flux<RagSource> findByTypeId(Long typeId);
}
