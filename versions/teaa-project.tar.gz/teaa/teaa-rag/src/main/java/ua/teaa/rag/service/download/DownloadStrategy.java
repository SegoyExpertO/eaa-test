package ua.teaa.rag.service.download;

import reactor.core.publisher.Flux;
import ua.teaa.rag.entity.RagSource;

import java.util.Map;

/**
 * Стратегія завантаження та парсингу документів для конкретного типу джерела.
 */
public interface DownloadStrategy {

    /**
     * Код типу джерела, який ця стратегія обслуговує.
     */
    String getSourceTypeCode();

    /**
     * Завантажує та парсить документи з джерела.
     *
     * @param source  джерело
     * @param config  effective config (merged)
     * @return потік чанків (content + metadata)
     */
    Flux<ChunkData> download(RagSource source, Map<String, Object> config);

    /**
     * Результат парсингу — текст чанка + метадані.
     */
    record ChunkData(String content, Map<String, Object> metadata) {}
}
