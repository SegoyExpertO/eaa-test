package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.dto.SearchRequest;
import ua.teaa.rag.dto.SearchResponse;
import ua.teaa.rag.dto.SearchResponse.QueryResult;
import ua.teaa.rag.repository.VectorRepository;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SearchService {

    private final VectorRepository vectorRepository;
    private final SettingsService settings;

    public Mono<SearchResponse> search(SearchRequest request) {
        if (request.getQueries() == null || request.getQueries().isEmpty()) {
            return Mono.just(SearchResponse.builder().results(List.of()).build());
        }

        double threshold = request.getThreshold() != null
                ? request.getThreshold()
                : settings.getDefaultThreshold();
        Long sourceId = request.getSourceId();
        Long collectionId = request.getCollectionId();

        log.info("Пошук: {} запитів, threshold={}, sourceId={}, collectionId={}",
                request.getQueries().size(), threshold, sourceId, collectionId);

        return Flux.range(0, request.getQueries().size())
                .flatMapSequential(index -> {
                    SearchRequest.SearchQuery query = request.getQueries().get(index);
                    int topK = query.getTopK() != null
                            ? query.getTopK()
                            : settings.getDefaultTopK();

                    return vectorRepository.search(query.getEmbedding(), topK, threshold, sourceId, collectionId)
                            .map(chunks -> QueryResult.builder()
                                    .queryIndex(index)
                                    .chunks(chunks)
                                    .build());
                })
                .collectList()
                .map(results -> {
                    int totalChunks = results.stream()
                            .mapToInt(r -> r.getChunks().size())
                            .sum();
                    log.info("Пошук завершено: {} запитів, {} чанків знайдено", results.size(), totalChunks);
                    return SearchResponse.builder().results(results).build();
                });
    }
}
