package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSourceType;

public interface RagSourceTypeRepository extends R2dbcRepository<RagSourceType, Long> {
    Mono<RagSourceType> findByCode(String code);
    Mono<Boolean> existsByCode(String code);
}
