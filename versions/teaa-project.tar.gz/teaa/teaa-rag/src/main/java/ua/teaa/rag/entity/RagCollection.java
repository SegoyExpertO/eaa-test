package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_collections")
public class RagCollection {

    @Id
    private Long id;
    private String name;
    private String description;
    private String version;
    private String embeddingModel;
    private Integer dimensions;
    private Integer chunkSize;
    private Integer chunkOverlap;
    private String teiBaseUrl;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public enum Status {
        CREATING, READY, ERROR
    }
}
