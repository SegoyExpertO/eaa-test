package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import ua.teaa.rag.dto.SearchRequest;
import ua.teaa.rag.dto.SearchResponse;
import ua.teaa.rag.service.SearchService;

@Tag(name = "Search", description = "Семантичний пошук по базі знань")
@RestController
@RequestMapping("/api/v1/search")
@RequiredArgsConstructor
public class SearchController {

    private final SearchService searchService;

    @PostMapping
    public Mono<SearchResponse> search(@RequestBody SearchRequest request) {
        return searchService.search(request);
    }
}
