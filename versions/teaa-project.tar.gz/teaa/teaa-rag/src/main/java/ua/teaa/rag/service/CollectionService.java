package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagCollection;
import ua.teaa.rag.repository.RagCollectionRepository;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class CollectionService {

    private final RagCollectionRepository repository;

    public Flux<RagCollection> findAll() {
        return repository.findAll();
    }

    public Mono<RagCollection> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<RagCollection> create(RagCollection collection) {
        collection.setStatus(RagCollection.Status.CREATING.name());
        collection.setCreatedAt(LocalDateTime.now());
        collection.setUpdatedAt(LocalDateTime.now());
        return repository.save(collection);
    }

    public Mono<RagCollection> update(Long id, RagCollection updated) {
        return repository.findById(id)
                .flatMap(existing -> {
                    existing.setName(updated.getName());
                    existing.setDescription(updated.getDescription());
                    existing.setVersion(updated.getVersion());
                    existing.setEmbeddingModel(updated.getEmbeddingModel());
                    existing.setDimensions(updated.getDimensions());
                    existing.setChunkSize(updated.getChunkSize());
                    existing.setChunkOverlap(updated.getChunkOverlap());
                    existing.setTeiBaseUrl(updated.getTeiBaseUrl());
                    existing.setUpdatedAt(LocalDateTime.now());
                    return repository.save(existing);
                });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id);
    }
}
