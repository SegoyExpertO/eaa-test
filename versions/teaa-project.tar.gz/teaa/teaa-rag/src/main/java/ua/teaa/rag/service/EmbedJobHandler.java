package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagChunk;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagChunkRepository;
import ua.teaa.rag.repository.VectorRepository;

import java.util.List;

/**
 * Обробник завдань EMBED.
 * Знаходить чанки без embeddings, генерує через TEI, зберігає через native SQL.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class EmbedJobHandler {

    private final JobService jobService;
    private final TeiClient teiClient;
    private final RagChunkRepository chunkRepository;
    private final VectorRepository vectorRepository;

    public Mono<RagJob> handle(RagJob job) {
        return chunkRepository.countWithoutEmbeddingBySourceId(job.getSourceId())
                .flatMap(total -> {
                    if (total == 0) {
                        log.info("EMBED id={}: немає чанків без embeddings", job.getId());
                        return jobService.markCompleted(job);
                    }

                    log.info("EMBED id={}: {} чанків для обробки", job.getId(), total);
                    return jobService.updateProgress(job, 0, total.intValue())
                            .flatMap(j -> processNextBatch(j, total.intValue(), 0));
                })
                .onErrorResume(e -> {
                    log.error("EMBED помилка id={}: {}", job.getId(), e.getMessage());
                    return jobService.markFailed(job, e.getMessage());
                });
    }

    private Mono<RagJob> processNextBatch(RagJob job, int total, int processed) {
        // Перевіряємо чи завдання не зупинено
        return jobService.findById(job.getId())
                .flatMap(currentJob -> {
                    if ("STOPPED".equals(currentJob.getStatus())) {
                        log.info("EMBED id={}: завдання зупинено", job.getId());
                        return Mono.just(currentJob);
                    }

                    int batchSize = teiClient.getBatchSize();

                    return chunkRepository.findWithoutEmbeddingBySourceId(job.getSourceId(), batchSize)
                            .collectList()
                            .flatMap(chunks -> {
                                if (chunks.isEmpty()) {
                                    log.info("EMBED id={}: завершено, оброблено {} чанків", job.getId(), processed);
                                    return jobService.markCompleted(job);
                                }

                                List<String> texts = chunks.stream()
                                        .map(RagChunk::getContent)
                                        .toList();

                                return teiClient.embed(texts)
                                        .flatMap(embeddings -> saveEmbeddings(chunks, embeddings))
                                        .then(Mono.defer(() -> {
                                            int newProcessed = processed + chunks.size();
                                            return jobService.updateProgress(job, newProcessed, total)
                                                    .flatMap(j -> processNextBatch(j, total, newProcessed));
                                        }));
                            });
                });
    }

    @SuppressWarnings("unchecked")
    private Mono<Void> saveEmbeddings(List<RagChunk> chunks, List<?> embeddings) {
        return reactor.core.publisher.Flux.range(0, chunks.size())
                .flatMap(i -> {
                    Long chunkId = chunks.get(i).getId();
                    List<Float> embedding;

                    Object raw = embeddings.get(i);
                    if (raw instanceof List<?> list) {
                        embedding = list.stream()
                                .map(v -> ((Number) v).floatValue())
                                .toList();
                    } else {
                        log.warn("Невідомий формат embedding для chunk id={}", chunkId);
                        return Mono.empty();
                    }

                    return vectorRepository.updateEmbedding(chunkId, embedding);
                })
                .then();
    }
}
