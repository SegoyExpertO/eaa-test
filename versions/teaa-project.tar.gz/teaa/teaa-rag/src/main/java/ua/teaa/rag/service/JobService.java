package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagJobRepository;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobService {

    private final RagJobRepository repository;

    public Flux<RagJob> findAll() {
        return repository.findAllOrderByCreatedAtDesc();
    }

    public Flux<RagJob> findFiltered(String status, String action) {
        if (status != null && action != null) {
            return repository.findByStatusAndActionOrdered(status, action);
        }
        if (status != null) {
            return repository.findByStatusOrdered(status);
        }
        if (action != null) {
            return repository.findByActionOrdered(action);
        }
        return repository.findAllOrderByCreatedAtDesc();
    }

    public Flux<RagJob> findRecent(int limit) {
        return repository.findRecent(limit);
    }

    public Mono<RagJob> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<RagJob> create(RagJob job) {
        job.setStatus(RagJob.Status.PENDING.name());
        job.setProgress(0);
        job.setTotalItems(0);
        job.setProcessedItems(0);
        job.setCreatedAt(LocalDateTime.now());
        log.info("Створено завдання: action={}, source_id={}", job.getAction(), job.getSourceId());
        return repository.save(job);
    }

    public Mono<RagJob> stop(Long id) {
        return repository.findById(id)
                .filter(job -> RagJob.Status.RUNNING.name().equals(job.getStatus())
                        || RagJob.Status.PENDING.name().equals(job.getStatus()))
                .flatMap(job -> {
                    job.setStatus(RagJob.Status.STOPPED.name());
                    job.setCompletedAt(LocalDateTime.now());
                    log.info("Зупинено завдання: id={}", id);
                    return repository.save(job);
                });
    }

    public Mono<RagJob> resume(Long id) {
        return repository.findById(id)
                .filter(job -> RagJob.Status.STOPPED.name().equals(job.getStatus())
                        || RagJob.Status.FAILED.name().equals(job.getStatus()))
                .flatMap(job -> {
                    job.setStatus(RagJob.Status.PENDING.name());
                    job.setErrorMessage(null);
                    job.setStartedAt(null);
                    job.setCompletedAt(null);
                    log.info("Відновлено завдання: id={}", id);
                    return repository.save(job);
                });
    }

    public Mono<RagJob> updateAndRestart(Long id, RagJob updated) {
        return repository.findById(id)
                .flatMap(existing -> {
                    existing.setConfigOverride(updated.getConfigOverride());
                    existing.setStatus(RagJob.Status.PENDING.name());
                    existing.setProgress(0);
                    existing.setProcessedItems(0);
                    existing.setErrorMessage(null);
                    existing.setStartedAt(null);
                    existing.setCompletedAt(null);
                    log.info("Перезапущено завдання: id={}", id);
                    return repository.save(existing);
                });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id);
    }

    public Mono<RagJob> markRunning(RagJob job) {
        job.setStatus(RagJob.Status.RUNNING.name());
        job.setStartedAt(LocalDateTime.now());
        return repository.save(job);
    }

    public Mono<RagJob> markCompleted(RagJob job) {
        job.setStatus(RagJob.Status.COMPLETED.name());
        job.setProgress(100);
        job.setCompletedAt(LocalDateTime.now());
        return repository.save(job);
    }

    public Mono<RagJob> markFailed(RagJob job, String errorMessage) {
        job.setStatus(RagJob.Status.FAILED.name());
        job.setErrorMessage(errorMessage);
        job.setCompletedAt(LocalDateTime.now());
        return repository.save(job);
    }

    public Mono<RagJob> updateProgress(RagJob job, int processed, int total) {
        job.setProcessedItems(processed);
        job.setTotalItems(total);
        job.setProgress(total > 0 ? (processed * 100 / total) : 0);
        return repository.save(job);
    }
}
