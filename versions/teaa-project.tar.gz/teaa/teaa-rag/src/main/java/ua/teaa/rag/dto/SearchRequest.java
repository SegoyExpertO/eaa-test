package ua.teaa.rag.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchRequest {

    private List<SearchQuery> queries;
    private Double threshold;
    private Long sourceId;
    private Long collectionId;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SearchQuery {
        private List<Float> embedding;
        private Integer topK;
    }
}
