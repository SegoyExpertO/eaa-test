package ua.teaa.rag.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
import ua.teaa.rag.dto.SearchResponse.ChunkResult;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Репозиторій для роботи з pgvector через native SQL.
 */
@Slf4j
@Repository
@RequiredArgsConstructor
public class VectorRepository {

    private final DatabaseClient databaseClient;
    private final ObjectMapper objectMapper;

    /**
     * Зберігає embedding для чанка.
     */
    public Mono<Void> updateEmbedding(Long chunkId, List<Float> embedding) {
        String vectorStr = toVectorString(embedding);

        return databaseClient.sql(
                        "UPDATE rag_chunks SET embedding = :vector::vector WHERE id = :id")
                .bind("vector", vectorStr)
                .bind("id", chunkId)
                .then();
    }

    /**
     * Пошук найближчих чанків за cosine similarity з фільтрацією.
     */
    public Mono<List<ChunkResult>> search(List<Float> queryEmbedding, int topK,
                                           double threshold, Long sourceId, Long collectionId) {
        String vectorStr = toVectorString(queryEmbedding);

        StringBuilder sql = new StringBuilder("""
                SELECT c.id, c.content, c.source_id, c.metadata,
                       1 - (c.embedding <=> :vector::vector) as similarity
                FROM rag_chunks c
                WHERE c.embedding IS NOT NULL
                  AND 1 - (c.embedding <=> :vector::vector) >= :threshold
                """);

        if (sourceId != null) {
            sql.append(" AND c.source_id = :sourceId");
        }
        if (collectionId != null) {
            sql.append(" AND c.collection_id = :collectionId");
        }

        sql.append(" ORDER BY c.embedding <=> :vector::vector LIMIT :topK");

        DatabaseClient.GenericExecuteSpec spec = databaseClient.sql(sql.toString())
                .bind("vector", vectorStr)
                .bind("threshold", threshold)
                .bind("topK", topK);

        if (sourceId != null) {
            spec = spec.bind("sourceId", sourceId);
        }
        if (collectionId != null) {
            spec = spec.bind("collectionId", collectionId);
        }

        return spec.map((row, metadata) -> ChunkResult.builder()
                        .chunkId(row.get("id", Long.class))
                        .content(row.get("content", String.class))
                        .similarity(row.get("similarity", Double.class))
                        .sourceId(row.get("source_id", Long.class))
                        .metadata(parseMetadata(row.get("metadata", String.class)))
                        .build())
                .all()
                .collectList();
    }

    private String toVectorString(List<Float> embedding) {
        return embedding.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(",", "[", "]"));
    }

    private Map<String, Object> parseMetadata(String json) {
        if (json == null || json.isBlank()) return Map.of();
        try {
            return objectMapper.readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            log.warn("Помилка парсингу metadata: {}", e.getMessage());
            return Map.of();
        }
    }
}
