package ua.teaa.rag.service.download;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import ua.teaa.rag.entity.RagSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Stream;

@Slf4j
@Component
@RequiredArgsConstructor
public class LocalFilesStrategy implements DownloadStrategy {

    private final TextChunker chunker;

    @Override
    public String getSourceTypeCode() {
        return "LOCAL_FILES";
    }

    @Override
    @SuppressWarnings("unchecked")
    public Flux<ChunkData> download(RagSource source, Map<String, Object> config) {
        Path directory = Path.of(source.getLocation());
        List<String> patterns = config.get("file_patterns") instanceof List<?> list
                ? (List<String>) list
                : List.of("*.html", "*.json", "*.md");
        int chunkSize = getInt(config, "chunk_size", 800);
        int chunkOverlap = getInt(config, "chunk_overlap", 200);

        log.info("LOCAL_FILES: читання з {}, patterns={}", directory, patterns);

        if (!Files.exists(directory) || !Files.isDirectory(directory)) {
            return Flux.error(new IllegalArgumentException("Каталог не знайдено: " + directory));
        }

        List<ChunkData> allChunks = new ArrayList<>();

        try (Stream<Path> files = Files.walk(directory)) {
            files.filter(Files::isRegularFile)
                    .filter(path -> matchesPatterns(path.getFileName().toString(), patterns))
                    .forEach(file -> {
                        try {
                            String content = Files.readString(file);
                            String relativePath = directory.relativize(file).toString();

                            for (String chunk : chunker.chunk(content, chunkSize, chunkOverlap)) {
                                allChunks.add(new ChunkData(chunk, Map.of(
                                        "file_path", relativePath,
                                        "type", "local_file"
                                )));
                            }
                        } catch (IOException e) {
                            log.warn("Помилка читання {}: {}", file, e.getMessage());
                        }
                    });
        } catch (IOException e) {
            return Flux.error(e);
        }

        log.info("LOCAL_FILES: створено {} чанків", allChunks.size());
        return Flux.fromIterable(allChunks);
    }

    private boolean matchesPatterns(String filename, List<String> patterns) {
        return patterns.stream().anyMatch(pattern -> {
            String regex = pattern.replace(".", "\\.").replace("*", ".*");
            return Pattern.matches(regex, filename);
        });
    }

    private int getInt(Map<String, Object> config, String key, int defaultVal) {
        Object val = config.get(key);
        if (val instanceof Number n) return n.intValue();
        return defaultVal;
    }
}
