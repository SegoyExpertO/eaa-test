package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_jobs")
public class RagJob {

    @Id
    private Long id;
    private Long sourceId;
    private String action;
    private String status;
    private Integer progress;
    private Integer totalItems;
    private Integer processedItems;
    private String errorMessage;
    private String configOverride;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private LocalDateTime createdAt;

    public enum Action {
        DOWNLOAD, EMBED
    }

    public enum Status {
        PENDING, RUNNING, COMPLETED, FAILED, STOPPED
    }
}
