package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagJob;

public interface RagJobRepository extends R2dbcRepository<RagJob, Long> {

    Flux<RagJob> findByStatus(String status);

    Flux<RagJob> findBySourceId(Long sourceId);

    Flux<RagJob> findByAction(String action);

    Flux<RagJob> findByStatusAndAction(String status, String action);

    @Query("SELECT * FROM rag_jobs ORDER BY created_at DESC")
    Flux<RagJob> findAllOrderByCreatedAtDesc();

    @Query("SELECT * FROM rag_jobs WHERE status = :status ORDER BY created_at DESC")
    Flux<RagJob> findByStatusOrdered(String status);

    @Query("SELECT * FROM rag_jobs WHERE action = :action ORDER BY created_at DESC")
    Flux<RagJob> findByActionOrdered(String action);

    @Query("SELECT * FROM rag_jobs WHERE status = :status AND action = :action ORDER BY created_at DESC")
    Flux<RagJob> findByStatusAndActionOrdered(String status, String action);

    @Query("SELECT * FROM rag_jobs ORDER BY created_at DESC LIMIT :limit")
    Flux<RagJob> findRecent(int limit);

    @Query("SELECT COUNT(*) FROM rag_jobs WHERE status = 'RUNNING' AND action = :action")
    Mono<Long> countRunningByAction(String action);

    @Query("SELECT * FROM rag_jobs WHERE status = 'PENDING' AND action = :action ORDER BY created_at LIMIT 1")
    Mono<RagJob> findNextPending(String action);

    @Query("SELECT * FROM rag_jobs WHERE status = 'RUNNING' AND started_at < NOW() - INTERVAL '1 minute' * :timeoutMinutes")
    Flux<RagJob> findStaleJobs(int timeoutMinutes);
}
