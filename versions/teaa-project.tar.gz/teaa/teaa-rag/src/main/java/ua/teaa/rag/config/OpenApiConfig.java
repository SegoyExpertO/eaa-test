package ua.teaa.rag.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("TEAA RAG Service API")
                        .description("API для управління RAG-базою знань: типи джерел, джерела, " +
                                "завдання (завантаження, embedding), колекції, налаштування, " +
                                "семантичний пошук, експорт/імпорт.")
                        .version("1.0.0")
                        .contact(new Contact().name("TEAA Team")));
    }
}
