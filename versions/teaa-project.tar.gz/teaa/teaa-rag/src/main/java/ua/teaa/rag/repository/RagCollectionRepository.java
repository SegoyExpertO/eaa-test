package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagCollection;

public interface RagCollectionRepository extends R2dbcRepository<RagCollection, Long> {
    Mono<RagCollection> findByName(String name);
}
