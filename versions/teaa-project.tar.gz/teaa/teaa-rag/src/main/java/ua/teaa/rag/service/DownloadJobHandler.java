package ua.teaa.rag.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagChunk;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagChunkRepository;
import ua.teaa.rag.repository.RagSourceRepository;
import ua.teaa.rag.repository.RagSourceTypeRepository;
import ua.teaa.rag.service.download.DownloadStrategy;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
public class DownloadJobHandler {

    private final JobService jobService;
    private final RagSourceRepository sourceRepository;
    private final RagSourceTypeRepository sourceTypeRepository;
    private final RagChunkRepository chunkRepository;
    private final ConfigMergeService configMergeService;
    private final ObjectMapper objectMapper;
    private final Map<String, DownloadStrategy> strategies;

    public DownloadJobHandler(JobService jobService,
                               RagSourceRepository sourceRepository,
                               RagSourceTypeRepository sourceTypeRepository,
                               RagChunkRepository chunkRepository,
                               ConfigMergeService configMergeService,
                               ObjectMapper objectMapper,
                               List<DownloadStrategy> strategyList) {
        this.jobService = jobService;
        this.sourceRepository = sourceRepository;
        this.sourceTypeRepository = sourceTypeRepository;
        this.chunkRepository = chunkRepository;
        this.configMergeService = configMergeService;
        this.objectMapper = objectMapper;
        this.strategies = strategyList.stream()
                .collect(Collectors.toMap(DownloadStrategy::getSourceTypeCode, Function.identity()));

        log.info("Зареєстровано {} стратегій завантаження: {}", strategies.size(), strategies.keySet());
    }

    public Mono<RagJob> handle(RagJob job) {
        return sourceRepository.findById(job.getSourceId())
                .flatMap(source -> sourceTypeRepository.findById(source.getTypeId())
                        .flatMap(sourceType -> {
                            Map<String, Object> config = configMergeService.merge(sourceType, source, job);
                            DownloadStrategy strategy = strategies.get(sourceType.getCode());

                            if (strategy == null) {
                                return jobService.markFailed(job,
                                        "Немає стратегії для типу: " + sourceType.getCode());
                            }

                            log.info("DOWNLOAD id={}: source='{}', type='{}', location='{}'",
                                    job.getId(), source.getName(), sourceType.getCode(), source.getLocation());

                            return strategy.download(source, config)
                                    .index()
                                    .flatMap(indexed -> {
                                        long idx = indexed.getT1();
                                        var chunkData = indexed.getT2();

                                        String metadataJson;
                                        try {
                                            metadataJson = objectMapper.writeValueAsString(chunkData.metadata());
                                        } catch (Exception e) {
                                            metadataJson = "{}";
                                        }

                                        var chunk = RagChunk.builder()
                                                .sourceId(job.getSourceId())
                                                .content(chunkData.content())
                                                .metadata(metadataJson)
                                                .createdAt(LocalDateTime.now())
                                                .build();

                                        return chunkRepository.save(chunk)
                                                .flatMap(saved -> {
                                                    if ((idx + 1) % 50 == 0) {
                                                        return jobService.updateProgress(job, (int) (idx + 1), 0);
                                                    }
                                                    return Mono.just(job);
                                                });
                                    })
                                    .count()
                                    .flatMap(total -> {
                                        log.info("DOWNLOAD id={}: збережено {} чанків", job.getId(), total);
                                        return jobService.updateProgress(job, total.intValue(), total.intValue())
                                                .flatMap(j -> jobService.markCompleted(j));
                                    });
                        }))
                .onErrorResume(e -> {
                    log.error("DOWNLOAD помилка id={}: {}", job.getId(), e.getMessage());
                    return jobService.markFailed(job, e.getMessage());
                });
    }
}
