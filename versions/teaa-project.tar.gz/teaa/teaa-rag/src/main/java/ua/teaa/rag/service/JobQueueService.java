package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.repository.RagJobRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobQueueService implements ApplicationRunner {

    private final RagJobRepository jobRepository;
    private final JobService jobService;
    private final DownloadJobHandler downloadHandler;
    private final EmbedJobHandler embedHandler;
    private final SettingsService settings;

    @Override
    public void run(ApplicationArguments args) {
        int timeout = settings.getStaleJobTimeoutMinutes();
        log.info("Перевірка завислих завдань (таймаут: {} хв)...", timeout);
        jobRepository.findStaleJobs(timeout)
                .flatMap(job -> {
                    log.warn("Завислe завдання id={}, action={} — повертаємо в PENDING", job.getId(), job.getAction());
                    job.setStatus(RagJob.Status.PENDING.name());
                    job.setStartedAt(null);
                    return jobRepository.save(job);
                })
                .collectList()
                .doOnSuccess(jobs -> {
                    if (!jobs.isEmpty()) {
                        log.info("Відновлено {} завислих завдань", jobs.size());
                    } else {
                        log.info("Завислих завдань не знайдено");
                    }
                })
                .block();
    }

    @Scheduled(fixedDelayString = "${teaa.queue.poll-interval-seconds:5}000")
    public void pollQueue() {
        processQueue(RagJob.Action.DOWNLOAD.name(), settings.getMaxConcurrentDownload());
        processQueue(RagJob.Action.EMBED.name(), settings.getMaxConcurrentEmbed());
    }

    private void processQueue(String action, int maxConcurrent) {
        jobRepository.countRunningByAction(action)
                .flatMap(running -> {
                    if (running >= maxConcurrent) {
                        return reactor.core.publisher.Mono.empty();
                    }
                    return jobRepository.findNextPending(action);
                })
                .flatMap(job -> {
                    log.info("Запуск завдання id={}, action={}", job.getId(), job.getAction());
                    return jobService.markRunning(job)
                            .flatMap(this::dispatch);
                })
                .subscribe(
                        job -> log.debug("Завдання id={} передано на обробку", job.getId()),
                        error -> log.error("Помилка обробки черги: {}", error.getMessage())
                );
    }

    private reactor.core.publisher.Mono<RagJob> dispatch(RagJob job) {
        return switch (RagJob.Action.valueOf(job.getAction())) {
            case DOWNLOAD -> downloadHandler.handle(job);
            case EMBED -> embedHandler.handle(job);
        };
    }
}
