package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_chunks")
public class RagChunk {

    @Id
    private Long id;
    private Long sourceId;
    private Long collectionId;
    private String content;
    private String metadata;
    private LocalDateTime createdAt;
}
