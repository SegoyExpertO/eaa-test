package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagChunk;

public interface RagChunkRepository extends R2dbcRepository<RagChunk, Long> {

    Flux<RagChunk> findBySourceId(Long sourceId);

    Mono<Long> countBySourceId(Long sourceId);

    @Query("SELECT COUNT(*) FROM rag_chunks WHERE source_id = :sourceId AND embedding IS NULL")
    Mono<Long> countWithoutEmbeddingBySourceId(Long sourceId);

    @Query("SELECT * FROM rag_chunks WHERE source_id = :sourceId AND embedding IS NULL LIMIT :limit")
    Flux<RagChunk> findWithoutEmbeddingBySourceId(Long sourceId, int limit);

    Mono<Void> deleteBySourceId(Long sourceId);
}
