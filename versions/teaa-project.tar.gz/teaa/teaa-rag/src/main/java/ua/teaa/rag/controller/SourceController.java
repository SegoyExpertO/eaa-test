package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSource;
import ua.teaa.rag.repository.RagChunkRepository;
import ua.teaa.rag.service.SourceService;

import java.util.Map;

@Tag(name = "Sources", description = "Управління джерелами документації")
@RestController
@RequestMapping("/api/v1/sources")
@RequiredArgsConstructor
public class SourceController {

    private final SourceService service;
    private final RagChunkRepository chunkRepository;

    @GetMapping
    public Flux<RagSource> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Mono<RagSource> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @GetMapping("/{id}/chunks/count")
    public Mono<Map<String, Object>> chunkCount(@PathVariable Long id) {
        return chunkRepository.countBySourceId(id)
                .map(count -> Map.of("sourceId", (Object) id, "chunkCount", count));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagSource> create(@RequestBody RagSource source) {
        return service.create(source);
    }

    @PutMapping("/{id}")
    public Mono<RagSource> update(@PathVariable Long id, @RequestBody RagSource source) {
        return service.update(id, source);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }
}
