package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_sources")
public class RagSource {

    @Id
    private Long id;
    private String name;
    private String description;
    private Long typeId;
    private String location;
    private String config;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public enum Status {
        REGISTERED, READY, ERROR
    }
}
