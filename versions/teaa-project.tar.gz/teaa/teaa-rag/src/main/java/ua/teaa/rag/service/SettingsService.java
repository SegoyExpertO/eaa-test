package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSetting;
import ua.teaa.rag.repository.RagSettingRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Сервіс системних налаштувань.
 * Зберігає в БД, кешує в пам'яті, оновлюється без перезапуску.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SettingsService implements ApplicationRunner {

    private final RagSettingRepository repository;
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    @Override
    public void run(ApplicationArguments args) {
        reloadCache().block();
        log.info("Завантажено {} налаштувань з БД", cache.size());
    }

    public Mono<Void> reloadCache() {
        return repository.findAll()
                .doOnNext(s -> cache.put(s.getKey(), s.getValue()))
                .then();
    }

    // --- Typed getters ---

    public String getString(String key, String defaultValue) {
        return cache.getOrDefault(key, defaultValue);
    }

    public int getInt(String key, int defaultValue) {
        String val = cache.get(key);
        if (val == null) return defaultValue;
        try {
            return Integer.parseInt(val);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public long getLong(String key, long defaultValue) {
        String val = cache.get(key);
        if (val == null) return defaultValue;
        try {
            return Long.parseLong(val);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public double getDouble(String key, double defaultValue) {
        String val = cache.get(key);
        if (val == null) return defaultValue;
        try {
            return Double.parseDouble(val);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    // --- Shortcut methods for common settings ---

    public String getTeiBaseUrl() {
        return getString("tei.base-url", "http://localhost:8080");
    }

    public int getTeiBatchSize() {
        return getInt("tei.batch-size", 32);
    }

    public long getTeiTimeoutSeconds() {
        return getLong("tei.timeout-seconds", 60);
    }

    public int getQueuePollIntervalSeconds() {
        return getInt("queue.poll-interval-seconds", 5);
    }

    public int getMaxConcurrentDownload() {
        return getInt("queue.max-concurrent-download", 2);
    }

    public int getMaxConcurrentEmbed() {
        return getInt("queue.max-concurrent-embed", 1);
    }

    public int getStaleJobTimeoutMinutes() {
        return getInt("queue.stale-job-timeout-minutes", 30);
    }

    public int getDefaultChunkSize() {
        return getInt("chunking.default-chunk-size", 800);
    }

    public int getDefaultChunkOverlap() {
        return getInt("chunking.default-chunk-overlap", 200);
    }

    public int getDefaultTopK() {
        return getInt("search.default-top-k", 10);
    }

    public double getDefaultThreshold() {
        return getDouble("search.default-threshold", 0.7);
    }

    // --- CRUD ---

    public Flux<RagSetting> findAll() {
        return repository.findAll();
    }

    public Mono<RagSetting> findByKey(String key) {
        return repository.findByKey(key);
    }

    public Mono<RagSetting> update(String key, String value) {
        return repository.findByKey(key)
                .flatMap(existing -> {
                    existing.setValue(value);
                    existing.setUpdatedAt(LocalDateTime.now());
                    return repository.save(existing);
                })
                .doOnSuccess(s -> {
                    if (s != null) {
                        cache.put(s.getKey(), s.getValue());
                        log.info("Налаштування оновлено: {} = {}", key, value);
                    }
                });
    }

    public Mono<RagSetting> create(RagSetting setting) {
        setting.setUpdatedAt(LocalDateTime.now());
        return repository.save(setting)
                .doOnSuccess(s -> {
                    cache.put(s.getKey(), s.getValue());
                    log.info("Налаштування створено: {} = {}", s.getKey(), s.getValue());
                });
    }

    public Mono<Void> delete(String key) {
        return repository.deleteById(key)
                .doOnSuccess(v -> {
                    cache.remove(key);
                    log.info("Налаштування видалено: {}", key);
                });
    }
}
