package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSetting;

public interface RagSettingRepository extends R2dbcRepository<RagSetting, String> {

    Mono<RagSetting> findByKey(String key);
}
