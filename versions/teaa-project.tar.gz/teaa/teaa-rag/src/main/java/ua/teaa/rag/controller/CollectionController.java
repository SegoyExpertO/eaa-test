package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagCollection;
import ua.teaa.rag.service.CollectionService;

@Tag(name = "Collections", description = "Управління колекціями знань")
@RestController
@RequestMapping("/api/v1/collections")
@RequiredArgsConstructor
public class CollectionController {

    private final CollectionService service;

    @GetMapping
    public Flux<RagCollection> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Mono<RagCollection> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagCollection> create(@RequestBody RagCollection collection) {
        return service.create(collection);
    }

    @PutMapping("/{id}")
    public Mono<RagCollection> update(@PathVariable Long id, @RequestBody RagCollection collection) {
        return service.update(id, collection);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }
}
