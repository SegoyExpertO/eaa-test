package ua.teaa.rag.service.download;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSource;

import java.time.Duration;
import java.util.*;
import java.util.regex.Pattern;

@Slf4j
@Component
@RequiredArgsConstructor
public class GitRepoStrategy implements DownloadStrategy {

    private final WebClient.Builder webClientBuilder;
    private final TextChunker chunker;
    private final ObjectMapper objectMapper;

    @Override
    public String getSourceTypeCode() {
        return "GIT_REPO";
    }

    @Override
    public Flux<ChunkData> download(RagSource source, Map<String, Object> config) {
        String repoUrl = source.getLocation(); // https://github.com/owner/repo
        String branch = getString(config, "branch", "main");
        List<String> filePatterns = getStringList(config, "file_patterns", List.of("*.json", "*.md"));
        int chunkSize = getInt(config, "chunk_size", 800);
        int chunkOverlap = getInt(config, "chunk_overlap", 200);

        // Перетворюємо GitHub URL в API URL
        String apiUrl = toGitHubApiUrl(repoUrl);
        String rawUrl = toGitHubRawUrl(repoUrl, branch);

        WebClient webClient = webClientBuilder.build();

        log.info("GIT_REPO: завантаження {}, branch={}, patterns={}", repoUrl, branch, filePatterns);

        return listRepoFiles(webClient, apiUrl, branch)
                .filter(path -> matchesPatterns(path, filePatterns))
                .delayElements(Duration.ofMillis(200))
                .flatMap(path -> fetchFile(webClient, rawUrl + "/" + path)
                        .flatMapMany(content -> {
                            List<ChunkData> chunks = parseFileContent(content, path, chunkSize, chunkOverlap);
                            return Flux.fromIterable(chunks);
                        })
                        .onErrorResume(e -> {
                            log.warn("Не вдалося завантажити {}: {}", path, e.getMessage());
                            return Flux.empty();
                        }), 2);
    }

    private List<ChunkData> parseFileContent(String content, String path, int chunkSize, int chunkOverlap) {
        List<ChunkData> chunks = new ArrayList<>();

        if (path.endsWith(".json")) {
            // JSON файл — парсимо як єдиний чанк з метаданими
            try {
                JsonNode root = objectMapper.readTree(content);
                String text = root.toPrettyString();

                Map<String, Object> metadata = new HashMap<>();
                metadata.put("file_path", path);
                metadata.put("type", "json_file");
                if (root.has("id")) metadata.put("rule_id", root.get("id").asText());
                if (root.has("tags")) {
                    List<String> tags = new ArrayList<>();
                    root.get("tags").forEach(t -> tags.add(t.asText()));
                    metadata.put("tags", String.join(",", tags));
                }

                for (String chunk : chunker.chunk(text, chunkSize, chunkOverlap)) {
                    chunks.add(new ChunkData(chunk, metadata));
                }
            } catch (Exception e) {
                log.warn("Помилка парсингу JSON {}: {}", path, e.getMessage());
                chunks.add(new ChunkData(content, Map.of("file_path", path, "type", "raw_json")));
            }
        } else {
            // MD або інший текст
            for (String chunk : chunker.chunk(content, chunkSize, chunkOverlap)) {
                chunks.add(new ChunkData(chunk, Map.of(
                        "file_path", path,
                        "type", "text_file"
                )));
            }
        }

        return chunks;
    }

    private Flux<String> listRepoFiles(WebClient webClient, String apiUrl, String branch) {
        // GitHub API: GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1
        return webClient.get()
                .uri(apiUrl + "/git/trees/" + branch + "?recursive=1")
                .header("Accept", "application/vnd.github.v3+json")
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30))
                .flatMapMany(json -> {
                    try {
                        JsonNode root = objectMapper.readTree(json);
                        JsonNode tree = root.get("tree");
                        List<String> paths = new ArrayList<>();
                        if (tree != null && tree.isArray()) {
                            tree.forEach(node -> {
                                if ("blob".equals(node.get("type").asText())) {
                                    paths.add(node.get("path").asText());
                                }
                            });
                        }
                        log.info("GIT_REPO: знайдено {} файлів у репозиторії", paths.size());
                        return Flux.fromIterable(paths);
                    } catch (Exception e) {
                        return Flux.error(e);
                    }
                });
    }

    private Mono<String> fetchFile(WebClient webClient, String url) {
        return webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30));
    }

    private boolean matchesPatterns(String path, List<String> patterns) {
        return patterns.stream().anyMatch(pattern -> {
            String regex = pattern.replace(".", "\\.").replace("*", ".*");
            return Pattern.matches(regex, path) || path.endsWith(pattern.replace("*", ""));
        });
    }

    private String toGitHubApiUrl(String repoUrl) {
        // https://github.com/owner/repo -> https://api.github.com/repos/owner/repo
        return repoUrl.replace("https://github.com/", "https://api.github.com/repos/")
                .replaceAll("/$", "");
    }

    private String toGitHubRawUrl(String repoUrl, String branch) {
        // https://github.com/owner/repo -> https://raw.githubusercontent.com/owner/repo/branch
        return repoUrl.replace("https://github.com/", "https://raw.githubusercontent.com/")
                .replaceAll("/$", "") + "/" + branch;
    }

    private String getString(Map<String, Object> config, String key, String defaultVal) {
        Object val = config.get(key);
        return val instanceof String s ? s : defaultVal;
    }

    @SuppressWarnings("unchecked")
    private List<String> getStringList(Map<String, Object> config, String key, List<String> defaultVal) {
        Object val = config.get(key);
        if (val instanceof List<?> list) return (List<String>) list;
        return defaultVal;
    }

    private int getInt(Map<String, Object> config, String key, int defaultVal) {
        Object val = config.get(key);
        if (val instanceof Number n) return n.intValue();
        return defaultVal;
    }
}
