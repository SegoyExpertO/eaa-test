package ua.teaa.rag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class TeaaRagApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeaaRagApplication.class, args);
    }
}
