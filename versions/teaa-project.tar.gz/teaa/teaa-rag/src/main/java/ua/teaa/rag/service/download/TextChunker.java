package ua.teaa.rag.service.download;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Нарізка тексту на чанки з перекриттям.
 * Працює на рівні слів, не символів — уникає розрізання посеред слова.
 */
@Component
public class TextChunker {

    /**
     * Нарізає текст на чанки.
     *
     * @param text    вхідний текст
     * @param chunkSize   приблизний розмір чанка в символах
     * @param overlap     розмір перекриття в символах
     * @return список чанків
     */
    public List<String> chunk(String text, int chunkSize, int overlap) {
        if (text == null || text.isBlank()) {
            return List.of();
        }

        if (text.length() <= chunkSize) {
            return List.of(text.trim());
        }

        List<String> chunks = new ArrayList<>();
        String[] words = text.split("\\s+");
        StringBuilder current = new StringBuilder();
        int lastChunkStart = 0;

        for (int i = 0; i < words.length; i++) {
            if (current.isEmpty()) {
                current.append(words[i]);
            } else {
                current.append(" ").append(words[i]);
            }

            if (current.length() >= chunkSize) {
                chunks.add(current.toString().trim());

                // Визначаємо початок наступного чанка з overlap
                int overlapWordCount = countWordsForLength(words, i, overlap);
                int nextStart = Math.max(lastChunkStart + 1, i - overlapWordCount + 1);
                lastChunkStart = nextStart;
                i = nextStart - 1;
                current = new StringBuilder();
            }
        }

        if (!current.isEmpty()) {
            String remaining = current.toString().trim();
            if (!remaining.isBlank()) {
                chunks.add(remaining);
            }
        }

        return chunks;
    }

    private int countWordsForLength(String[] words, int endIndex, int targetLength) {
        int length = 0;
        int count = 0;
        for (int i = endIndex; i >= 0 && length < targetLength; i--) {
            length += words[i].length() + 1;
            count++;
        }
        return count;
    }
}
