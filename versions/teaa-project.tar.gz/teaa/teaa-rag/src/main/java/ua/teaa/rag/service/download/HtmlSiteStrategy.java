package ua.teaa.rag.service.download;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSource;

import java.time.Duration;
import java.util.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class HtmlSiteStrategy implements DownloadStrategy {

    private final WebClient.Builder webClientBuilder;
    private final TextChunker chunker;

    @Override
    public String getSourceTypeCode() {
        return "HTML_SITE";
    }

    @Override
    public Flux<ChunkData> download(RagSource source, Map<String, Object> config) {
        int maxDepth = getInt(config, "max_depth", 2);
        boolean followLinks = getBool(config, "follow_links", true);
        int chunkSize = getInt(config, "chunk_size", 800);
        int chunkOverlap = getInt(config, "chunk_overlap", 200);

        WebClient webClient = webClientBuilder.build();
        String baseUrl = source.getLocation();

        log.info("HTML_SITE: завантаження {}, max_depth={}, follow_links={}", baseUrl, maxDepth, followLinks);

        return fetchPage(webClient, baseUrl)
                .flatMapMany(html -> {
                    Document doc = Jsoup.parse(html, baseUrl);
                    List<ChunkData> chunks = new ArrayList<>(parseDocument(doc, baseUrl, chunkSize, chunkOverlap));

                    if (!followLinks || maxDepth <= 0) {
                        return Flux.fromIterable(chunks);
                    }

                    // Збираємо внутрішні посилання
                    Set<String> links = extractLinks(doc, baseUrl);
                    log.info("HTML_SITE: знайдено {} внутрішніх посилань", links.size());

                    return Flux.fromIterable(chunks)
                            .concatWith(
                                    Flux.fromIterable(links)
                                            .delayElements(Duration.ofMillis(300))
                                            .flatMap(link -> fetchPage(webClient, link)
                                                    .flatMapMany(linkHtml -> {
                                                        Document linkDoc = Jsoup.parse(linkHtml, link);
                                                        return Flux.fromIterable(
                                                                parseDocument(linkDoc, link, chunkSize, chunkOverlap));
                                                    })
                                                    .onErrorResume(e -> {
                                                        log.warn("Не вдалося завантажити {}: {}", link, e.getMessage());
                                                        return Flux.empty();
                                                    }),
                                                    1)
                            );
                });
    }

    private List<ChunkData> parseDocument(Document doc, String url, int chunkSize, int chunkOverlap) {
        List<ChunkData> chunks = new ArrayList<>();
        String title = doc.title();

        // Парсимо секції — кожна секція окремо
        Elements sections = doc.select("section, article, .guideline, .sc");

        if (sections.isEmpty()) {
            // Без секцій — парсимо body цілком
            String text = doc.body() != null ? doc.body().text() : doc.text();
            if (!text.isBlank()) {
                for (String chunkText : chunker.chunk(text, chunkSize, chunkOverlap)) {
                    chunks.add(new ChunkData(chunkText, Map.of(
                            "title", title,
                            "url", url,
                            "type", "html_page"
                    )));
                }
            }
        } else {
            for (Element section : sections) {
                String sectionText = section.text();
                if (sectionText.isBlank()) continue;

                String sectionTitle = "";
                Element heading = section.selectFirst("h1, h2, h3, h4, h5");
                if (heading != null) {
                    sectionTitle = heading.text();
                }

                Map<String, Object> metadata = new HashMap<>();
                metadata.put("title", title);
                metadata.put("section", sectionTitle);
                metadata.put("url", url);
                metadata.put("section_id", section.id());
                metadata.put("type", "html_section");

                for (String chunkText : chunker.chunk(sectionText, chunkSize, chunkOverlap)) {
                    chunks.add(new ChunkData(chunkText, metadata));
                }
            }
        }

        return chunks;
    }

    private Set<String> extractLinks(Document doc, String baseUrl) {
        Set<String> links = new LinkedHashSet<>();
        Elements anchors = doc.select("a[href]");

        for (Element a : anchors) {
            String href = a.absUrl("href");
            if (href.startsWith(baseUrl) && !href.equals(baseUrl) && !href.contains("#")) {
                links.add(href);
            }
        }

        return links;
    }

    private Mono<String> fetchPage(WebClient webClient, String url) {
        return webClient.get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30))
                .doOnSuccess(h -> log.debug("Завантажено: {}", url));
    }

    private int getInt(Map<String, Object> config, String key, int defaultVal) {
        Object val = config.get(key);
        if (val instanceof Number n) return n.intValue();
        return defaultVal;
    }

    private boolean getBool(Map<String, Object> config, String key, boolean defaultVal) {
        Object val = config.get(key);
        if (val instanceof Boolean b) return b;
        return defaultVal;
    }
}
