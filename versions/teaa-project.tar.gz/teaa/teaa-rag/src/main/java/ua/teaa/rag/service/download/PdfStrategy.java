package ua.teaa.rag.service.download;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSource;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class PdfStrategy implements DownloadStrategy {

    private final WebClient.Builder webClientBuilder;
    private final TextChunker chunker;

    @Override
    public String getSourceTypeCode() {
        return "PDF";
    }

    @Override
    public Flux<ChunkData> download(RagSource source, Map<String, Object> config) {
        int chunkSize = getInt(config, "chunk_size", 800);
        int chunkOverlap = getInt(config, "chunk_overlap", 200);

        WebClient webClient = webClientBuilder.build();

        log.info("PDF: завантаження {}", source.getLocation());

        return webClient.get()
                .uri(source.getLocation())
                .retrieve()
                .bodyToMono(byte[].class)
                .timeout(Duration.ofSeconds(60))
                .flatMapMany(bytes -> {
                    try {
                        String text = extractTextFromPdf(bytes);
                        log.info("PDF: витягнуто {} символів", text.length());

                        List<ChunkData> chunks = new ArrayList<>();
                        for (String chunk : chunker.chunk(text, chunkSize, chunkOverlap)) {
                            chunks.add(new ChunkData(chunk, Map.of(
                                    "url", source.getLocation(),
                                    "type", "pdf_section"
                            )));
                        }
                        return Flux.fromIterable(chunks);
                    } catch (Exception e) {
                        log.error("PDF: помилка парсингу: {}", e.getMessage());
                        return Flux.error(e);
                    }
                });
    }

    private String extractTextFromPdf(byte[] bytes) throws Exception {
        // Apache PDFBox
        try (var doc = org.apache.pdfbox.pdmodel.PDDocument.load(new ByteArrayInputStream(bytes))) {
            var stripper = new org.apache.pdfbox.text.PDFTextStripper();
            return stripper.getText(doc);
        }
    }

    private int getInt(Map<String, Object> config, String key, int defaultVal) {
        Object val = config.get(key);
        if (val instanceof Number n) return n.intValue();
        return defaultVal;
    }
}
