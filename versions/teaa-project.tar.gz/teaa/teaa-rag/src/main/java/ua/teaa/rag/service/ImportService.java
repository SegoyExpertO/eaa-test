package ua.teaa.rag.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImportService {

    private final DatabaseClient databaseClient;

    /**
     * Імпорт з JSON дампу.
     */
    @SuppressWarnings("unchecked")
    public Mono<Map<String, Object>> importJson(byte[] data) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            Map<String, Object> dump = mapper.readValue(data, new TypeReference<>() {});

            String exportType = (String) dump.get("exportType");
            List<Map<String, Object>> chunks = (List<Map<String, Object>>) dump.get("chunks");
            int totalChunks = chunks != null ? chunks.size() : 0;

            log.info("Імпорт: type={}, chunks={}", exportType, totalChunks);

            if (chunks == null || chunks.isEmpty()) {
                return Mono.just(Map.of("imported", 0, "status", "EMPTY"));
            }

            return Flux.fromIterable(chunks)
                    .flatMap(this::insertChunk, 4)
                    .count()
                    .map(count -> {
                        log.info("Імпортовано {} чанків", count);
                        return Map.<String, Object>of(
                                "imported", count,
                                "total", totalChunks,
                                "status", "SUCCESS"
                        );
                    });

        } catch (Exception e) {
            log.error("Помилка імпорту: {}", e.getMessage());
            return Mono.just(Map.of("imported", 0, "status", "ERROR", "error", e.getMessage()));
        }
    }

    /**
     * Імпорт з SQL дампу — виконує SQL напряму.
     */
    public Mono<Map<String, Object>> importSql(byte[] data) {
        String sql = new String(data);
        String[] statements = sql.split(";\n");

        log.info("Імпорт SQL: {} statements", statements.length);

        return Flux.fromArray(statements)
                .filter(s -> !s.isBlank() && !s.trim().startsWith("--"))
                .flatMap(statement -> databaseClient.sql(statement.trim())
                        .then()
                        .onErrorResume(e -> {
                            log.warn("SQL помилка: {}", e.getMessage());
                            return Mono.empty();
                        }), 1)
                .count()
                .map(count -> Map.<String, Object>of(
                        "executedStatements", count,
                        "totalStatements", (long) statements.length,
                        "status", "SUCCESS"
                ));
    }

    private Mono<Void> insertChunk(Map<String, Object> chunk) {
        String embedding = chunk.get("embedding") != null
                ? chunk.get("embedding").toString()
                : null;

        var spec = databaseClient.sql(
                        "INSERT INTO rag_chunks (source_id, collection_id, content, embedding, metadata) " +
                                "VALUES (:sourceId, :collectionId, :content, " +
                                (embedding != null ? ":embedding::vector" : "NULL") +
                                ", :metadata::jsonb)")
                .bind("sourceId", ((Number) chunk.get("sourceId")).longValue())
                .bind("content", chunk.get("content").toString())
                .bind("metadata", chunk.get("metadata") != null ? chunk.get("metadata").toString() : "{}");

        if (chunk.get("collectionId") != null) {
            spec = spec.bind("collectionId", ((Number) chunk.get("collectionId")).longValue());
        } else {
            spec = spec.bindNull("collectionId", Long.class);
        }

        if (embedding != null) {
            spec = spec.bind("embedding", embedding);
        }

        return spec.then();
    }
}
