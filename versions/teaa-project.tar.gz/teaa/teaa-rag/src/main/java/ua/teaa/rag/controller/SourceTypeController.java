package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagSourceType;
import ua.teaa.rag.service.SourceTypeService;

@Tag(name = "Source Types", description = "Управління типами джерел")
@RestController
@RequestMapping("/api/v1/source-types")
@RequiredArgsConstructor
public class SourceTypeController {

    private final SourceTypeService service;

    @GetMapping
    public Flux<RagSourceType> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Mono<RagSourceType> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagSourceType> create(@RequestBody RagSourceType sourceType) {
        return service.create(sourceType);
    }

    @PutMapping("/{id}")
    public Mono<RagSourceType> update(@PathVariable Long id, @RequestBody RagSourceType sourceType) {
        return service.update(id, sourceType);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }
}
