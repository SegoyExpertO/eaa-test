package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_source_types")
public class RagSourceType {

    @Id
    private Long id;
    private String code;
    private String name;
    private String description;
    private String defaultConfig;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
