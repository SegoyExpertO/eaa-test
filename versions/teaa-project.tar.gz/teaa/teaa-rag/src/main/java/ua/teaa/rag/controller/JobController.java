package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagJob;
import ua.teaa.rag.service.JobService;

@Tag(name = "Jobs", description = "Управління завданнями")
@RestController
@RequestMapping("/api/v1/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService service;

    @GetMapping
    public Flux<RagJob> findAll(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String action) {
        return service.findFiltered(status, action);
    }

    @GetMapping("/{id}")
    public Mono<RagJob> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagJob> create(@RequestBody RagJob job) {
        return service.create(job);
    }

    @PutMapping("/{id}")
    public Mono<RagJob> updateAndRestart(@PathVariable Long id, @RequestBody RagJob job) {
        return service.updateAndRestart(id, job);
    }

    @PutMapping("/{id}/stop")
    public Mono<RagJob> stop(@PathVariable Long id) {
        return service.stop(id);
    }

    @PutMapping("/{id}/resume")
    public Mono<RagJob> resume(@PathVariable Long id) {
        return service.resume(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }
}
