package ua.teaa.rag.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import ua.teaa.rag.service.ExportService;
import ua.teaa.rag.service.ImportService;

import java.util.Map;

@Tag(name = "Export / Import", description = "Експорт та імпорт RAG-бази")
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class ExportImportController {
    private final ExportService exportService;
    private final ImportService importService;

    /**
     * Експорт RAG-бази.
     * GET /api/v1/export?scope=collection|source|all&id=1&format=json|sql
     */
    @GetMapping("/export")
    public Mono<ResponseEntity<byte[]>> export(
            @RequestParam String scope,
            @RequestParam(required = false) Long id,
            @RequestParam(defaultValue = "json") String format) {

        if (!"all".equals(scope) && id == null) {
            return Mono.just(ResponseEntity.badRequest().build());
        }

        String filename = "teaa-rag-export-" + scope + (id != null ? "-" + id : "");

        return switch (format) {
            case "json" -> exportService.exportJson(scope, id)
                    .map(data -> ResponseEntity.ok()
                            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename + ".json")
                            .contentType(MediaType.APPLICATION_JSON)
                            .body(data));
            case "sql" -> exportService.exportSql(scope, id)
                    .map(data -> ResponseEntity.ok()
                            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename + ".sql")
                            .contentType(MediaType.TEXT_PLAIN)
                            .body(data));
            default -> Mono.just(ResponseEntity.badRequest().build());
        };
    }

    /**
     * Імпорт RAG-бази.
     * POST /api/v1/import (multipart file)
     */
    @PostMapping(value = "/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String, Object>> importDump(@RequestPart("file") FilePart file) {
        String filename = file.filename().toLowerCase();

        return DataBufferUtils.join(file.content())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .flatMap(bytes -> {
                    if (filename.endsWith(".json")) {
                        return importService.importJson(bytes);
                    } else if (filename.endsWith(".sql")) {
                        return importService.importSql(bytes);
                    } else {
                        return Mono.just(Map.<String, Object>of(
                                "status", "ERROR",
                                "error", "Непідтримуваний формат. Очікується .json або .sql"
                        ));
                    }
                });
    }
}
