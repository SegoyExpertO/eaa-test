CREATE EXTENSION IF NOT EXISTS vector;

-- Типи джерел
CREATE TABLE IF NOT EXISTS rag_source_types (
    id              BIGSERIAL PRIMARY KEY,
    code            VARCHAR(50) NOT NULL UNIQUE,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    default_config  JSONB DEFAULT '{}',
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Джерела документації
CREATE TABLE IF NOT EXISTS rag_sources (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    type_id     BIGINT NOT NULL REFERENCES rag_source_types(id),
    location    VARCHAR(1000) NOT NULL,
    config      JSONB DEFAULT '{}',
    status      VARCHAR(50) NOT NULL DEFAULT 'REGISTERED',
    created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Колекції знань
CREATE TABLE IF NOT EXISTS rag_collections (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL UNIQUE,
    description     TEXT,
    version         VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    embedding_model VARCHAR(255) NOT NULL,
    dimensions      INTEGER NOT NULL,
    chunk_size      INTEGER NOT NULL,
    chunk_overlap   INTEGER NOT NULL,
    tei_base_url    VARCHAR(500),
    status          VARCHAR(50) NOT NULL DEFAULT 'CREATING',
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Завдання
CREATE TABLE IF NOT EXISTS rag_jobs (
    id              BIGSERIAL PRIMARY KEY,
    source_id       BIGINT NOT NULL REFERENCES rag_sources(id),
    action          VARCHAR(50) NOT NULL,
    status          VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    progress        INTEGER DEFAULT 0,
    total_items     INTEGER DEFAULT 0,
    processed_items INTEGER DEFAULT 0,
    error_message   TEXT,
    config_override JSONB,
    started_at      TIMESTAMP,
    completed_at    TIMESTAMP,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Чанки з embeddings
CREATE TABLE IF NOT EXISTS rag_chunks (
    id              BIGSERIAL PRIMARY KEY,
    source_id       BIGINT NOT NULL REFERENCES rag_sources(id) ON DELETE CASCADE,
    collection_id   BIGINT REFERENCES rag_collections(id) ON DELETE SET NULL,
    content         TEXT NOT NULL,
    embedding       vector,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Індекси
CREATE INDEX IF NOT EXISTS idx_jobs_status ON rag_jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_action ON rag_jobs(action);
CREATE INDEX IF NOT EXISTS idx_jobs_source ON rag_jobs(source_id);
CREATE INDEX IF NOT EXISTS idx_chunks_source ON rag_chunks(source_id);
CREATE INDEX IF NOT EXISTS idx_chunks_collection ON rag_chunks(collection_id);
CREATE INDEX IF NOT EXISTS idx_sources_type ON rag_sources(type_id);

-- Початкові типи джерел
INSERT INTO rag_source_types (code, name, description, default_config) VALUES
    ('HTML_SITE', 'HTML сайт', 'Набір HTML-сторінок для парсингу', '{"parser": "jsoup", "follow_links": true, "max_depth": 2}'),
    ('GIT_REPO', 'Git репозиторій', 'GitHub/GitLab репозиторій', '{"branch": "main", "file_patterns": ["*.json", "*.md"]}'),
    ('PDF', 'PDF документ', 'PDF файл для парсингу', '{"parser": "pdfbox", "split_by": "sections"}'),
    ('LOCAL_FILES', 'Локальні файли', 'Файли з локального каталогу', '{"file_patterns": ["*.html", "*.json", "*.md"]}')
ON CONFLICT (code) DO NOTHING;

-- Системні налаштування (key-value)
CREATE TABLE IF NOT EXISTS rag_settings (
    key         VARCHAR(100) PRIMARY KEY,
    value       VARCHAR(1000) NOT NULL,
    description TEXT,
    updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Профілі побудови RAG
CREATE TABLE IF NOT EXISTS rag_build_profiles (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL UNIQUE,
    description     TEXT,
    embedding_model VARCHAR(255) NOT NULL DEFAULT 'nomic-embed-text',
    dimensions      INTEGER NOT NULL DEFAULT 768,
    chunk_size      INTEGER NOT NULL DEFAULT 800,
    chunk_overlap   INTEGER NOT NULL DEFAULT 200,
    is_default      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Початкові налаштування
INSERT INTO rag_settings (key, value, description) VALUES
    ('tei.base-url',             'http://localhost:8080',  'URL TEI сервера'),
    ('tei.batch-size',           '32',                     'Розмір батчу для TEI'),
    ('tei.timeout-seconds',      '60',                     'Таймаут запиту до TEI (секунди)'),
    ('queue.poll-interval-seconds', '5',                   'Інтервал перевірки черги (секунди)'),
    ('queue.max-concurrent-download', '2',                 'Максимум одночасних DOWNLOAD завдань'),
    ('queue.max-concurrent-embed', '1',                    'Максимум одночасних EMBED завдань'),
    ('queue.stale-job-timeout-minutes', '30',              'Таймаут завислих завдань (хвилини)'),
    ('chunking.default-chunk-size', '800',                 'Розмір чанка за замовчуванням (символи)'),
    ('chunking.default-chunk-overlap', '200',              'Перекриття чанків за замовчуванням (символи)'),
    ('search.default-top-k',    '10',                      'Кількість результатів пошуку за замовчуванням'),
    ('search.default-threshold', '0.7',                    'Мінімальна схожість за замовчуванням'),
    ('ui.default-locale',       'uk',                      'Мова інтерфейсу за замовчуванням (uk, en)')
ON CONFLICT (key) DO NOTHING;

-- Початкові профілі побудови
INSERT INTO rag_build_profiles (name, description, embedding_model, dimensions, chunk_size, chunk_overlap, is_default) VALUES
    ('default', 'Стандартний профіль', 'nomic-embed-text', 768, 800, 200, true),
    ('large-chunks', 'Великі чанки для контексту', 'nomic-embed-text', 768, 1500, 300, false),
    ('small-chunks', 'Малі чанки для точності', 'nomic-embed-text', 768, 400, 100, false)
ON CONFLICT (name) DO NOTHING;
