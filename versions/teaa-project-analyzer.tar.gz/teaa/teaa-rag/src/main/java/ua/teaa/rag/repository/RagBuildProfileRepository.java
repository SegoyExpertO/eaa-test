package ua.teaa.rag.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagBuildProfile;

public interface RagBuildProfileRepository extends R2dbcRepository<RagBuildProfile, Long> {
    Mono<RagBuildProfile> findByName(String name);
    Mono<RagBuildProfile> findByIsDefaultTrue();
}
