package ua.teaa.rag.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("rag_build_profiles")
public class RagBuildProfile {
    @Id
    private Long id;
    private String name;
    private String description;
    private String embeddingModel;
    private Integer dimensions;
    private Integer chunkSize;
    private Integer chunkOverlap;
    private Boolean isDefault;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
