package ua.teaa.rag.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagBuildProfile;
import ua.teaa.rag.service.BuildProfileService;

@Tag(name = "Build Profiles", description = "Профілі побудови RAG")
@RestController
@RequestMapping("/api/v1/build-profiles")
@RequiredArgsConstructor
public class BuildProfileController {

    private final BuildProfileService service;

    @GetMapping
    public Flux<RagBuildProfile> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Mono<RagBuildProfile> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @GetMapping("/default")
    public Mono<RagBuildProfile> findDefault() {
        return service.findDefault();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<RagBuildProfile> create(@RequestBody RagBuildProfile profile) {
        return service.create(profile);
    }

    @PutMapping("/{id}")
    public Mono<RagBuildProfile> update(@PathVariable Long id, @RequestBody RagBuildProfile profile) {
        return service.update(id, profile);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }
}
