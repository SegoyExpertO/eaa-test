package ua.teaa.rag.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.rag.entity.RagBuildProfile;
import ua.teaa.rag.repository.RagBuildProfileRepository;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class BuildProfileService {

    private final RagBuildProfileRepository repository;

    public Flux<RagBuildProfile> findAll() {
        return repository.findAll();
    }

    public Mono<RagBuildProfile> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<RagBuildProfile> findDefault() {
        return repository.findByIsDefaultTrue();
    }

    public Mono<RagBuildProfile> create(RagBuildProfile profile) {
        profile.setCreatedAt(LocalDateTime.now());
        profile.setUpdatedAt(LocalDateTime.now());
        if (profile.getIsDefault() == null) profile.setIsDefault(false);
        return repository.save(profile);
    }

    public Mono<RagBuildProfile> update(Long id, RagBuildProfile updated) {
        return repository.findById(id).flatMap(existing -> {
            existing.setName(updated.getName());
            existing.setDescription(updated.getDescription());
            existing.setEmbeddingModel(updated.getEmbeddingModel());
            existing.setDimensions(updated.getDimensions());
            existing.setChunkSize(updated.getChunkSize());
            existing.setChunkOverlap(updated.getChunkOverlap());
            existing.setIsDefault(updated.getIsDefault());
            existing.setUpdatedAt(LocalDateTime.now());
            return repository.save(existing);
        });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id);
    }
}
