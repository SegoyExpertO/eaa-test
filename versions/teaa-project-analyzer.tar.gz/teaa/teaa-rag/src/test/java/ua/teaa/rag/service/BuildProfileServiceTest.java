package ua.teaa.rag.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.rag.entity.RagBuildProfile;
import ua.teaa.rag.repository.RagBuildProfileRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BuildProfileServiceTest {

    @Mock
    private RagBuildProfileRepository repository;

    @InjectMocks
    private BuildProfileService service;

    @Test
    void shouldCreateWithDefaults() {
        var profile = RagBuildProfile.builder()
                .name("test")
                .embeddingModel("nomic-embed-text")
                .dimensions(768)
                .chunkSize(800)
                .chunkOverlap(200)
                .build();

        when(repository.save(any())).thenAnswer(inv -> {
            RagBuildProfile p = inv.getArgument(0);
            p.setId(1L);
            return Mono.just(p);
        });

        StepVerifier.create(service.create(profile))
                .assertNext(p -> {
                    assertThat(p.getId()).isEqualTo(1L);
                    assertThat(p.getIsDefault()).isFalse();
                    assertThat(p.getCreatedAt()).isNotNull();
                })
                .verifyComplete();
    }

    @Test
    void shouldFindDefault() {
        var profile = RagBuildProfile.builder().id(1L).name("default").isDefault(true).build();
        when(repository.findByIsDefaultTrue()).thenReturn(Mono.just(profile));

        StepVerifier.create(service.findDefault())
                .assertNext(p -> assertThat(p.getName()).isEqualTo("default"))
                .verifyComplete();
    }

    @Test
    void shouldUpdate() {
        var existing = RagBuildProfile.builder()
                .id(1L).name("old").embeddingModel("old-model")
                .dimensions(384).chunkSize(500).chunkOverlap(100).isDefault(false)
                .build();
        var updated = RagBuildProfile.builder()
                .name("new").embeddingModel("new-model")
                .dimensions(768).chunkSize(800).chunkOverlap(200).isDefault(true)
                .build();

        when(repository.findById(1L)).thenReturn(Mono.just(existing));
        when(repository.save(any())).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(service.update(1L, updated))
                .assertNext(p -> {
                    assertThat(p.getName()).isEqualTo("new");
                    assertThat(p.getEmbeddingModel()).isEqualTo("new-model");
                    assertThat(p.getDimensions()).isEqualTo(768);
                    assertThat(p.getIsDefault()).isTrue();
                    assertThat(p.getUpdatedAt()).isNotNull();
                })
                .verifyComplete();
    }
}
