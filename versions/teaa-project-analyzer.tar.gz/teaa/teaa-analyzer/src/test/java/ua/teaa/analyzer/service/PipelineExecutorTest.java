package ua.teaa.analyzer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import ua.teaa.analyzer.service.pipeline.PipelineExecutor;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class PipelineExecutorTest {

    @Mock private OllamaClient ollamaClient;
    @Mock private RagSearchClient ragClient;
    @Mock private SettingsService settings;
    @Spy private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private PipelineExecutor executor;

    @Test
    void shouldCountSteps() {
        String pipeline = """
                {"steps":[
                  {"step":1,"parallel":true,"actions":[{"source":"wcag"}]},
                  {"step":2,"actions":[{"type":"aggregate"}]}
                ]}""";

        assertThat(executor.countSteps(pipeline)).isEqualTo(2);
    }

    @Test
    void shouldCountZeroForInvalidPipeline() {
        assertThat(executor.countSteps("invalid")).isEqualTo(0);
        assertThat(executor.countSteps("{}")).isEqualTo(0);
    }

    @Test
    void shouldCountStepsForAllStrategies() {
        String parallel = """
                {"steps":[{"step":1,"parallel":true,"actions":[{"source":"axe-core"},{"source":"wcag"}]},{"step":2,"actions":[{"type":"aggregate"}]}]}""";
        String concrete = """
                {"steps":[{"step":1,"actions":[{"source":"axe-core"}]},{"step":2,"actions":[{"source":"en301549"}]},{"step":3,"actions":[{"source":"wcag"}]}]}""";

        assertThat(executor.countSteps(parallel)).isEqualTo(2);
        assertThat(executor.countSteps(concrete)).isEqualTo(3);
    }
}
