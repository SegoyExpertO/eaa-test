package ua.teaa.analyzer.service;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class TeiEmbedClientTest {

    private MockWebServer mockServer;
    private TeiEmbedClient client;

    @BeforeEach
    void setUp() throws IOException {
        mockServer = new MockWebServer();
        mockServer.start();
        SettingsService settings = mock(SettingsService.class);
        when(settings.getTeiBaseUrl()).thenReturn(mockServer.url("/").toString());
        client = new TeiEmbedClient(settings, WebClient.builder());
    }

    @AfterEach
    void tearDown() throws IOException {
        mockServer.shutdown();
    }

    @Test
    void shouldReturnEmbeddings() {
        mockServer.enqueue(new MockResponse()
                .setBody("[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]")
                .addHeader("Content-Type", "application/json"));

        StepVerifier.create(client.embed(List.of("text1", "text2")))
                .assertNext(result -> assertThat(result).hasSize(2))
                .verifyComplete();
    }

    @Test
    void shouldHandleError() {
        mockServer.enqueue(new MockResponse().setResponseCode(500));

        StepVerifier.create(client.embed(List.of("text")))
                .expectError()
                .verify();
    }
}
