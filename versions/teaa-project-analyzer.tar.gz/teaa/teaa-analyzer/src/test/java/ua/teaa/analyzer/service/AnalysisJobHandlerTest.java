package ua.teaa.analyzer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.analyzer.entity.AnalysisJob;
import ua.teaa.analyzer.entity.AnalysisStrategy;
import ua.teaa.analyzer.repository.AnalysisFileRepository;
import ua.teaa.analyzer.repository.AnalysisJobRepository;
import ua.teaa.analyzer.repository.AnalysisReportRepository;
import ua.teaa.analyzer.service.code.CodeExtractor;
import ua.teaa.analyzer.service.pipeline.PipelineExecutor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnalysisJobHandlerTest {

    @Mock private AnalysisJobRepository jobRepository;
    @Mock private AnalysisFileRepository fileRepository;
    @Mock private AnalysisReportRepository reportRepository;
    @Mock private StrategyService strategyService;
    @Mock private CodeExtractor codeExtractor;
    @Mock private TeiEmbedClient teiClient;
    @Mock private PipelineExecutor pipelineExecutor;
    @Spy private ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private AnalysisJobHandler handler;

    @Test
    void shouldFailWhenNoStrategyFound() {
        var job = AnalysisJob.builder()
                .id(1L)
                .inputType("TEXT")
                .inputText("code")
                .question("test?")
                .build();

        when(strategyService.findDefault()).thenReturn(Mono.empty());
        when(jobRepository.save(any())).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        StepVerifier.create(handler.handle(job))
                .assertNext(j -> assertThat(j.getStatus()).isEqualTo("FAILED"))
                .verifyComplete();
    }

    @Test
    void shouldUseStrategyOverride() {
        var job = AnalysisJob.builder()
                .id(1L)
                .inputType("TEXT")
                .inputText("int main() {}")
                .question("test?")
                .strategyOverride("{\"steps\":[]}")
                .build();

        when(jobRepository.save(any())).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        // Empty pipeline will fail gracefully
        StepVerifier.create(handler.handle(job))
                .assertNext(j -> assertThat(j.getStatus()).isEqualTo("FAILED"))
                .verifyComplete();
    }

    @Test
    void shouldResolveStrategyById() {
        var strategy = AnalysisStrategy.builder()
                .id(1L)
                .name("test")
                .pipeline("{\"steps\":[{\"step\":1,\"actions\":[{\"source\":\"wcag\",\"role\":\"test\"}]}]}")
                .build();

        var job = AnalysisJob.builder()
                .id(1L)
                .inputType("TEXT")
                .inputText("code")
                .question("test?")
                .strategyId(1L)
                .build();

        when(strategyService.findById(1L)).thenReturn(Mono.just(strategy));
        when(jobRepository.save(any())).thenAnswer(inv -> Mono.just(inv.getArgument(0)));
        when(fileRepository.save(any())).thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        // Will proceed but may fail at TEI call - that's expected in unit test
        StepVerifier.create(handler.handle(job))
                .assertNext(j -> assertThat(j.getStatus()).isIn("FAILED", "COMPLETED"))
                .verifyComplete();
    }
}
