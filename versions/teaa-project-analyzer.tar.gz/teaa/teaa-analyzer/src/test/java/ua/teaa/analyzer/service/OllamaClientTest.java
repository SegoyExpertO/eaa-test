package ua.teaa.analyzer.service;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class OllamaClientTest {

    private MockWebServer mockServer;
    private OllamaClient client;
    private SettingsService settings;

    @BeforeEach
    void setUp() throws IOException {
        mockServer = new MockWebServer();
        mockServer.start();
        settings = mock(SettingsService.class);
        when(settings.getOllamaBaseUrl()).thenReturn(mockServer.url("/").toString());
        when(settings.getOllamaModel()).thenReturn("test-model");
        when(settings.getOllamaTimeout()).thenReturn(10L);
        client = new OllamaClient(settings, WebClient.builder());
    }

    @AfterEach
    void tearDown() throws IOException {
        mockServer.shutdown();
    }

    @Test
    void shouldReturnChatResponse() {
        mockServer.enqueue(new MockResponse()
                .setBody("{\"message\":{\"content\":\"{\\\"findings\\\":[]}\"}}")
                .addHeader("Content-Type", "application/json"));

        StepVerifier.create(client.chat("system", "user prompt"))
                .assertNext(response -> assertThat(response).contains("findings"))
                .verifyComplete();
    }

    @Test
    void shouldHandleError() {
        mockServer.enqueue(new MockResponse().setResponseCode(500));

        StepVerifier.create(client.chat("system", "user"))
                .expectError()
                .verify();
    }

    @Test
    void shouldCheckHealth() {
        mockServer.enqueue(new MockResponse().setResponseCode(200)
                .setBody("{\"models\":[]}"));

        StepVerifier.create(client.isHealthy())
                .assertNext(healthy -> assertThat(healthy).isTrue())
                .verifyComplete();
    }

    @Test
    void shouldReturnUnhealthy() {
        mockServer.enqueue(new MockResponse().setResponseCode(503));

        StepVerifier.create(client.isHealthy())
                .assertNext(healthy -> assertThat(healthy).isFalse())
                .verifyComplete();
    }
}
