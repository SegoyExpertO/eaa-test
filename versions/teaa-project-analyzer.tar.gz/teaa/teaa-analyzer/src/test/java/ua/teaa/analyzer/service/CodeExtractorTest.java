package ua.teaa.analyzer.service;

import org.junit.jupiter.api.Test;
import ua.teaa.analyzer.service.code.CodeExtractor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CodeExtractorTest {

    @Test
    void shouldDetectCLanguage() {
        SettingsService settings = mock(SettingsService.class);
        CodeExtractor extractor = new CodeExtractor(settings);

        assertThat(extractor.detectLanguage("#include <stdio.h>\nint main() {}")).isEqualTo("C");
        assertThat(extractor.detectLanguage("Evas_Object *btn = elm_button_add(parent);")).isEqualTo("C");
    }

    @Test
    void shouldDetectCSharp() {
        SettingsService settings = mock(SettingsService.class);
        CodeExtractor extractor = new CodeExtractor(settings);

        assertThat(extractor.detectLanguage("namespace MyApp {\n  class Program {\n    void Main() {};\n  }\n}")).isEqualTo("CSHARP");
    }

    @Test
    void shouldDetectByExtension() {
        SettingsService settings = mock(SettingsService.class);
        CodeExtractor extractor = new CodeExtractor(settings);

        assertThat(extractor.detectLanguageByExtension("main.c")).isEqualTo("C");
        assertThat(extractor.detectLanguageByExtension("App.cs")).isEqualTo("CSHARP");
        assertThat(extractor.detectLanguageByExtension("page.xaml")).isEqualTo("XAML");
        assertThat(extractor.detectLanguageByExtension("index.html")).isEqualTo("HTML");
        assertThat(extractor.detectLanguageByExtension("app.js")).isEqualTo("JS");
    }

    @Test
    void shouldChunkCode() {
        SettingsService settings = mock(SettingsService.class);
        when(settings.getCodeChunkSize()).thenReturn(50);
        when(settings.getCodeChunkOverlap()).thenReturn(10);
        CodeExtractor extractor = new CodeExtractor(settings);

        String code = "line1\nline2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10\n".repeat(5);
        var chunks = extractor.chunkCode(code);

        assertThat(chunks).hasSizeGreaterThan(1);
        // All code should be present
        String joined = String.join("", chunks);
        assertThat(joined).contains("line1");
        assertThat(joined).contains("line10");
    }

    @Test
    void shouldNotChunkSmallCode() {
        SettingsService settings = mock(SettingsService.class);
        when(settings.getCodeChunkSize()).thenReturn(1000);
        when(settings.getCodeChunkOverlap()).thenReturn(100);
        CodeExtractor extractor = new CodeExtractor(settings);

        var chunks = extractor.chunkCode("short code");
        assertThat(chunks).hasSize(1);
    }
}
