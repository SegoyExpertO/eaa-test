package ua.teaa.analyzer.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.analyzer.entity.AnalysisStrategy;
import ua.teaa.analyzer.repository.AnalysisStrategyRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StrategyServiceTest {

    @Mock private AnalysisStrategyRepository repository;
    @Mock private SettingsService settings;
    @InjectMocks private StrategyService service;

    @Test
    void shouldFindDefault() {
        var strategy = AnalysisStrategy.builder().id(1L).name("parallel").isDefault(true).build();
        when(repository.findByIsDefaultTrue()).thenReturn(Mono.just(strategy));

        StepVerifier.create(service.findDefault())
                .assertNext(s -> assertThat(s.getName()).isEqualTo("parallel"))
                .verifyComplete();
    }

    @Test
    void shouldFallbackToSettingsDefault() {
        when(repository.findByIsDefaultTrue()).thenReturn(Mono.empty());
        when(settings.getDefaultStrategy()).thenReturn("concrete-to-formal");
        var strategy = AnalysisStrategy.builder().id(2L).name("concrete-to-formal").build();
        when(repository.findByName("concrete-to-formal")).thenReturn(Mono.just(strategy));

        StepVerifier.create(service.findDefault())
                .assertNext(s -> assertThat(s.getName()).isEqualTo("concrete-to-formal"))
                .verifyComplete();
    }

    @Test
    void shouldCreate() {
        var strategy = AnalysisStrategy.builder().name("custom").pipeline("{}").build();
        when(repository.save(any())).thenAnswer(inv -> {
            AnalysisStrategy s = inv.getArgument(0);
            s.setId(1L);
            return Mono.just(s);
        });

        StepVerifier.create(service.create(strategy))
                .assertNext(s -> {
                    assertThat(s.getId()).isEqualTo(1L);
                    assertThat(s.getIsDefault()).isFalse();
                    assertThat(s.getCreatedAt()).isNotNull();
                })
                .verifyComplete();
    }
}
