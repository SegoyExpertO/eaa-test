package ua.teaa.analyzer.service;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class RagSearchClientTest {

    private MockWebServer mockServer;
    private RagSearchClient client;

    @BeforeEach
    void setUp() throws IOException {
        mockServer = new MockWebServer();
        mockServer.start();
        SettingsService settings = mock(SettingsService.class);
        when(settings.getRagBaseUrl()).thenReturn(mockServer.url("/").toString());
        when(settings.getRagTopK()).thenReturn(5);
        when(settings.getRagThreshold()).thenReturn(0.7);
        client = new RagSearchClient(settings, WebClient.builder());
    }

    @AfterEach
    void tearDown() throws IOException {
        mockServer.shutdown();
    }

    @Test
    void shouldReturnChunks() {
        mockServer.enqueue(new MockResponse()
                .setBody("{\"results\":[{\"queryIndex\":0,\"chunks\":[{\"content\":\"test chunk\",\"similarity\":0.9}]}]}")
                .addHeader("Content-Type", "application/json"));

        StepVerifier.create(client.search(List.of(0.1f, 0.2f), 1L))
                .assertNext(chunks -> {
                    assertThat(chunks).hasSize(1);
                    assertThat(chunks.getFirst().get("content")).isEqualTo("test chunk");
                })
                .verifyComplete();
    }

    @Test
    void shouldHandleEmptyResults() {
        mockServer.enqueue(new MockResponse()
                .setBody("{\"results\":[{\"queryIndex\":0,\"chunks\":[]}]}")
                .addHeader("Content-Type", "application/json"));

        StepVerifier.create(client.search(List.of(0.1f), 1L))
                .assertNext(chunks -> assertThat(chunks).isEmpty())
                .verifyComplete();
    }

    @Test
    void shouldCheckHealth() {
        mockServer.enqueue(new MockResponse().setResponseCode(200));

        StepVerifier.create(client.isHealthy())
                .assertNext(h -> assertThat(h).isTrue())
                .verifyComplete();
    }
}
