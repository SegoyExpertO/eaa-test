-- Analysis strategies (pipeline presets)
CREATE TABLE IF NOT EXISTS analysis_strategies (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    pipeline    JSONB NOT NULL,
    is_default  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Analysis settings (key-value)
CREATE TABLE IF NOT EXISTS analysis_settings (
    key         VARCHAR(100) PRIMARY KEY,
    value       VARCHAR(1000) NOT NULL,
    description TEXT,
    updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Analysis jobs
CREATE TABLE IF NOT EXISTS analysis_jobs (
    id                BIGSERIAL PRIMARY KEY,
    input_type        VARCHAR(50) NOT NULL,
    input_text        TEXT,
    input_filename    VARCHAR(500),
    question          TEXT NOT NULL,
    strategy_id       BIGINT REFERENCES analysis_strategies(id),
    strategy_override JSONB,
    status            VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    current_step      INTEGER DEFAULT 0,
    total_steps       INTEGER DEFAULT 0,
    progress          INTEGER DEFAULT 0,
    error_message     TEXT,
    started_at        TIMESTAMP,
    completed_at      TIMESTAMP,
    created_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Analysis reports
CREATE TABLE IF NOT EXISTS analysis_reports (
    id              BIGSERIAL PRIMARY KEY,
    job_id          BIGINT NOT NULL REFERENCES analysis_jobs(id) ON DELETE CASCADE,
    summary         TEXT,
    overall_status  VARCHAR(50),
    report_data     JSONB DEFAULT '{}',
    step_results    JSONB DEFAULT '{}',
    strategy_used   JSONB DEFAULT '{}',
    files_analyzed  INTEGER DEFAULT 0,
    findings_count  INTEGER DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Analysis files (from archive)
CREATE TABLE IF NOT EXISTS analysis_files (
    id          BIGSERIAL PRIMARY KEY,
    job_id      BIGINT NOT NULL REFERENCES analysis_jobs(id) ON DELETE CASCADE,
    file_path   VARCHAR(1000) NOT NULL,
    content     TEXT NOT NULL,
    language    VARCHAR(50),
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_analysis_jobs_status ON analysis_jobs(status);
CREATE INDEX IF NOT EXISTS idx_analysis_reports_job ON analysis_reports(job_id);
CREATE INDEX IF NOT EXISTS idx_analysis_files_job ON analysis_files(job_id);

-- Seed strategies
INSERT INTO analysis_strategies (name, description, pipeline, is_default) VALUES
    ('parallel', 'Паралельний аналіз з ранжуванням', '{"steps":[{"step":1,"parallel":true,"actions":[{"source":"axe-core","role":"Знайди порушення правил доступності"},{"source":"tizen","role":"Перевір використання Accessibility API"},{"source":"en301549","role":"Перевір відповідність технічним вимогам"},{"source":"wcag","role":"Визнач порушення критеріїв WCAG"}]},{"step":2,"parallel":false,"actions":[{"type":"aggregate","role":"Ранжуй за severity, дедуплікуй, згрупуй по розділах EAA, сформуй фінальний звіт"}]}]}', true),
    ('concrete-to-formal', 'Від конкретного до загального', '{"steps":[{"step":1,"parallel":true,"actions":[{"source":"axe-core","role":"Знайди порушення правил"},{"source":"tizen","role":"Перевір використання API"}]},{"step":2,"parallel":false,"actions":[{"source":"en301549","role":"Деталізуй порушення згідно EN 301 549, визнач severity","input":"step1"}]},{"step":3,"parallel":false,"actions":[{"source":"wcag","role":"Формалізуй у вимогах WCAG, згрупуй по розділах EAA","input":"step2"}]}]}', false),
    ('formal-to-concrete', 'Від загального до конкретного', '{"steps":[{"step":1,"parallel":false,"actions":[{"source":"wcag","role":"Визнач які вимоги WCAG порушує код"}]},{"step":2,"parallel":false,"actions":[{"source":"en301549","role":"Деталізуй технічні вимоги для кожного порушення","input":"step1"}]},{"step":3,"parallel":true,"actions":[{"source":"axe-core","role":"Додай конкретні правила та приклади","input":"step2"},{"source":"tizen","role":"Додай рекомендації з API платформи","input":"step2"}]},{"step":4,"parallel":false,"actions":[{"type":"aggregate","role":"Сформуй фінальний звіт","input":"step3"}]}]}', false)
ON CONFLICT (name) DO NOTHING;

-- Seed settings
INSERT INTO analysis_settings (key, value, description) VALUES
    ('ollama.base-url',           'http://localhost:11434', 'URL Ollama'),
    ('ollama.model',              'qwen2.5:14b',           'Модель LLM'),
    ('ollama.timeout-seconds',    '120',                   'Таймаут LLM (секунди)'),
    ('tei.base-url',              'http://localhost:8080',  'URL TEI'),
    ('rag.base-url',              'http://localhost:8082',  'URL RAG Service'),
    ('rag.wcag-source-id',        '1',                     'sourceId для WCAG у RAG'),
    ('rag.en301549-source-id',    '2',                     'sourceId для EN 301 549'),
    ('rag.axecore-source-id',     '3',                     'sourceId для axe-core'),
    ('rag.tizen-source-id',       '4',                     'sourceId для Tizen'),
    ('rag.top-k',                 '10',                    'Кількість чанків per query'),
    ('rag.threshold',             '0.7',                   'Мінімальна схожість'),
    ('analysis.default-strategy', 'parallel',              'Стратегія за замовчуванням'),
    ('queue.poll-interval-seconds','5',                    'Інтервал черги'),
    ('queue.max-concurrent',      '1',                     'Max одночасних аналізів'),
    ('queue.stale-timeout-minutes','60',                   'Таймаут завислих'),
    ('code.chunk-size',           '1500',                  'Розмір фрагмента коду'),
    ('code.chunk-overlap',        '300',                   'Перекриття фрагментів')
ON CONFLICT (key) DO NOTHING;
