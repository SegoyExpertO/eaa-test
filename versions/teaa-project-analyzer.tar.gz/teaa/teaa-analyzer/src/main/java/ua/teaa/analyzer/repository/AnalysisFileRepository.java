package ua.teaa.analyzer.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisFile;

public interface AnalysisFileRepository extends R2dbcRepository<AnalysisFile, Long> {
    Flux<AnalysisFile> findByJobId(Long jobId);
    Mono<Long> countByJobId(Long jobId);
}
