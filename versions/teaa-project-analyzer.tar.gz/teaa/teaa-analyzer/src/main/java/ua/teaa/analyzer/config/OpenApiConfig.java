package ua.teaa.analyzer.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI().info(new Info()
                .title("TEAA Analyzer API")
                .description("Аналіз вихідного коду на відповідність EAA з використанням RAG та LLM")
                .version("1.0.0"));
    }
}
