package ua.teaa.analyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class TeaaAnalyzerApplication {
    public static void main(String[] args) {
        SpringApplication.run(TeaaAnalyzerApplication.class, args);
    }
}
