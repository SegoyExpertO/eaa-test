package ua.teaa.analyzer.service.code;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ua.teaa.analyzer.entity.AnalysisFile;
import ua.teaa.analyzer.service.SettingsService;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Slf4j
@Service
@RequiredArgsConstructor
public class CodeExtractor {

    private final SettingsService settings;

    private static final Set<String> CODE_EXTENSIONS = Set.of(
            ".c", ".cpp", ".h", ".hpp", ".cs", ".xaml",
            ".html", ".htm", ".js", ".css", ".json", ".xml"
    );

    public List<AnalysisFile> extractFromArchive(byte[] archiveBytes, String filename, Long jobId) {
        List<AnalysisFile> files = new ArrayList<>();

        if (filename.toLowerCase().endsWith(".zip")) {
            files.addAll(extractZip(archiveBytes, jobId));
        } else {
            log.warn("Непідтримуваний формат: {}", filename);
        }

        log.info("Витягнуто {} файлів з {}", files.size(), filename);
        return files;
    }

    public List<AnalysisFile> extractFromText(String text, Long jobId) {
        String language = detectLanguage(text);
        return List.of(AnalysisFile.builder()
                .jobId(jobId)
                .filePath("input.txt")
                .content(text)
                .language(language)
                .build());
    }

    public List<String> chunkCode(String content) {
        int chunkSize = settings.getCodeChunkSize();
        int overlap = settings.getCodeChunkOverlap();

        if (content.length() <= chunkSize) {
            return List.of(content);
        }

        List<String> chunks = new ArrayList<>();
        String[] lines = content.split("\n");
        StringBuilder current = new StringBuilder();

        for (String line : lines) {
            if (current.length() + line.length() > chunkSize && !current.isEmpty()) {
                chunks.add(current.toString());
                // Overlap: keep last N characters
                String overlapText = current.substring(Math.max(0, current.length() - overlap));
                current = new StringBuilder(overlapText);
            }
            current.append(line).append("\n");
        }

        if (!current.isEmpty()) {
            chunks.add(current.toString());
        }

        return chunks;
    }

    public String detectLanguage(String content) {
        if (content.contains("#include") || content.contains("elm_") || content.contains("Evas_Object"))
            return "C";
        if (content.contains("class ") && content.contains("namespace ") && content.contains(";"))
            return "CSHARP";
        if (content.contains("<xaml") || content.contains("xmlns:"))
            return "XAML";
        if (content.contains("<html") || content.contains("<!DOCTYPE"))
            return "HTML";
        if (content.contains("function ") || content.contains("const ") || content.contains("=>"))
            return "JS";
        if (content.contains("{") && content.contains(":") && content.contains(";"))
            return "CSS";
        return "UNKNOWN";
    }

    public String detectLanguageByExtension(String filename) {
        String lower = filename.toLowerCase();
        if (lower.endsWith(".c") || lower.endsWith(".h")) return "C";
        if (lower.endsWith(".cpp") || lower.endsWith(".hpp")) return "CPP";
        if (lower.endsWith(".cs")) return "CSHARP";
        if (lower.endsWith(".xaml")) return "XAML";
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "HTML";
        if (lower.endsWith(".js")) return "JS";
        if (lower.endsWith(".css")) return "CSS";
        return "UNKNOWN";
    }

    private List<AnalysisFile> extractZip(byte[] bytes, Long jobId) {
        List<AnalysisFile> files = new ArrayList<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String name = entry.getName();
                if (!isCodeFile(name)) continue;

                String content = new String(zis.readAllBytes(), StandardCharsets.UTF_8);
                files.add(AnalysisFile.builder()
                        .jobId(jobId)
                        .filePath(name)
                        .content(content)
                        .language(detectLanguageByExtension(name))
                        .build());
            }
        } catch (IOException e) {
            log.error("Помилка розпакування ZIP: {}", e.getMessage());
        }
        return files;
    }

    private boolean isCodeFile(String filename) {
        return CODE_EXTENSIONS.stream().anyMatch(ext -> filename.toLowerCase().endsWith(ext));
    }
}
