package ua.teaa.analyzer.service.pipeline;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.service.OllamaClient;
import ua.teaa.analyzer.service.RagSearchClient;
import ua.teaa.analyzer.service.SettingsService;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PipelineExecutor {

    private final OllamaClient ollamaClient;
    private final RagSearchClient ragClient;
    private final SettingsService settings;
    private final ObjectMapper objectMapper;

    private static final String SYSTEM_TEMPLATE = """
            Ти — експерт з доступності для Tizen TV застосунків.
            %s
            Відповідай ТІЛЬКИ у форматі JSON.
            """;

    /**
     * Виконує pipeline і повертає результати всіх кроків.
     *
     * @param pipelineJson JSON конфігурація pipeline
     * @param codeContext  підготовлений контекст коду
     * @param embeddings   embeddings фрагментів коду
     * @param question     питання користувача
     * @return Map з step results
     */
    @SuppressWarnings("unchecked")
    public Mono<Map<String, Object>> execute(String pipelineJson, String codeContext,
                                              List<List<Float>> embeddings, String question) {
        try {
            Map<String, Object> pipeline = objectMapper.readValue(pipelineJson, new TypeReference<>() {});
            List<Map<String, Object>> steps = (List<Map<String, Object>>) pipeline.get("steps");

            if (steps == null || steps.isEmpty()) {
                return Mono.error(new IllegalArgumentException("Pipeline не містить кроків"));
            }

            Map<String, Object> allResults = new LinkedHashMap<>();

            return Flux.fromIterable(steps)
                    .concatMap(step -> executeStep(step, codeContext, embeddings, question, allResults)
                            .doOnSuccess(result -> {
                                int stepNum = ((Number) step.get("step")).intValue();
                                allResults.put("step" + stepNum, result);
                                log.info("Pipeline step {} завершено", stepNum);
                            }))
                    .then(Mono.just(allResults));

        } catch (Exception e) {
            return Mono.error(new RuntimeException("Помилка парсингу pipeline: " + e.getMessage(), e));
        }
    }

    public int countSteps(String pipelineJson) {
        try {
            Map<String, Object> pipeline = objectMapper.readValue(pipelineJson, new TypeReference<>() {});
            List<?> steps = (List<?>) pipeline.get("steps");
            return steps != null ? steps.size() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    @SuppressWarnings("unchecked")
    private Mono<Map<String, Object>> executeStep(Map<String, Object> step, String codeContext,
                                                    List<List<Float>> embeddings, String question,
                                                    Map<String, Object> previousResults) {
        List<Map<String, Object>> actions = (List<Map<String, Object>>) step.get("actions");
        boolean parallel = Boolean.TRUE.equals(step.get("parallel"));

        if (parallel) {
            return Flux.fromIterable(actions)
                    .flatMap(action -> executeAction(action, codeContext, embeddings, question, previousResults))
                    .collectList()
                    .map(results -> {
                        Map<String, Object> combined = new LinkedHashMap<>();
                        combined.put("actions", results);
                        return combined;
                    });
        } else {
            return Flux.fromIterable(actions)
                    .concatMap(action -> executeAction(action, codeContext, embeddings, question, previousResults))
                    .collectList()
                    .map(results -> {
                        Map<String, Object> combined = new LinkedHashMap<>();
                        combined.put("actions", results);
                        return combined;
                    });
        }
    }

    @SuppressWarnings("unchecked")
    private Mono<Map<String, Object>> executeAction(Map<String, Object> action, String codeContext,
                                                      List<List<Float>> embeddings, String question,
                                                      Map<String, Object> previousResults) {
        String type = (String) action.getOrDefault("type", "source");
        String source = (String) action.get("source");
        String role = (String) action.getOrDefault("role", "Аналізуй код");
        String input = (String) action.get("input");

        if ("aggregate".equals(type)) {
            return executeAggregate(role, codeContext, question, previousResults);
        }

        // RAG search з відповідним sourceId
        Long sourceId = settings.getSourceId(source);

        return Flux.fromIterable(embeddings)
                .flatMap(emb -> ragClient.search(emb, sourceId))
                .collectList()
                .flatMap(allChunks -> {
                    // Flatten і deduplicate chunks
                    List<Map<String, Object>> flatChunks = allChunks.stream()
                            .flatMap(List::stream)
                            .collect(Collectors.toList());

                    String chunksContext = flatChunks.stream()
                            .map(c -> String.valueOf(c.getOrDefault("content", "")))
                            .collect(Collectors.joining("\n\n"));

                    // Додаємо результат попереднього кроку якщо вказано
                    String prevContext = "";
                    if (input != null && previousResults.containsKey(input)) {
                        try {
                            prevContext = objectMapper.writeValueAsString(previousResults.get(input));
                        } catch (Exception e) {
                            prevContext = previousResults.get(input).toString();
                        }
                    }

                    String systemPrompt = SYSTEM_TEMPLATE.formatted(role);
                    String userPrompt = buildUserPrompt(codeContext, chunksContext, prevContext, question, source);

                    return ollamaClient.chat(systemPrompt, userPrompt)
                            .map(response -> {
                                Map<String, Object> result = new LinkedHashMap<>();
                                result.put("source", source);
                                result.put("role", role);
                                result.put("chunksUsed", flatChunks.size());
                                try {
                                    result.put("result", objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {}));
                                } catch (Exception e) {
                                    result.put("result", response);
                                }
                                return result;
                            });
                });
    }

    private Mono<Map<String, Object>> executeAggregate(String role, String codeContext,
                                                         String question, Map<String, Object> previousResults) {
        String systemPrompt = SYSTEM_TEMPLATE.formatted(role);
        String prevJson;
        try {
            prevJson = objectMapper.writeValueAsString(previousResults);
        } catch (Exception e) {
            prevJson = previousResults.toString();
        }

        String userPrompt = """
                === РЕЗУЛЬТАТИ ПОПЕРЕДНІХ ЕТАПІВ ===
                %s
                
                === КОД ===
                %s
                
                === ПИТАННЯ ===
                %s
                """.formatted(prevJson, codeContext, question);

        return ollamaClient.chat(systemPrompt, userPrompt)
                .map(response -> {
                    Map<String, Object> result = new LinkedHashMap<>();
                    result.put("type", "aggregate");
                    result.put("role", role);
                    try {
                        result.put("result", objectMapper.readValue(response, new TypeReference<Map<String, Object>>() {}));
                    } catch (Exception e) {
                        result.put("result", response);
                    }
                    return result;
                });
    }

    private String buildUserPrompt(String code, String chunks, String prevContext, String question, String source) {
        StringBuilder sb = new StringBuilder();
        if (!prevContext.isEmpty()) {
            sb.append("=== РЕЗУЛЬТАТИ ПОПЕРЕДНЬОГО ЕТАПУ ===\n").append(prevContext).append("\n\n");
        }
        sb.append("=== СТАНДАРТИ (").append(source).append(") ===\n").append(chunks).append("\n\n");
        sb.append("=== КОД ===\n").append(code).append("\n\n");
        sb.append("=== ПИТАННЯ ===\n").append(question);
        return sb.toString();
    }
}
