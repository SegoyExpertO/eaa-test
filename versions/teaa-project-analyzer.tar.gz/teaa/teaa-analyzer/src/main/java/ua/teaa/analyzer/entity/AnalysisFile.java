package ua.teaa.analyzer.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("analysis_files")
public class AnalysisFile {
    @Id
    private Long id;
    private Long jobId;
    private String filePath;
    private String content;
    private String language;
    private LocalDateTime createdAt;
}
