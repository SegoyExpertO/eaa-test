package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class TeiEmbedClient {

    private final SettingsService settings;
    private final WebClient.Builder webClientBuilder;

    @SuppressWarnings("unchecked")
    public Mono<List<List<Float>>> embed(List<String> texts) {
        String baseUrl = settings.getTeiBaseUrl();

        return webClientBuilder.build()
                .post()
                .uri(baseUrl + "/embed")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(Map.of("inputs", texts, "normalize", true, "truncate", true))
                .retrieve()
                .bodyToMono(List.class)
                .timeout(Duration.ofSeconds(60))
                .doOnSuccess(r -> log.debug("TEI: {} embeddings", texts.size()))
                .doOnError(e -> log.error("TEI помилка: {}", e.getMessage()));
    }

    public Mono<Boolean> isHealthy() {
        return webClientBuilder.build()
                .get()
                .uri(settings.getTeiBaseUrl() + "/health")
                .retrieve()
                .toBodilessEntity()
                .map(r -> r.getStatusCode().is2xxSuccessful())
                .timeout(Duration.ofSeconds(5))
                .onErrorReturn(false);
    }
}
