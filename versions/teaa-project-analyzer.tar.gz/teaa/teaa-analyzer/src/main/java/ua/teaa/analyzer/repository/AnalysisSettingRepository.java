package ua.teaa.analyzer.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisSetting;

public interface AnalysisSettingRepository extends R2dbcRepository<AnalysisSetting, String> {
    Mono<AnalysisSetting> findByKey(String key);
}
