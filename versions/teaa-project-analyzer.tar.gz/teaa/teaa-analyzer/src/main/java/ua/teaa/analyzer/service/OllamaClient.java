package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class OllamaClient {

    private final SettingsService settings;
    private final WebClient.Builder webClientBuilder;

    public Mono<String> chat(String systemPrompt, String userPrompt) {
        String baseUrl = settings.getOllamaBaseUrl();
        String model = settings.getOllamaModel();
        long timeout = settings.getOllamaTimeout();

        log.debug("Ollama: model={}, prompt length={}", model, userPrompt.length());

        return webClientBuilder.build()
                .post()
                .uri(baseUrl + "/api/chat")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(Map.of(
                        "model", model,
                        "messages", List.of(
                                Map.of("role", "system", "content", systemPrompt),
                                Map.of("role", "user", "content", userPrompt)
                        ),
                        "format", "json",
                        "stream", false
                ))
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(timeout))
                .map(response -> {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> message = (Map<String, Object>) response.get("message");
                    return message != null ? (String) message.get("content") : "";
                })
                .doOnSuccess(r -> log.debug("Ollama: відповідь {} символів", r.length()))
                .doOnError(e -> log.error("Ollama помилка: {}", e.getMessage()));
    }

    public Mono<Boolean> isHealthy() {
        return webClientBuilder.build()
                .get()
                .uri(settings.getOllamaBaseUrl() + "/api/tags")
                .retrieve()
                .toBodilessEntity()
                .map(r -> r.getStatusCode().is2xxSuccessful())
                .timeout(Duration.ofSeconds(5))
                .onErrorReturn(false);
    }
}
