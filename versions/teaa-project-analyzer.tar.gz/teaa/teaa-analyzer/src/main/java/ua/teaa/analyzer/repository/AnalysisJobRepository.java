package ua.teaa.analyzer.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisJob;

public interface AnalysisJobRepository extends R2dbcRepository<AnalysisJob, Long> {

    @Query("SELECT * FROM analysis_jobs ORDER BY created_at DESC")
    Flux<AnalysisJob> findAllOrdered();

    Flux<AnalysisJob> findByStatus(String status);

    @Query("SELECT COUNT(*) FROM analysis_jobs WHERE status = 'RUNNING'")
    Mono<Long> countRunning();

    @Query("SELECT * FROM analysis_jobs WHERE status = 'PENDING' ORDER BY created_at LIMIT 1")
    Mono<AnalysisJob> findNextPending();

    @Query("SELECT * FROM analysis_jobs WHERE status = 'RUNNING' AND started_at < NOW() - INTERVAL '1 minute' * :timeoutMinutes")
    Flux<AnalysisJob> findStaleJobs(int timeoutMinutes);
}
