package ua.teaa.analyzer.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisReport;
import ua.teaa.analyzer.repository.AnalysisReportRepository;

import java.util.Map;

@Tag(name = "Reports", description = "Звіти аналізу")
@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
public class ReportController {

    private final AnalysisReportRepository repository;

    @GetMapping
    public Flux<AnalysisReport> findAll() {
        return repository.findAllOrdered();
    }

    @GetMapping("/{id}")
    public Mono<AnalysisReport> findById(@PathVariable Long id) {
        return repository.findById(id);
    }

    @GetMapping("/{id}/summary")
    public Mono<Map<String, Object>> getSummary(@PathVariable Long id) {
        return repository.findById(id)
                .map(r -> Map.<String, Object>of(
                        "summary", r.getSummary() != null ? r.getSummary() : "",
                        "overallStatus", r.getOverallStatus() != null ? r.getOverallStatus() : "",
                        "findingsCount", r.getFindingsCount() != null ? r.getFindingsCount() : 0,
                        "filesAnalyzed", r.getFilesAnalyzed() != null ? r.getFilesAnalyzed() : 0
                ));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return repository.deleteById(id);
    }
}
