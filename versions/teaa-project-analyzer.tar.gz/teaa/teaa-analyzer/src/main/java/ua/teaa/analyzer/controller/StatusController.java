package ua.teaa.analyzer.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.repository.AnalysisJobRepository;
import ua.teaa.analyzer.repository.AnalysisReportRepository;
import ua.teaa.analyzer.service.OllamaClient;
import ua.teaa.analyzer.service.RagSearchClient;
import ua.teaa.analyzer.service.TeiEmbedClient;

import java.util.HashMap;
import java.util.Map;

@Tag(name = "Status", description = "Стан системи")
@RestController
@RequestMapping("/api/v1/status")
@RequiredArgsConstructor
public class StatusController {

    private final AnalysisJobRepository jobRepository;
    private final AnalysisReportRepository reportRepository;
    private final OllamaClient ollamaClient;
    private final TeiEmbedClient teiClient;
    private final RagSearchClient ragClient;

    @GetMapping
    public Mono<Map<String, Object>> status() {
        return Mono.zip(
                jobRepository.countRunning(),
                jobRepository.findByStatus("PENDING").count(),
                reportRepository.count(),
                ollamaClient.isHealthy(),
                teiClient.isHealthy(),
                ragClient.isHealthy()
        ).map(tuple -> {
            Map<String, Object> result = new HashMap<>();
            result.put("runningJobs", tuple.getT1());
            result.put("pendingJobs", tuple.getT2());
            result.put("totalReports", tuple.getT3());
            result.put("ollamaHealthy", tuple.getT4());
            result.put("teiHealthy", tuple.getT5());
            result.put("ragHealthy", tuple.getT6());
            return result;
        });
    }
}
