package ua.teaa.analyzer.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisJob;
import ua.teaa.analyzer.repository.AnalysisJobRepository;

import java.time.LocalDateTime;
import java.util.Map;

@Tag(name = "Analyze", description = "Аналіз коду")
@RestController
@RequestMapping("/api/v1/analyze")
@RequiredArgsConstructor
public class AnalyzeController {

    private final AnalysisJobRepository jobRepository;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<AnalysisJob> analyzeText(@RequestBody Map<String, Object> request) {
        AnalysisJob job = AnalysisJob.builder()
                .inputType("TEXT")
                .inputText((String) request.get("text"))
                .question((String) request.get("question"))
                .strategyId(request.containsKey("strategyId") ? ((Number) request.get("strategyId")).longValue() : null)
                .strategyOverride(request.containsKey("strategyOverride") ? request.get("strategyOverride").toString() : null)
                .status("PENDING")
                .progress(0)
                .currentStep(0)
                .createdAt(LocalDateTime.now())
                .build();
        return jobRepository.save(job);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<AnalysisJob> analyzeArchive(
            @RequestPart("file") FilePart file,
            @RequestPart("question") String question,
            @RequestPart(value = "strategyId", required = false) String strategyId) {

        return DataBufferUtils.join(file.content())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return java.util.Base64.getEncoder().encodeToString(bytes);
                })
                .flatMap(base64 -> {
                    AnalysisJob job = AnalysisJob.builder()
                            .inputType("ARCHIVE")
                            .inputText(base64)
                            .inputFilename(file.filename())
                            .question(question)
                            .strategyId(strategyId != null ? Long.parseLong(strategyId) : null)
                            .status("PENDING")
                            .progress(0)
                            .currentStep(0)
                            .createdAt(LocalDateTime.now())
                            .build();
                    return jobRepository.save(job);
                });
    }

    @GetMapping("/jobs")
    public Flux<AnalysisJob> listJobs() {
        return jobRepository.findAllOrdered();
    }

    @GetMapping("/jobs/{id}")
    public Mono<AnalysisJob> getJob(@PathVariable Long id) {
        return jobRepository.findById(id);
    }
}
