package ua.teaa.analyzer.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisReport;

public interface AnalysisReportRepository extends R2dbcRepository<AnalysisReport, Long> {
    Mono<AnalysisReport> findByJobId(Long jobId);

    @Query("SELECT * FROM analysis_reports ORDER BY created_at DESC")
    Flux<AnalysisReport> findAllOrdered();
}
