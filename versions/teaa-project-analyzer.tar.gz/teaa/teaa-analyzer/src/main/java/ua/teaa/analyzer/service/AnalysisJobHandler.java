package ua.teaa.analyzer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisFile;
import ua.teaa.analyzer.entity.AnalysisJob;
import ua.teaa.analyzer.entity.AnalysisReport;
import ua.teaa.analyzer.entity.AnalysisStrategy;
import ua.teaa.analyzer.repository.AnalysisFileRepository;
import ua.teaa.analyzer.repository.AnalysisJobRepository;
import ua.teaa.analyzer.repository.AnalysisReportRepository;
import ua.teaa.analyzer.service.code.CodeExtractor;
import ua.teaa.analyzer.service.pipeline.PipelineExecutor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class AnalysisJobHandler {

    private final AnalysisJobRepository jobRepository;
    private final AnalysisFileRepository fileRepository;
    private final AnalysisReportRepository reportRepository;
    private final StrategyService strategyService;
    private final CodeExtractor codeExtractor;
    private final TeiEmbedClient teiClient;
    private final PipelineExecutor pipelineExecutor;
    private final ObjectMapper objectMapper;

    public Mono<AnalysisJob> handle(AnalysisJob job) {
        return resolvePipeline(job)
                .flatMap(pipeline -> {
                    int totalSteps = pipelineExecutor.countSteps(pipeline);
                    job.setTotalSteps(totalSteps);
                    job.setCurrentStep(0);
                    job.setStatus("RUNNING");
                    job.setStartedAt(LocalDateTime.now());
                    return jobRepository.save(job).thenReturn(pipeline);
                })
                .flatMap(pipeline -> processJob(job, pipeline))
                .onErrorResume(e -> {
                    log.error("Помилка аналізу job id={}: {}", job.getId(), e.getMessage());
                    job.setStatus("FAILED");
                    job.setErrorMessage(e.getMessage());
                    job.setCompletedAt(LocalDateTime.now());
                    return jobRepository.save(job);
                });
    }

    private Mono<AnalysisJob> processJob(AnalysisJob job, String pipeline) {
        // 1. Extract code files
        List<AnalysisFile> files;
        if ("TEXT".equals(job.getInputType())) {
            files = codeExtractor.extractFromText(job.getInputText(), job.getId());
        } else {
            // Archive bytes stored in inputText as base64 for simplicity
            // In production, use file storage
            files = List.of();
        }

        return Flux.fromIterable(files)
                .flatMap(fileRepository::save)
                .collectList()
                .flatMap(savedFiles -> {
                    // 2. Build code context
                    String codeContext = savedFiles.stream()
                            .map(f -> "=== " + f.getFilePath() + " (" + f.getLanguage() + ") ===\n" + f.getContent())
                            .collect(Collectors.joining("\n\n"));

                    // 3. Chunk and embed code
                    List<String> codeChunks = savedFiles.stream()
                            .flatMap(f -> codeExtractor.chunkCode(f.getContent()).stream())
                            .toList();

                    if (codeChunks.isEmpty()) {
                        return Mono.error(new RuntimeException("Не знайдено коду для аналізу"));
                    }

                    return teiClient.embed(codeChunks)
                            .flatMap(embeddings -> {
                                // 4. Execute pipeline
                                return pipelineExecutor.execute(pipeline, codeContext,
                                        castEmbeddings(embeddings), job.getQuestion());
                            })
                            .flatMap(stepResults -> {
                                // 5. Save report
                                return saveReport(job, stepResults, pipeline, savedFiles.size());
                            });
                });
    }

    private Mono<AnalysisJob> saveReport(AnalysisJob job, Map<String, Object> stepResults,
                                          String pipeline, int filesCount) {
        try {
            // Extract final result (last step)
            String lastKey = "step" + job.getTotalSteps();
            Object finalResult = stepResults.getOrDefault(lastKey, stepResults);

            String reportDataJson = objectMapper.writeValueAsString(finalResult);
            String stepResultsJson = objectMapper.writeValueAsString(stepResults);

            // Try to extract summary and status from final result
            String summary = "Аналіз завершено";
            String overallStatus = "PARTIAL";
            int findingsCount = 0;

            if (finalResult instanceof Map<?, ?> finalMap) {
                Object result = finalMap.get("result");
                if (result instanceof Map<?, ?> resultMap) {
                    if (resultMap.containsKey("summary")) summary = resultMap.get("summary").toString();
                    if (resultMap.containsKey("overallStatus")) overallStatus = resultMap.get("overallStatus").toString();
                    if (resultMap.containsKey("totalFindings")) findingsCount = ((Number) resultMap.get("totalFindings")).intValue();
                }
            }

            AnalysisReport report = AnalysisReport.builder()
                    .jobId(job.getId())
                    .summary(summary)
                    .overallStatus(overallStatus)
                    .reportData(reportDataJson)
                    .stepResults(stepResultsJson)
                    .strategyUsed(pipeline)
                    .filesAnalyzed(filesCount)
                    .findingsCount(findingsCount)
                    .createdAt(LocalDateTime.now())
                    .build();

            return reportRepository.save(report)
                    .flatMap(saved -> {
                        job.setStatus("COMPLETED");
                        job.setProgress(100);
                        job.setCompletedAt(LocalDateTime.now());
                        return jobRepository.save(job);
                    });

        } catch (Exception e) {
            return Mono.error(new RuntimeException("Помилка збереження звіту: " + e.getMessage(), e));
        }
    }

    private Mono<String> resolvePipeline(AnalysisJob job) {
        // Priority: strategyOverride > strategyId > default
        if (job.getStrategyOverride() != null && !job.getStrategyOverride().isBlank()) {
            return Mono.just(job.getStrategyOverride());
        }
        if (job.getStrategyId() != null) {
            return strategyService.findById(job.getStrategyId())
                    .map(AnalysisStrategy::getPipeline);
        }
        return strategyService.findDefault()
                .map(AnalysisStrategy::getPipeline);
    }

    @SuppressWarnings("unchecked")
    private List<List<Float>> castEmbeddings(List<?> raw) {
        return raw.stream()
                .map(item -> ((List<?>) item).stream()
                        .map(v -> ((Number) v).floatValue())
                        .toList())
                .toList();
    }
}
