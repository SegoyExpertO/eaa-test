package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ua.teaa.analyzer.repository.AnalysisJobRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobQueueService implements ApplicationRunner {

    private final AnalysisJobRepository jobRepository;
    private final AnalysisJobHandler jobHandler;
    private final SettingsService settings;

    @Override
    public void run(ApplicationArguments args) {
        int timeout = settings.getStaleTimeout();
        log.info("Перевірка завислих завдань (таймаут: {} хв)...", timeout);
        jobRepository.findStaleJobs(timeout)
                .flatMap(job -> {
                    log.warn("Завислe завдання id={} — повертаємо в PENDING", job.getId());
                    job.setStatus("PENDING");
                    job.setStartedAt(null);
                    return jobRepository.save(job);
                })
                .collectList()
                .doOnSuccess(jobs -> log.info("Відновлено {} завислих завдань", jobs.size()))
                .block();
    }

    @Scheduled(fixedDelayString = "${teaa.queue.poll-interval-seconds:5}000")
    public void pollQueue() {
        int maxConcurrent = settings.getMaxConcurrent();

        jobRepository.countRunning()
                .flatMap(running -> {
                    if (running >= maxConcurrent) return reactor.core.publisher.Mono.empty();
                    return jobRepository.findNextPending();
                })
                .flatMap(jobHandler::handle)
                .subscribe(
                        job -> log.debug("Завдання id={} оброблено", job.getId()),
                        error -> log.error("Помилка черги: {}", error.getMessage())
                );
    }
}
