package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class RagSearchClient {

    private final SettingsService settings;
    private final WebClient.Builder webClientBuilder;

    @SuppressWarnings("unchecked")
    public Mono<List<Map<String, Object>>> search(List<Float> embedding, Long sourceId) {
        String ragUrl = settings.getRagBaseUrl();
        int topK = settings.getRagTopK();
        double threshold = settings.getRagThreshold();

        Map<String, Object> query = new java.util.HashMap<>();
        query.put("embedding", embedding);
        query.put("topK", topK);

        Map<String, Object> request = new java.util.HashMap<>();
        request.put("queries", List.of(query));
        request.put("threshold", threshold);
        if (sourceId != null) request.put("sourceId", sourceId);

        return webClientBuilder.build()
                .post()
                .uri(ragUrl + "/api/v1/search")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(30))
                .map(response -> {
                    List<Map<String, Object>> results = (List<Map<String, Object>>) response.get("results");
                    if (results != null && !results.isEmpty()) {
                        return (List<Map<String, Object>>) results.getFirst().get("chunks");
                    }
                    return List.<Map<String, Object>>of();
                })
                .doOnSuccess(chunks -> log.debug("RAG search: sourceId={}, знайдено {} чанків", sourceId, chunks.size()))
                .doOnError(e -> log.error("RAG search помилка: {}", e.getMessage()));
    }

    public Mono<Boolean> isHealthy() {
        return webClientBuilder.build()
                .get()
                .uri(settings.getRagBaseUrl() + "/api/v1/status")
                .retrieve()
                .toBodilessEntity()
                .map(r -> r.getStatusCode().is2xxSuccessful())
                .timeout(Duration.ofSeconds(5))
                .onErrorReturn(false);
    }
}
