package ua.teaa.analyzer.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisStrategy;
import ua.teaa.analyzer.service.StrategyService;

@Tag(name = "Strategies", description = "Стратегії аналізу")
@RestController
@RequestMapping("/api/v1/strategies")
@RequiredArgsConstructor
public class StrategyController {

    private final StrategyService service;

    @GetMapping
    public Flux<AnalysisStrategy> findAll() { return service.findAll(); }

    @GetMapping("/{id}")
    public Mono<AnalysisStrategy> findById(@PathVariable Long id) { return service.findById(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<AnalysisStrategy> create(@RequestBody AnalysisStrategy strategy) { return service.create(strategy); }

    @PutMapping("/{id}")
    public Mono<AnalysisStrategy> update(@PathVariable Long id, @RequestBody AnalysisStrategy strategy) {
        return service.update(id, strategy);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) { return service.delete(id); }
}
