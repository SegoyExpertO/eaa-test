package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisSetting;
import ua.teaa.analyzer.repository.AnalysisSettingRepository;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class SettingsService implements ApplicationRunner {

    private final AnalysisSettingRepository repository;
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    @Override
    public void run(ApplicationArguments args) {
        reloadCache().block();
        log.info("Завантажено {} налаштувань", cache.size());
    }

    public Mono<Void> reloadCache() {
        return repository.findAll()
                .doOnNext(s -> cache.put(s.getKey(), s.getValue()))
                .then();
    }

    public String getString(String key, String def) { return cache.getOrDefault(key, def); }
    public int getInt(String key, int def) {
        try { return Integer.parseInt(cache.getOrDefault(key, String.valueOf(def))); }
        catch (Exception e) { return def; }
    }
    public long getLong(String key, long def) {
        try { return Long.parseLong(cache.getOrDefault(key, String.valueOf(def))); }
        catch (Exception e) { return def; }
    }
    public double getDouble(String key, double def) {
        try { return Double.parseDouble(cache.getOrDefault(key, String.valueOf(def))); }
        catch (Exception e) { return def; }
    }

    public String getOllamaBaseUrl() { return getString("ollama.base-url", "http://localhost:11434"); }
    public String getOllamaModel() { return getString("ollama.model", "qwen2.5:14b"); }
    public long getOllamaTimeout() { return getLong("ollama.timeout-seconds", 120); }
    public String getTeiBaseUrl() { return getString("tei.base-url", "http://localhost:8080"); }
    public String getRagBaseUrl() { return getString("rag.base-url", "http://localhost:8082"); }
    public int getRagTopK() { return getInt("rag.top-k", 10); }
    public double getRagThreshold() { return getDouble("rag.threshold", 0.7); }
    public String getDefaultStrategy() { return getString("analysis.default-strategy", "parallel"); }
    public int getMaxConcurrent() { return getInt("queue.max-concurrent", 1); }
    public int getStaleTimeout() { return getInt("queue.stale-timeout-minutes", 60); }
    public int getCodeChunkSize() { return getInt("code.chunk-size", 1500); }
    public int getCodeChunkOverlap() { return getInt("code.chunk-overlap", 300); }

    public Long getSourceId(String source) {
        return switch (source) {
            case "wcag" -> getLong("rag.wcag-source-id", 1);
            case "en301549" -> getLong("rag.en301549-source-id", 2);
            case "axe-core" -> getLong("rag.axecore-source-id", 3);
            case "tizen" -> getLong("rag.tizen-source-id", 4);
            default -> null;
        };
    }

    public Flux<AnalysisSetting> findAll() { return repository.findAll(); }
    public Mono<AnalysisSetting> update(String key, String value) {
        return repository.findByKey(key).flatMap(s -> {
            s.setValue(value);
            s.setUpdatedAt(LocalDateTime.now());
            return repository.save(s);
        }).doOnSuccess(s -> { if (s != null) cache.put(key, value); });
    }
}
