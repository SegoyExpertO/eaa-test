package ua.teaa.analyzer.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisStrategy;

public interface AnalysisStrategyRepository extends R2dbcRepository<AnalysisStrategy, Long> {
    Mono<AnalysisStrategy> findByName(String name);
    Mono<AnalysisStrategy> findByIsDefaultTrue();
}
