package ua.teaa.analyzer.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisSetting;
import ua.teaa.analyzer.service.SettingsService;

import java.util.Map;

@Tag(name = "Settings", description = "Налаштування аналізатора")
@RestController
@RequestMapping("/api/v1/settings")
@RequiredArgsConstructor
public class SettingsController {

    private final SettingsService service;

    @GetMapping
    public Flux<AnalysisSetting> findAll() { return service.findAll(); }

    @PutMapping("/{key}")
    public Mono<AnalysisSetting> update(@PathVariable String key, @RequestBody Map<String, String> body) {
        return service.update(key, body.get("value"));
    }

    @PostMapping("/reload")
    public Mono<Void> reload() { return service.reloadCache(); }
}
