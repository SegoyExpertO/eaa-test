package ua.teaa.analyzer.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("analysis_jobs")
public class AnalysisJob {
    @Id
    private Long id;
    private String inputType;
    private String inputText;
    private String inputFilename;
    private String question;
    private Long strategyId;
    private String strategyOverride;
    private String status;
    private Integer currentStep;
    private Integer totalSteps;
    private Integer progress;
    private String errorMessage;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private LocalDateTime createdAt;

    public enum Status { PENDING, RUNNING, COMPLETED, FAILED }
    public enum InputType { TEXT, ARCHIVE }
}
