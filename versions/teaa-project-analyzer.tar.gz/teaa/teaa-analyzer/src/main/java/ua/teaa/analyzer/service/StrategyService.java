package ua.teaa.analyzer.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.analyzer.entity.AnalysisStrategy;
import ua.teaa.analyzer.repository.AnalysisStrategyRepository;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class StrategyService {

    private final AnalysisStrategyRepository repository;
    private final SettingsService settings;

    public Flux<AnalysisStrategy> findAll() { return repository.findAll(); }
    public Mono<AnalysisStrategy> findById(Long id) { return repository.findById(id); }
    public Mono<AnalysisStrategy> findByName(String name) { return repository.findByName(name); }

    public Mono<AnalysisStrategy> findDefault() {
        return repository.findByIsDefaultTrue()
                .switchIfEmpty(repository.findByName(settings.getDefaultStrategy()));
    }

    public Mono<AnalysisStrategy> create(AnalysisStrategy s) {
        s.setCreatedAt(LocalDateTime.now());
        s.setUpdatedAt(LocalDateTime.now());
        if (s.getIsDefault() == null) s.setIsDefault(false);
        return repository.save(s);
    }

    public Mono<AnalysisStrategy> update(Long id, AnalysisStrategy updated) {
        return repository.findById(id).flatMap(existing -> {
            existing.setName(updated.getName());
            existing.setDescription(updated.getDescription());
            existing.setPipeline(updated.getPipeline());
            existing.setIsDefault(updated.getIsDefault());
            existing.setUpdatedAt(LocalDateTime.now());
            return repository.save(existing);
        });
    }

    public Mono<Void> delete(Long id) { return repository.deleteById(id); }
}
