package ua.teaa.analyzer.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("analysis_reports")
public class AnalysisReport {
    @Id
    private Long id;
    private Long jobId;
    private String summary;
    private String overallStatus;
    private String reportData;
    private String stepResults;
    private String strategyUsed;
    private Integer filesAnalyzed;
    private Integer findingsCount;
    private LocalDateTime createdAt;
}
