CREATE TABLE IF NOT EXISTS gateway_routes (
    id              BIGSERIAL PRIMARY KEY,
    route_id        VARCHAR(100) NOT NULL UNIQUE,
    path            VARCHAR(500) NOT NULL,
    target          VARCHAR(500) NOT NULL,
    rewrite_from    VARCHAR(500),
    rewrite_to      VARCHAR(500),
    strip_prefix    INTEGER NOT NULL DEFAULT 0,
    order_num       INTEGER NOT NULL DEFAULT 100,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gateway_settings (
    key         VARCHAR(100) PRIMARY KEY,
    value       VARCHAR(1000) NOT NULL,
    description TEXT,
    updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Seed routes
INSERT INTO gateway_routes (route_id, path, target, strip_prefix, order_num) VALUES
    ('rag-api',         '/rag/api/**',          'http://teaa-rag:8082',             1,  10),
    ('rag-swagger',     '/rag/swagger-ui/**',   'http://teaa-rag:8082',             1,  15),
    ('rag-api-docs',    '/rag/api-docs/**',     'http://teaa-rag:8082',             1,  16),
    ('rag-ui',          '/rag/**',              'http://teaa-ui-rag:4200',          1,  20),
    ('analyzer-api',    '/api/**',              'http://teaa-analyzer:8083',        0,  30),
    ('analyzer-swagger','/swagger-ui/**',       'http://teaa-analyzer:8083',        0,  35),
    ('analyzer-ui',     '/**',                  'http://teaa-ui-analyzer:4201',     0, 100)
ON CONFLICT (route_id) DO NOTHING;

-- Seed settings
INSERT INTO gateway_settings (key, value, description) VALUES
    ('cors.allowed-origins',  '*',                        'Дозволені CORS origins'),
    ('cors.allowed-methods',  'GET,POST,PUT,DELETE,OPTIONS', 'Дозволені HTTP методи')
ON CONFLICT (key) DO NOTHING;
