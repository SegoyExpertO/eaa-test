package ua.teaa.gateway.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.gateway.config.DatabaseRouteLocator;
import ua.teaa.gateway.entity.GatewayRoute;
import ua.teaa.gateway.repository.GatewayRouteRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class RouteService {

    private final GatewayRouteRepository repository;
    private final DatabaseRouteLocator routeLocator;

    public Flux<GatewayRoute> findAll() {
        return repository.findAll();
    }

    public Mono<GatewayRoute> findById(Long id) {
        return repository.findById(id);
    }

    public Mono<GatewayRoute> create(GatewayRoute route) {
        route.setCreatedAt(LocalDateTime.now());
        route.setUpdatedAt(LocalDateTime.now());
        if (route.getEnabled() == null) route.setEnabled(true);
        if (route.getStripPrefix() == null) route.setStripPrefix(0);
        if (route.getOrderNum() == null) route.setOrderNum(100);
        return repository.save(route)
                .doOnSuccess(r -> {
                    routeLocator.refresh();
                    log.info("Маршрут створено: {} → {}", r.getPath(), r.getTarget());
                });
    }

    public Mono<GatewayRoute> update(Long id, GatewayRoute updated) {
        return repository.findById(id).flatMap(existing -> {
            existing.setRouteId(updated.getRouteId());
            existing.setPath(updated.getPath());
            existing.setTarget(updated.getTarget());
            existing.setRewriteFrom(updated.getRewriteFrom());
            existing.setRewriteTo(updated.getRewriteTo());
            existing.setStripPrefix(updated.getStripPrefix());
            existing.setOrderNum(updated.getOrderNum());
            existing.setEnabled(updated.getEnabled());
            existing.setUpdatedAt(LocalDateTime.now());
            return repository.save(existing);
        }).doOnSuccess(r -> {
            routeLocator.refresh();
            log.info("Маршрут оновлено: {}", r.getRouteId());
        });
    }

    public Mono<Void> delete(Long id) {
        return repository.deleteById(id)
                .doOnSuccess(v -> routeLocator.refresh());
    }

    public Mono<byte[]> exportRoutes() {
        return repository.findAll().collectList().map(routes -> {
            try {
                ObjectMapper mapper = new ObjectMapper();
                mapper.registerModule(new JavaTimeModule());
                mapper.enable(SerializationFeature.INDENT_OUTPUT);
                mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                return mapper.writeValueAsBytes(Map.of("routes", routes));
            } catch (Exception e) {
                throw new RuntimeException("Export error: " + e.getMessage(), e);
            }
        });
    }

    public Mono<Map<String, Object>> importRoutes(byte[] data) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            Map<String, Object> imported = mapper.readValue(data, new TypeReference<>() {});
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> routeMaps = (List<Map<String, Object>>) imported.get("routes");

            if (routeMaps == null || routeMaps.isEmpty()) {
                return Mono.just(Map.of("imported", 0, "status", "EMPTY"));
            }

            return Flux.fromIterable(routeMaps)
                    .flatMap(routeMap -> {
                        GatewayRoute route = mapper.convertValue(routeMap, GatewayRoute.class);
                        route.setId(null);
                        route.setCreatedAt(LocalDateTime.now());
                        route.setUpdatedAt(LocalDateTime.now());
                        return repository.findByRouteId(route.getRouteId())
                                .flatMap(existing -> {
                                    existing.setPath(route.getPath());
                                    existing.setTarget(route.getTarget());
                                    existing.setRewriteFrom(route.getRewriteFrom());
                                    existing.setRewriteTo(route.getRewriteTo());
                                    existing.setStripPrefix(route.getStripPrefix());
                                    existing.setOrderNum(route.getOrderNum());
                                    existing.setEnabled(route.getEnabled());
                                    existing.setUpdatedAt(LocalDateTime.now());
                                    return repository.save(existing);
                                })
                                .switchIfEmpty(repository.save(route));
                    })
                    .count()
                    .map(count -> {
                        routeLocator.refresh();
                        log.info("Імпортовано {} маршрутів", count);
                        return Map.<String, Object>of("imported", count, "status", "SUCCESS");
                    });

        } catch (Exception e) {
            return Mono.just(Map.of("imported", 0, "status", "ERROR", "error", e.getMessage()));
        }
    }

    public void refresh() {
        routeLocator.refresh();
    }
}
