package ua.teaa.gateway.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.event.RefreshRoutesEvent;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import ua.teaa.gateway.entity.GatewayRoute;
import ua.teaa.gateway.repository.GatewayRouteRepository;

@Slf4j
@Component
@RequiredArgsConstructor
public class DatabaseRouteLocator implements RouteLocator {

    private final GatewayRouteRepository routeRepository;
    private final RouteLocatorBuilder routeLocatorBuilder;
    private final ApplicationEventPublisher eventPublisher;

    @Override
    public Flux<Route> getRoutes() {
        return routeRepository.findAllEnabled()
                .map(this::buildRoute)
                .doOnComplete(() -> log.debug("Маршрути завантажено з БД"));
    }

    public void refresh() {
        eventPublisher.publishEvent(new RefreshRoutesEvent(this));
        log.info("Маршрути оновлено");
    }

    private Route buildRoute(GatewayRoute dbRoute) {
        var builder = Route.async()
                .id(dbRoute.getRouteId())
                .uri(dbRoute.getTarget())
                .order(dbRoute.getOrderNum())
                .asyncPredicate(exchange -> {
                    String requestPath = exchange.getRequest().getURI().getPath();
                    String pattern = dbRoute.getPath().replace("/**", "");
                    return reactor.core.publisher.Mono.just(
                            requestPath.startsWith(pattern) || requestPath.equals(pattern));
                });

        if (dbRoute.getStripPrefix() != null && dbRoute.getStripPrefix() > 0) {
            builder.filter((exchange, chain) -> {
                var request = exchange.getRequest().mutate();
                String originalPath = exchange.getRequest().getURI().getPath();
                String[] segments = originalPath.split("/");
                int skip = dbRoute.getStripPrefix();
                StringBuilder newPath = new StringBuilder();
                for (int i = skip + 1; i < segments.length; i++) {
                    newPath.append("/").append(segments[i]);
                }
                if (newPath.isEmpty()) newPath.append("/");
                request.path(newPath.toString());
                return chain.filter(exchange.mutate().request(request.build()).build());
            });
        }

        if (dbRoute.getRewriteFrom() != null && dbRoute.getRewriteTo() != null) {
            builder.filter((exchange, chain) -> {
                var request = exchange.getRequest().mutate();
                String path = exchange.getRequest().getURI().getPath();
                String rewritten = path.replaceFirst(
                        dbRoute.getRewriteFrom().replace("**", ".*"),
                        dbRoute.getRewriteTo().replace("**", ""));
                request.path(rewritten);
                return chain.filter(exchange.mutate().request(request.build()).build());
            });
        }

        return builder.build();
    }
}
