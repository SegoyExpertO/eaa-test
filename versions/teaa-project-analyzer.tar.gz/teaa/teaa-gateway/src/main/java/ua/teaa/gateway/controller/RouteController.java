package ua.teaa.gateway.controller;

import lombok.RequiredArgsConstructor;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.gateway.entity.GatewayRoute;
import ua.teaa.gateway.service.RouteService;

import java.util.Map;

@Tag(name = "Gateway Routes", description = "Управління маршрутами gateway")
@RestController
@RequestMapping("/api/v1/gateway/routes")
@RequiredArgsConstructor
public class RouteController {
    private final RouteService service;

    @GetMapping
    public Flux<GatewayRoute> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Mono<GatewayRoute> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<GatewayRoute> create(@RequestBody GatewayRoute route) {
        return service.create(route);
    }

    @PutMapping("/{id}")
    public Mono<GatewayRoute> update(@PathVariable Long id, @RequestBody GatewayRoute route) {
        return service.update(id, route);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable Long id) {
        return service.delete(id);
    }

    @GetMapping("/export")
    public Mono<ResponseEntity<byte[]>> exportRoutes() {
        return service.exportRoutes()
                .map(data -> ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=gateway-routes.json")
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(data));
    }

    @PostMapping(value = "/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<Map<String, Object>> importRoutes(@RequestPart("file") FilePart file) {
        return DataBufferUtils.join(file.content())
                .map(buffer -> {
                    byte[] bytes = new byte[buffer.readableByteCount()];
                    buffer.read(bytes);
                    DataBufferUtils.release(buffer);
                    return bytes;
                })
                .flatMap(service::importRoutes);
    }

    @PostMapping("/refresh")
    public Mono<Map<String, String>> refresh() {
        service.refresh();
        return Mono.just(Map.of("status", "OK"));
    }
}
