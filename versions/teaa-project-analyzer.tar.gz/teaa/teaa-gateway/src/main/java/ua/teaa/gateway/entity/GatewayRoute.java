package ua.teaa.gateway.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("gateway_routes")
public class GatewayRoute {
    @Id
    private Long id;
    private String routeId;
    private String path;
    private String target;
    private String rewriteFrom;
    private String rewriteTo;
    private Integer stripPrefix;
    private Integer orderNum;
    private Boolean enabled;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
