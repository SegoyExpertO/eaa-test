package ua.teaa.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeaaGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(TeaaGatewayApplication.class, args);
    }
}
