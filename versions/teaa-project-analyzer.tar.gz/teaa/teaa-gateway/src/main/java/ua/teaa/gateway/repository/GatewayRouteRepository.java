package ua.teaa.gateway.repository;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ua.teaa.gateway.entity.GatewayRoute;

public interface GatewayRouteRepository extends R2dbcRepository<GatewayRoute, Long> {
    Mono<GatewayRoute> findByRouteId(String routeId);

    @Query("SELECT * FROM gateway_routes WHERE enabled = true ORDER BY order_num")
    Flux<GatewayRoute> findAllEnabled();
}
