package ua.teaa.gateway.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import ua.teaa.gateway.config.DatabaseRouteLocator;
import ua.teaa.gateway.entity.GatewayRoute;
import ua.teaa.gateway.repository.GatewayRouteRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RouteServiceTest {

    @Mock private GatewayRouteRepository repository;
    @Mock private DatabaseRouteLocator routeLocator;
    @InjectMocks private RouteService service;

    @Test
    void shouldCreateAndRefresh() {
        var route = GatewayRoute.builder().routeId("test").path("/test/**").target("http://localhost:9999").build();
        when(repository.save(any())).thenAnswer(inv -> {
            GatewayRoute r = inv.getArgument(0);
            r.setId(1L);
            return Mono.just(r);
        });
        doNothing().when(routeLocator).refresh();

        StepVerifier.create(service.create(route))
                .assertNext(r -> {
                    assertThat(r.getId()).isEqualTo(1L);
                    assertThat(r.getEnabled()).isTrue();
                })
                .verifyComplete();

        verify(routeLocator).refresh();
    }

    @Test
    void shouldExport() {
        when(repository.findAll()).thenReturn(Flux.just(
                GatewayRoute.builder().routeId("r1").path("/a/**").target("http://a").build()));

        StepVerifier.create(service.exportRoutes())
                .assertNext(bytes -> {
                    String json = new String(bytes);
                    assertThat(json).contains("r1");
                    assertThat(json).contains("/a/**");
                })
                .verifyComplete();
    }
}
