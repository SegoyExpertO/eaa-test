# TEAA — Tizen European Accessibility Auditor

Система для аналізу вихідного коду Tizen TV застосунків на відповідність вимогам European Accessibility Act (EAA). Складається з RAG-бази знань стандартів, LLM-аналізатора з конфігурованими стратегіями, веб-інтерфейсів та API Gateway.

## Архітектура

| Сервіс | Порт | Опис |
|---|---|---|
| teaa-gateway | 443 | Spring Cloud Gateway, маршрути в БД, export/import конфігурації |
| teaa-rag | 8082 | RAG-база знань: джерела, завдання, чанки, embeddings, пошук |
| teaa-analyzer | 8083 | Аналіз коду з LLM, конфігуровані стратегії pipeline |
| RAG Admin UI | 4200 | Angular, управління RAG |
| Analyzer UI | 4201 | Angular, аналіз коду, звіти |
| TEI (зовнішній) | 8080 | Text Embeddings Inference, модель конфігурована |
| Ollama (зовнішній) | 11434 | LLM (qwen2.5:14b за замовчуванням) |

## Запуск

```bash
export TEI_BASE_URL=http://<tei-server>:8080
export OLLAMA_BASE_URL=http://<ollama-server>:11434

docker compose up -d

# Gateway:      https://localhost
# Analyzer UI:  https://localhost/
# RAG Admin:    https://localhost/rag/
# RAG API:      https://localhost/rag/api/
# Analyzer API: https://localhost/api/
```

## Структура

```
teaa/
├── pom.xml                  # Parent Maven POM
├── docker-compose.yml       # 7 сервісів + 3 PostgreSQL
├── teaa-gateway/            # Spring Cloud Gateway
├── teaa-rag/                # RAG Service (Java 21, WebFlux, pgvector)
├── teaa-analyzer/           # Analyzer Service (Java 21, WebFlux, Ollama)
├── teaa-ui/                 # RAG Admin UI (Angular 19)
└── teaa-ui-analyzer/        # Analyzer UI (Angular 19)
```

## REST API

### Gateway (порт 443)
| Endpoint | Опис |
|---|---|
| CRUD `/api/v1/gateway/routes` | Маршрути |
| `GET /api/v1/gateway/routes/export` | Експорт конфігурації |
| `POST /api/v1/gateway/routes/import` | Імпорт конфігурації |

### RAG Service (через `/rag/api/`)
| Endpoint | Опис |
|---|---|
| CRUD `/api/v1/source-types` | Типи джерел |
| CRUD `/api/v1/sources` | Джерела |
| CRUD `/api/v1/build-profiles` | Профілі побудови |
| CRUD `/api/v1/jobs` | Завдання (DOWNLOAD, EMBED) |
| CRUD `/api/v1/collections` | Колекції |
| CRUD `/api/v1/settings` | Налаштування |
| `POST /api/v1/search` | Семантичний пошук |
| `GET /api/v1/export` | Експорт RAG |
| `POST /api/v1/import` | Імпорт RAG |

### Analyzer Service (через `/api/`)
| Endpoint | Опис |
|---|---|
| `POST /api/v1/analyze` | Створити аналіз (текст/архів + питання) |
| `GET /api/v1/analyze/jobs` | Завдання |
| `GET /api/v1/reports` | Звіти |
| `GET /api/v1/reports/{id}` | Повний звіт по розділах EAA |
| CRUD `/api/v1/strategies` | Стратегії аналізу |
| CRUD `/api/v1/settings` | Налаштування |

## Стратегії аналізу

3 пресети (зберігаються в БД, обираються при запиті):

| Стратегія | Опис |
|---|---|
| parallel (default) | Всі джерела паралельно → ранжування |
| concrete-to-formal | axe-core+Tizen → EN 301 549 → WCAG |
| formal-to-concrete | WCAG → EN 301 549 → axe-core+Tizen |

Можна створити власну через API — довільний pipeline JSON.

## Ліцензія

Proprietary
