import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HttpClient } from '@angular/common/http';

interface BuildProfile {
  id?: number; name: string; description?: string; embeddingModel: string;
  dimensions: number; chunkSize: number; chunkOverlap: number; isDefault?: boolean;
}

@Component({
  selector: 'app-build-profiles',
  standalone: true,
  imports: [CommonModule, FormsModule, MatTableModule, MatButtonModule, MatIconModule,
            MatFormFieldModule, MatInputModule, MatChipsModule, MatSnackBarModule],
  template: `
    <div class="page-header">
      <h1 i18n="@@buildProfilesTitle">Профілі побудови</h1>
      <button mat-flat-button color="primary" (click)="showCreate()" i18n="@@bpCreate">Створити</button>
    </div>

    <table mat-table [dataSource]="items()" class="mat-elevation-z0">
      <ng-container matColumnDef="name"><th mat-header-cell *matHeaderCellDef i18n="@@bpColName">Назва</th>
        <td mat-cell *matCellDef="let p">{{ p.name }} @if (p.isDefault) { <mat-chip>default</mat-chip> }</td></ng-container>
      <ng-container matColumnDef="model"><th mat-header-cell *matHeaderCellDef i18n="@@bpColModel">Модель</th>
        <td mat-cell *matCellDef="let p"><code>{{ p.embeddingModel }}</code></td></ng-container>
      <ng-container matColumnDef="dimensions"><th mat-header-cell *matHeaderCellDef>Dim</th>
        <td mat-cell *matCellDef="let p">{{ p.dimensions }}</td></ng-container>
      <ng-container matColumnDef="chunk"><th mat-header-cell *matHeaderCellDef>Chunk</th>
        <td mat-cell *matCellDef="let p">{{ p.chunkSize }} / {{ p.chunkOverlap }}</td></ng-container>
      <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let p">
          <button mat-icon-button (click)="remove(p)" color="warn"><mat-icon>delete</mat-icon></button>
        </td></ng-container>
      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>

    @if (creating()) {
      <div class="card create-form">
        <h3 i18n="@@bpFormTitle">Новий профіль</h3>
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Назва</mat-label><input matInput [(ngModel)]="form.name">
        </mat-form-field>
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Опис</mat-label><input matInput [(ngModel)]="form.description">
        </mat-form-field>
        <div class="row">
          <mat-form-field appearance="outline"><mat-label>Embedding модель</mat-label>
            <input matInput [(ngModel)]="form.embeddingModel"></mat-form-field>
          <mat-form-field appearance="outline"><mat-label>Розмірність</mat-label>
            <input matInput type="number" [(ngModel)]="form.dimensions"></mat-form-field>
        </div>
        <div class="row">
          <mat-form-field appearance="outline"><mat-label>Chunk size</mat-label>
            <input matInput type="number" [(ngModel)]="form.chunkSize"></mat-form-field>
          <mat-form-field appearance="outline"><mat-label>Overlap</mat-label>
            <input matInput type="number" [(ngModel)]="form.chunkOverlap"></mat-form-field>
        </div>
        <div class="form-actions">
          <button mat-stroked-button (click)="creating.set(false)">Скасувати</button>
          <button mat-flat-button color="primary" (click)="create()">Зберегти</button>
        </div>
      </div>
    }
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.75rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
    .create-form { margin-top: 16px; max-width: 640px; }
    .full-width { width: 100%; }
    .row { display: flex; gap: 16px; }
    .row mat-form-field { flex: 1; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 12px; }
  `]
})
export class BuildProfilesComponent implements OnInit {
  items = signal<BuildProfile[]>([]);
  columns = ['name', 'model', 'dimensions', 'chunk', 'actions'];
  creating = signal(false);
  form: BuildProfile = { name: '', embeddingModel: 'nomic-embed-text', dimensions: 768, chunkSize: 800, chunkOverlap: 200 };

  constructor(private http: HttpClient, private snackBar: MatSnackBar) {}
  ngOnInit(): void { this.load(); }

  showCreate(): void {
    this.creating.set(true);
    this.form = { name: '', embeddingModel: 'nomic-embed-text', dimensions: 768, chunkSize: 800, chunkOverlap: 200 };
  }

  create(): void {
    this.http.post<BuildProfile>('/api/v1/build-profiles', this.form).subscribe(() => {
      this.creating.set(false); this.snackBar.open('Створено', '', { duration: 2000 }); this.load();
    });
  }

  remove(p: BuildProfile): void {
    this.http.delete(`/api/v1/build-profiles/${p.id}`).subscribe(() => {
      this.snackBar.open('Видалено', '', { duration: 2000 }); this.load();
    });
  }

  private load(): void {
    this.http.get<BuildProfile[]>('/api/v1/build-profiles').subscribe(p => this.items.set(p));
  }
}
