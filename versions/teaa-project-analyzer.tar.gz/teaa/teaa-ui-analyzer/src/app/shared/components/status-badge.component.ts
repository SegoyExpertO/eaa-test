import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-status-badge',
  standalone: true,
  imports: [CommonModule],
  template: `<span class="badge" [ngClass]="'status-' + status.toLowerCase()">{{ status }}</span>`,
  styles: [`
    .badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    .status-pending { background: rgba(217,119,6,0.12); color: #d97706; }
    .status-running { background: rgba(37,99,235,0.12); color: #2563eb; }
    .status-completed { background: rgba(22,163,74,0.12); color: #16a34a; }
    .status-failed { background: rgba(220,38,38,0.12); color: #dc2626; }
    .status-pass { background: rgba(22,163,74,0.12); color: #16a34a; }
    .status-partial { background: rgba(217,119,6,0.12); color: #d97706; }
    .status-fail { background: rgba(220,38,38,0.12); color: #dc2626; }
  `]
})
export class StatusBadgeComponent {
  @Input() status = '';
}
