import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const API = '/api/v1';

export interface AnalysisJob {
  id?: number; inputType: string; inputFilename?: string; question: string;
  strategyId?: number; status?: string; currentStep?: number; totalSteps?: number;
  progress?: number; errorMessage?: string; createdAt?: string;
}
export interface AnalysisReport {
  id?: number; jobId: number; summary?: string; overallStatus?: string;
  reportData?: any; stepResults?: any; strategyUsed?: any;
  filesAnalyzed?: number; findingsCount?: number; createdAt?: string;
}
export interface Strategy {
  id?: number; name: string; description?: string; pipeline: string;
  isDefault?: boolean; createdAt?: string;
}
export interface Setting { key: string; value: string; description?: string; }
export interface SystemStatus {
  runningJobs: number; pendingJobs: number; totalReports: number;
  ollamaHealthy: boolean; teiHealthy: boolean; ragHealthy: boolean;
}

@Injectable({ providedIn: 'root' })
export class AnalyzeApiService {
  constructor(private http: HttpClient) {}
  analyzeText(data: { text: string; question: string; strategyId?: number }): Observable<AnalysisJob> {
    return this.http.post<AnalysisJob>(`${API}/analyze`, { inputType: 'TEXT', ...data });
  }
  analyzeArchive(file: File, question: string, strategyId?: number): Observable<AnalysisJob> {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('question', question);
    if (strategyId) fd.append('strategyId', String(strategyId));
    return this.http.post<AnalysisJob>(`${API}/analyze`, fd);
  }
  getJobs(): Observable<AnalysisJob[]> { return this.http.get<AnalysisJob[]>(`${API}/analyze/jobs`); }
  getJob(id: number): Observable<AnalysisJob> { return this.http.get<AnalysisJob>(`${API}/analyze/jobs/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class ReportApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<AnalysisReport[]> { return this.http.get<AnalysisReport[]>(`${API}/reports`); }
  findById(id: number): Observable<AnalysisReport> { return this.http.get<AnalysisReport>(`${API}/reports/${id}`); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/reports/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class StrategyApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<Strategy[]> { return this.http.get<Strategy[]>(`${API}/strategies`); }
  findById(id: number): Observable<Strategy> { return this.http.get<Strategy>(`${API}/strategies/${id}`); }
  create(s: Strategy): Observable<Strategy> { return this.http.post<Strategy>(`${API}/strategies`, s); }
  update(id: number, s: Strategy): Observable<Strategy> { return this.http.put<Strategy>(`${API}/strategies/${id}`, s); }
  delete(id: number): Observable<void> { return this.http.delete<void>(`${API}/strategies/${id}`); }
}

@Injectable({ providedIn: 'root' })
export class SettingsApiService {
  constructor(private http: HttpClient) {}
  findAll(): Observable<Setting[]> { return this.http.get<Setting[]>(`${API}/settings`); }
  update(key: string, value: string): Observable<Setting> { return this.http.put<Setting>(`${API}/settings/${key}`, { value }); }
}

@Injectable({ providedIn: 'root' })
export class StatusApiService {
  constructor(private http: HttpClient) {}
  getStatus(): Observable<SystemStatus> { return this.http.get<SystemStatus>(`${API}/status`); }
}
