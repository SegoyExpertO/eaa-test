import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatChipsModule } from '@angular/material/chips';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { ReportApiService, AnalysisReport } from '@app/shared/services/api.service';

@Component({
  selector: 'app-report-detail',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatExpansionModule, MatChipsModule, MatTabsModule, MatIconModule],
  template: `
    @if (report(); as r) {
      <div class="page-header">
        <h1 i18n="@@reportTitle">Звіт #{{ r.id }}</h1>
        <span class="overall-badge" [class]="'status-' + r.overallStatus?.toLowerCase()">
          {{ r.overallStatus }}
        </span>
      </div>

      <mat-card class="summary-card">
        <p class="summary-text">{{ r.summary }}</p>
        <div class="stats">
          <span i18n="@@reportFiles">Файлів: {{ r.filesAnalyzed }}</span>
          <span i18n="@@reportFindings">Порушень: {{ r.findingsCount }}</span>
        </div>
      </mat-card>

      <mat-tab-group>
        <mat-tab label="Звіт" i18n-label="@@reportTabReport">
          @if (sections().length > 0) {
            <mat-accordion>
              @for (section of sections(); track section.sectionId) {
                <mat-expansion-panel>
                  <mat-expansion-panel-header>
                    <mat-panel-title>
                      <span class="section-status" [class]="'status-' + section.status?.toLowerCase()">●</span>
                      {{ section.sectionTitle }}
                    </mat-panel-title>
                    <mat-panel-description>
                      {{ section.findings?.length || 0 }} порушень
                    </mat-panel-description>
                  </mat-expansion-panel-header>

                  @if (section.findings?.length > 0) {
                    @for (finding of section.findings; track finding.criterion) {
                      <div class="finding">
                        <div class="finding-header">
                          <span class="criterion">{{ finding.criterion }}</span>
                          <span class="severity" [class]="'sev-' + finding.severity">{{ finding.severity }}</span>
                          <span class="finding-title">{{ finding.title }}</span>
                        </div>
                        <p class="finding-desc">{{ finding.description }}</p>
                        @if (finding.file) {
                          <p class="finding-file"><mat-icon>code</mat-icon> {{ finding.file }}:{{ finding.line }}</p>
                        }
                        @if (finding.codeSnippet) {
                          <pre class="code-snippet">{{ finding.codeSnippet }}</pre>
                        }
                        <p class="finding-rec"><mat-icon>lightbulb</mat-icon> {{ finding.recommendation }}</p>
                        @if (finding.standard) {
                          <span class="standard-ref">{{ finding.standard }}</span>
                        }
                      </div>
                    }
                  } @else {
                    <p class="no-findings" i18n="@@reportNoFindings">Порушень не знайдено</p>
                  }
                </mat-expansion-panel>
              }
            </mat-accordion>
          }
        </mat-tab>

        <mat-tab label="Кроки pipeline" i18n-label="@@reportTabSteps">
          <pre class="json-block">{{ r.stepResults | json }}</pre>
        </mat-tab>

        <mat-tab label="Стратегія" i18n-label="@@reportTabStrategy">
          <pre class="json-block">{{ r.strategyUsed | json }}</pre>
        </mat-tab>
      </mat-tab-group>
    }
  `,
  styles: [`
    .summary-card { padding: 24px; margin-bottom: 24px; background: var(--bg-surface); border: 1px solid var(--border-color); }
    .summary-text { font-size: 1rem; line-height: 1.6; margin-bottom: 12px; }
    .stats { display: flex; gap: 24px; color: var(--text-secondary); font-size: 0.85rem; }
    .overall-badge { padding: 4px 14px; border-radius: 12px; font-weight: 600; font-size: 0.85rem; }
    .status-pass { background: rgba(22,163,74,0.12); color: #16a34a; }
    .status-partial { background: rgba(217,119,6,0.12); color: #d97706; }
    .status-fail { background: rgba(220,38,38,0.12); color: #dc2626; }
    .section-status { margin-right: 8px; }
    .finding { padding: 16px; border-bottom: 1px solid var(--border-color); }
    .finding-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .criterion { font-weight: 600; color: var(--primary); }
    .severity { padding: 2px 8px; border-radius: 10px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; }
    .sev-critical { background: rgba(220,38,38,0.12); color: #dc2626; }
    .sev-serious { background: rgba(217,119,6,0.12); color: #d97706; }
    .sev-moderate { background: rgba(37,99,235,0.12); color: #2563eb; }
    .sev-minor { background: rgba(148,163,184,0.12); color: #94a3b8; }
    .finding-title { font-weight: 500; }
    .finding-desc { font-size: 0.9rem; color: var(--text-primary); }
    .finding-file { font-size: 0.8rem; color: var(--text-secondary); display: flex; align-items: center; gap: 4px; }
    .finding-file mat-icon { font-size: 16px; width: 16px; height: 16px; }
    .code-snippet { background: var(--bg-primary); padding: 8px 12px; border-radius: 4px; font-size: 0.8rem; overflow-x: auto; }
    .finding-rec { font-size: 0.85rem; color: var(--success); display: flex; align-items: center; gap: 4px; }
    .finding-rec mat-icon { font-size: 16px; width: 16px; height: 16px; }
    .standard-ref { font-size: 0.75rem; color: var(--text-secondary); background: rgba(37,99,235,0.06); padding: 2px 8px; border-radius: 10px; }
    .no-findings { color: var(--text-secondary); padding: 16px; }
    .json-block { background: var(--bg-primary); padding: 16px; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; }
  `]
})
export class ReportDetailComponent implements OnInit {
  report = signal<AnalysisReport | null>(null);
  sections = signal<any[]>([]);

  constructor(private route: ActivatedRoute, private api: ReportApiService) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.api.findById(id).subscribe(r => {
      this.report.set(r);
      if (r.reportData) {
        try {
          const data = typeof r.reportData === 'string' ? JSON.parse(r.reportData) : r.reportData;
          this.sections.set(data?.sections || data?.result?.sections || []);
        } catch { this.sections.set([]); }
      }
    });
  }
}
