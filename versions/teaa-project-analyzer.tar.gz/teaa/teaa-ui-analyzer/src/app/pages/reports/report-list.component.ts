import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ReportApiService, AnalysisReport } from '@app/shared/services/api.service';

@Component({
  selector: 'app-report-list',
  standalone: true,
  imports: [CommonModule, RouterModule, MatTableModule, MatButtonModule, MatIconModule],
  template: `
    <div class="page-header"><h1 i18n="@@reportsTitle">Звіти</h1></div>
    <table mat-table [dataSource]="reports()" class="mat-elevation-z0">
      <ng-container matColumnDef="id"><th mat-header-cell *matHeaderCellDef>ID</th><td mat-cell *matCellDef="let r">#{{ r.id }}</td></ng-container>
      <ng-container matColumnDef="status"><th mat-header-cell *matHeaderCellDef i18n="@@repColStatus">Статус</th>
        <td mat-cell *matCellDef="let r"><span class="badge" [class]="'status-'+r.overallStatus?.toLowerCase()">{{ r.overallStatus }}</span></td></ng-container>
      <ng-container matColumnDef="findings"><th mat-header-cell *matHeaderCellDef i18n="@@repColFindings">Порушень</th><td mat-cell *matCellDef="let r">{{ r.findingsCount }}</td></ng-container>
      <ng-container matColumnDef="files"><th mat-header-cell *matHeaderCellDef i18n="@@repColFiles">Файлів</th><td mat-cell *matCellDef="let r">{{ r.filesAnalyzed }}</td></ng-container>
      <ng-container matColumnDef="date"><th mat-header-cell *matHeaderCellDef i18n="@@repColDate">Дата</th><td mat-cell *matCellDef="let r">{{ r.createdAt | date:'short' }}</td></ng-container>
      <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let r"><a mat-icon-button [routerLink]="['/reports', r.id]"><mat-icon>visibility</mat-icon></a></td></ng-container>
      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`table { width: 100%; background: var(--bg-surface); }
    .badge { padding: 2px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }
    .status-pass { background: rgba(22,163,74,0.12); color: #16a34a; }
    .status-partial { background: rgba(217,119,6,0.12); color: #d97706; }
    .status-fail { background: rgba(220,38,38,0.12); color: #dc2626; }`]
})
export class ReportListComponent implements OnInit {
  reports = signal<AnalysisReport[]>([]);
  columns = ['id', 'status', 'findings', 'files', 'date', 'actions'];
  constructor(private api: ReportApiService) {}
  ngOnInit(): void { this.api.findAll().subscribe(r => this.reports.set(r)); }
}
