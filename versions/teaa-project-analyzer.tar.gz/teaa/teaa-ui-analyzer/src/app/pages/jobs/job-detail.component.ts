import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AnalyzeApiService, AnalysisJob, ReportApiService, AnalysisReport } from '@app/shared/services/api.service';
import { interval, Subscription, switchMap, filter } from 'rxjs';

@Component({
  selector: 'app-job-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, MatCardModule, MatProgressBarModule, MatButtonModule, MatIconModule],
  template: `
    <div class="page-header"><h1 i18n="@@jobTitle">Завдання #{{ job()?.id }}</h1></div>
    @if (job(); as j) {
      <mat-card class="job-card">
        <div class="status-row">
          <span class="status-badge" [class]="'status-' + j.status?.toLowerCase()">{{ j.status }}</span>
          <span class="step-info" i18n="@@jobStep">Крок {{ j.currentStep }} / {{ j.totalSteps }}</span>
        </div>
        <mat-progress-bar mode="determinate" [value]="j.progress ?? 0"></mat-progress-bar>
        <p class="progress-text">{{ j.progress }}%</p>

        @if (j.errorMessage) {
          <div class="error-box">{{ j.errorMessage }}</div>
        }

        @if (j.status === 'COMPLETED' && reportId()) {
          <a mat-flat-button color="primary" [routerLink]="['/reports', reportId()]" i18n="@@jobViewReport">
            <mat-icon>assessment</mat-icon> Переглянути звіт
          </a>
        }

        <div class="meta">
          <p i18n="@@jobQuestion">Питання: {{ j.question }}</p>
          <p i18n="@@jobCreated">Створено: {{ j.createdAt | date:'medium' }}</p>
        </div>
      </mat-card>
    }
  `,
  styles: [`
    .job-card { max-width: 640px; padding: 24px; background: var(--bg-surface); border: 1px solid var(--border-color); }
    .status-row { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; }
    .status-badge { padding: 4px 12px; border-radius: 12px; font-weight: 600; font-size: 0.8rem; text-transform: uppercase; }
    .status-pending { background: rgba(217,119,6,0.12); color: #d97706; }
    .status-running { background: rgba(37,99,235,0.12); color: #2563eb; }
    .status-completed { background: rgba(22,163,74,0.12); color: #16a34a; }
    .status-failed { background: rgba(220,38,38,0.12); color: #dc2626; }
    .step-info { color: var(--text-secondary); font-size: 0.85rem; }
    .progress-text { text-align: center; color: var(--text-secondary); margin: 8px 0 16px; }
    .error-box { background: rgba(220,38,38,0.08); color: #dc2626; padding: 12px; border-radius: 6px; margin-bottom: 16px; font-size: 0.85rem; }
    .meta { margin-top: 16px; font-size: 0.85rem; color: var(--text-secondary); }
    .meta p { margin: 4px 0; }
  `]
})
export class JobDetailComponent implements OnInit, OnDestroy {
  job = signal<AnalysisJob | null>(null);
  reportId = signal<number | null>(null);
  private sub?: Subscription;

  constructor(private route: ActivatedRoute, private api: AnalyzeApiService, private reportApi: ReportApiService) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.loadJob(id);
    this.sub = interval(3000).pipe(
        filter(() => { const s = this.job()?.status; return s === 'PENDING' || s === 'RUNNING'; }),
        switchMap(() => this.api.getJob(id))
    ).subscribe(j => {
      this.job.set(j);
      if (j.status === 'COMPLETED') this.loadReport(id);
    });
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  private loadJob(id: number): void {
    this.api.getJob(id).subscribe(j => {
      this.job.set(j);
      if (j.status === 'COMPLETED') this.loadReport(id);
    });
  }

  private loadReport(jobId: number): void {
    this.reportApi.findAll().subscribe(reports => {
      const r = reports.find(rep => rep.jobId === jobId);
      if (r) this.reportId.set(r.id!);
    });
  }
}
