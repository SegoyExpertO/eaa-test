import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AnalyzeApiService, StrategyApiService, Strategy } from '@app/shared/services/api.service';

@Component({
  selector: 'app-analyze',
  standalone: true,
  imports: [CommonModule, FormsModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatTabsModule, MatIconModule, MatSnackBarModule],
  template: `
    <div class="page-header"><h1 i18n="@@analyzeTitle">Аналіз коду</h1></div>
    <div class="card form-card">
      <mat-tab-group [(selectedIndex)]="tabIndex">
        <mat-tab label="Текст" i18n-label="@@analyzeTabText">
          <mat-form-field appearance="outline" class="full-width">
            <mat-label i18n="@@analyzeCode">Вихідний код</mat-label>
            <textarea matInput [(ngModel)]="codeText" rows="12" class="code-input"></textarea>
          </mat-form-field>
        </mat-tab>
        <mat-tab label="Архів" i18n-label="@@analyzeTabArchive">
          <div class="upload-area">
            <input type="file" accept=".zip,.tar.gz" (change)="onFileSelected($event)" #fileInput>
            @if (selectedFile) {
              <p>{{ selectedFile.name }} ({{ (selectedFile.size / 1024).toFixed(1) }} KB)</p>
            }
          </div>
        </mat-tab>
      </mat-tab-group>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@analyzeQuestion">Питання</mat-label>
        <textarea matInput [(ngModel)]="question" rows="3"
                  placeholder="Чи відповідає цей код вимогам EAA?"></textarea>
      </mat-form-field>

      <mat-form-field appearance="outline" class="full-width">
        <mat-label i18n="@@analyzeStrategy">Стратегія</mat-label>
        <mat-select [(ngModel)]="strategyId">
          @for (s of strategies(); track s.id) {
            <mat-option [value]="s.id">{{ s.name }} {{ s.isDefault ? '(за замовчуванням)' : '' }}</mat-option>
          }
        </mat-select>
      </mat-form-field>

      <button mat-flat-button color="primary" (click)="submit()" [disabled]="!canSubmit()" i18n="@@analyzeSubmit">
        <mat-icon>play_arrow</mat-icon> Аналізувати
      </button>
    </div>
  `,
  styles: [`
    .form-card { max-width: 800px; }
    .full-width { width: 100%; margin-top: 16px; }
    .code-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .upload-area { padding: 24px 0; }
  `]
})
export class AnalyzeComponent implements OnInit {
  strategies = signal<Strategy[]>([]);
  codeText = '';
  question = '';
  strategyId: number | null = null;
  selectedFile: File | null = null;
  tabIndex = 0;

  constructor(
    private analyzeApi: AnalyzeApiService,
    private strategyApi: StrategyApiService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.strategyApi.findAll().subscribe(s => {
      this.strategies.set(s);
      const def = s.find(st => st.isDefault);
      if (def) this.strategyId = def.id!;
    });
  }

  canSubmit(): boolean {
    return this.question.trim().length > 0 &&
        (this.tabIndex === 0 ? this.codeText.trim().length > 0 : this.selectedFile !== null);
  }

  onFileSelected(event: Event): void {
    this.selectedFile = (event.target as HTMLInputElement).files?.[0] ?? null;
  }

  submit(): void {
    if (this.tabIndex === 0) {
      this.analyzeApi.analyzeText({
        text: this.codeText, question: this.question,
        strategyId: this.strategyId ?? undefined
      }).subscribe(job => this.router.navigate(['/analyze/jobs', job.id]));
    } else if (this.selectedFile) {
      this.analyzeApi.analyzeArchive(this.selectedFile, this.question, this.strategyId ?? undefined)
          .subscribe(job => this.router.navigate(['/analyze/jobs', job.id]));
    }
  }
}
