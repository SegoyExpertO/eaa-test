import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatChipsModule } from '@angular/material/chips';
import { StrategyApiService, Strategy } from '@app/shared/services/api.service';

@Component({
  selector: 'app-strategy-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatTableModule, MatButtonModule, MatIconModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatSnackBarModule, MatChipsModule],
  template: `
    <div class="page-header">
      <h1 i18n="@@strategiesTitle">Стратегії</h1>
      <button mat-flat-button color="primary" (click)="showCreate()" i18n="@@strategiesCreate">Створити</button>
    </div>

    <table mat-table [dataSource]="items()" class="mat-elevation-z0">
      <ng-container matColumnDef="name"><th mat-header-cell *matHeaderCellDef i18n="@@strColName">Назва</th>
        <td mat-cell *matCellDef="let s">{{ s.name }} @if (s.isDefault) { <mat-chip>default</mat-chip> }</td></ng-container>
      <ng-container matColumnDef="description"><th mat-header-cell *matHeaderCellDef i18n="@@strColDesc">Опис</th>
        <td mat-cell *matCellDef="let s">{{ s.description }}</td></ng-container>
      <ng-container matColumnDef="actions"><th mat-header-cell *matHeaderCellDef></th>
        <td mat-cell *matCellDef="let s">
          <button mat-icon-button (click)="showPipeline(s)"><mat-icon>visibility</mat-icon></button>
          <button mat-icon-button (click)="remove(s)" color="warn"><mat-icon>delete</mat-icon></button>
        </td></ng-container>
      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>

    @if (viewingPipeline()) {
      <div class="pipeline-view card">
        <h3>{{ viewingName() }}</h3>
        <pre>{{ viewingPipeline() | json }}</pre>
        <button mat-stroked-button (click)="viewingPipeline.set(null)">Закрити</button>
      </div>
    }

    @if (creating()) {
      <div class="card create-form">
        <h3 i18n="@@strategiesFormTitle">Нова стратегія</h3>
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Назва</mat-label><input matInput [(ngModel)]="newName">
        </mat-form-field>
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Опис</mat-label><input matInput [(ngModel)]="newDesc">
        </mat-form-field>
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Pipeline (JSON)</mat-label>
          <textarea matInput [(ngModel)]="newPipeline" rows="10" class="json-input"></textarea>
        </mat-form-field>
        <div class="form-actions">
          <button mat-stroked-button (click)="creating.set(false)">Скасувати</button>
          <button mat-flat-button color="primary" (click)="create()">Зберегти</button>
        </div>
      </div>
    }
  `,
  styles: [`
    table { width: 100%; background: var(--bg-surface); }
    .pipeline-view { margin-top: 16px; max-width: 800px; }
    .pipeline-view pre { background: var(--bg-primary); padding: 12px; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; }
    .create-form { margin-top: 16px; max-width: 640px; }
    .full-width { width: 100%; }
    .json-input { font-family: 'Courier New', monospace; font-size: 0.85rem; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 12px; }
  `]
})
export class StrategyListComponent implements OnInit {
  items = signal<Strategy[]>([]);
  columns = ['name', 'description', 'actions'];
  viewingPipeline = signal<any>(null);
  viewingName = signal('');
  creating = signal(false);
  newName = ''; newDesc = ''; newPipeline = '{}';

  constructor(private api: StrategyApiService, private snackBar: MatSnackBar) {}
  ngOnInit(): void { this.load(); }

  showPipeline(s: Strategy): void {
    try { this.viewingPipeline.set(JSON.parse(s.pipeline)); }
    catch { this.viewingPipeline.set(s.pipeline); }
    this.viewingName.set(s.name);
  }

  showCreate(): void { this.creating.set(true); this.newName = ''; this.newDesc = ''; this.newPipeline = '{}'; }

  create(): void {
    this.api.create({ name: this.newName, description: this.newDesc, pipeline: this.newPipeline })
        .subscribe(() => { this.creating.set(false); this.snackBar.open('Створено', '', { duration: 2000 }); this.load(); });
  }

  remove(s: Strategy): void {
    this.api.delete(s.id!).subscribe(() => { this.snackBar.open('Видалено', '', { duration: 2000 }); this.load(); });
  }

  private load(): void { this.api.findAll().subscribe(s => this.items.set(s)); }
}
