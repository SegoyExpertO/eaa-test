import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { SettingsApiService, Setting } from '@app/shared/services/api.service';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule, MatTableModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatIconModule, MatSnackBarModule],
  template: `
    <div class="page-header"><h1 i18n="@@settingsTitle">Налаштування</h1></div>
    <table mat-table [dataSource]="settings()" class="mat-elevation-z0">
      <ng-container matColumnDef="key"><th mat-header-cell *matHeaderCellDef>Ключ</th>
        <td mat-cell *matCellDef="let s"><code>{{ s.key }}</code></td></ng-container>
      <ng-container matColumnDef="value"><th mat-header-cell *matHeaderCellDef>Значення</th>
        <td mat-cell *matCellDef="let s">
          @if (editKey() === s.key) {
            <mat-form-field appearance="outline" class="inline">
              <input matInput [(ngModel)]="editValue" (keyup.enter)="save(s.key)">
            </mat-form-field>
            <button mat-icon-button (click)="save(s.key)" color="primary"><mat-icon>check</mat-icon></button>
            <button mat-icon-button (click)="editKey.set(null)"><mat-icon>close</mat-icon></button>
          } @else {
            <span (click)="startEdit(s)" class="editable">{{ s.value }}</span>
          }
        </td></ng-container>
      <ng-container matColumnDef="description"><th mat-header-cell *matHeaderCellDef>Опис</th>
        <td mat-cell *matCellDef="let s">{{ s.description }}</td></ng-container>
      <tr mat-header-row *matHeaderRowDef="columns"></tr>
      <tr mat-row *matRowDef="let row; columns: columns;"></tr>
    </table>
  `,
  styles: [`table { width: 100%; background: var(--bg-surface); }
    code { font-size: 0.8rem; color: var(--primary); background: rgba(37,99,235,0.06); padding: 2px 6px; border-radius: 4px; }
    .editable { cursor: pointer; } .editable:hover { text-decoration: underline; }
    .inline { width: 200px; }`]
})
export class SettingsComponent implements OnInit {
  settings = signal<Setting[]>([]);
  editKey = signal<string | null>(null);
  editValue = '';
  columns = ['key', 'value', 'description'];
  constructor(private api: SettingsApiService, private snackBar: MatSnackBar) {}
  ngOnInit(): void { this.api.findAll().subscribe(s => this.settings.set(s)); }
  startEdit(s: Setting): void { this.editKey.set(s.key); this.editValue = s.value; }
  save(key: string): void {
    this.api.update(key, this.editValue).subscribe(() => {
      this.editKey.set(null); this.snackBar.open('Збережено', '', { duration: 2000 });
      this.api.findAll().subscribe(s => this.settings.set(s));
    });
  }
}
