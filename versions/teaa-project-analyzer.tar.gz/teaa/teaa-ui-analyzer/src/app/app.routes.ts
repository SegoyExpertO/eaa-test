import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'analyze', pathMatch: 'full' },
  { path: 'analyze', loadComponent: () => import('./pages/analyze/analyze.component').then(m => m.AnalyzeComponent) },
  { path: 'analyze/jobs/:id', loadComponent: () => import('./pages/jobs/job-detail.component').then(m => m.JobDetailComponent) },
  { path: 'reports', loadComponent: () => import('./pages/reports/report-list.component').then(m => m.ReportListComponent) },
  { path: 'reports/:id', loadComponent: () => import('./pages/reports/report-detail.component').then(m => m.ReportDetailComponent) },
  { path: 'strategies', loadComponent: () => import('./pages/strategies/strategy-list.component').then(m => m.StrategyListComponent) },
  { path: 'settings', loadComponent: () => import('./pages/settings/settings.component').then(m => m.SettingsComponent) }
];
