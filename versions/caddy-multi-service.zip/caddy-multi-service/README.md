# Multi-Service Platform with Caddy

Платформа з двома Angular UI та двома Spring Boot backend сервісами за reverse proxy Caddy.

## Структура проєкту

```
caddy-multi-service/
├── docker-compose.yml          # Оркестрація всіх сервісів
├── caddy/
│   ├── Caddyfile               # Конфігурація Caddy з усіма маршрутами
│   └── Dockerfile              # Caddy зі збірним модулем rate-limit
├── ui1/
│   ├── Dockerfile              # Multi-stage збірка Angular -> nginx
│   └── nginx.conf              # SPA routing, кешування
├── ui2/
│   ├── Dockerfile
│   └── nginx.conf
├── backend1/
│   ├── Dockerfile              # Multi-stage Maven -> JRE
│   └── application.yml         # Spring Boot з налаштуваннями reverse proxy
└── backend2/
    ├── Dockerfile
    └── application.yml
```

## Маршрутизація

| URL | Призначення |
|-----|-------------|
| `http://<ip>/` | Перенаправлення на HTTPS, далі на `/ui1/` |
| `https://<ip>/ui1/` | Перший Angular UI |
| `https://<ip>/ui2/` | Другий Angular UI |
| `https://<ip>/api1/*` | REST API першого backend |
| `https://<ip>/api1/ws/*` | WebSocket першого backend |
| `https://<ip>/api1/sse/*` | SSE першого backend |
| `https://<ip>/api2/*` | REST API другого backend |
| `https://<ip>/api2/ws/*` | WebSocket другого backend |
| `https://<ip>/api2/sse/*` | SSE другого backend |
| `https://<ip>/actuator1/*` | Spring Actuator backend1 (тільки внутрішня мережа) |
| `https://<ip>/actuator2/*` | Spring Actuator backend2 (тільки внутрішня мережа) |

## Запуск

### Локальна розробка

1. Розмістити вихідний код Angular додатків у `ui1/` та `ui2/` (поряд з Dockerfile)
2. Розмістити вихідний код Spring Boot сервісів у `backend1/` та `backend2/`
3. Виконати:

```bash
docker compose up --build -d
```

4. Перевірити статус:

```bash
docker compose ps
docker compose logs -f caddy
```

5. Відкрити в браузері: `https://localhost` (буде попередження про сертифікат — це нормально)

### Деплой на сервер у локальній мережі

1. Скопіювати весь проєкт на сервер
2. Запустити так само:

```bash
docker compose up --build -d
```

3. Доступ за IP сервера: `https://192.168.x.x` або `https://10.x.x.x`

### Усунення попередження про сертифікат

Caddy використовує власний локальний CA. Щоб клієнти не бачили попередження:

```bash
# Експортувати кореневий сертифікат Caddy
docker compose exec caddy cat /data/caddy/pki/authorities/local/root.crt > caddy-root.crt

# Встановити цей сертифікат як довірений на клієнтських машинах
# Ubuntu/Debian:
sudo cp caddy-root.crt /usr/local/share/ca-certificates/
sudo update-ca-certificates

# Windows (через certmgr.msc): "Trusted Root Certification Authorities"
```

## Особливості налаштування

### Angular

Збірка для UI1:
```bash
ng build --configuration=production --base-href=/ui1/
```

У `app.config.ts`:
```typescript
import { APP_BASE_HREF } from '@angular/common';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    { provide: APP_BASE_HREF, useValue: '/ui1/' }
  ]
};
```

У `environments/environment.ts`:
```typescript
export const environment = {
  production: false,
  apiUrl: '/api1',  // відносний шлях - Caddy замаршрутизує
  wsUrl: '/api1/ws'
};
```

### Spring Boot

Налаштування `forward-headers-strategy: framework` критично важливе — без нього Spring не розумітиме, що працює за reverse proxy, та може генерувати неправильні URL у редиректах та HATEOAS-посиланнях.

CORS налаштовується **виключно в Caddy**, не у Spring. Якщо лишити CORS і там, і там — отримаєте дубльовані заголовки та помилки.

## Корисні команди

```bash
# Перегляд логів
docker compose logs -f caddy
docker compose logs -f backend1

# Перезавантаження тільки Caddy після зміни Caddyfile
docker compose restart caddy

# Перевірка валідності Caddyfile
docker compose exec caddy caddy validate --config /etc/caddy/Caddyfile

# Графічне форматування Caddyfile
docker compose exec caddy caddy fmt --overwrite /etc/caddy/Caddyfile

# Перевірка health-статусу
docker compose ps

# Зупинка та очистка
docker compose down -v
```

## Налаштування мережі

За замовчуванням Docker bridge мережа використовує підмережу `172.28.0.0/16`. Якщо вона конфліктує з вашою локальною мережею — змініть її в `docker-compose.yml`.

ACL для actuator endpoints дозволяє доступ з підмереж:
- `10.0.0.0/8`
- `172.16.0.0/12`
- `192.168.0.0/16`
- `127.0.0.1`

Якщо ваша внутрішня мережа використовує іншу підмережу — додайте її в `Caddyfile` у блоках `actuator1` та `actuator2`.
